#!/usr/bin/env python3
"""
lyricglow web — a YouTube Music web app that runs on YOUR machine and is reached over Tailscale.

  lyricglow web                  start the server  (prints the URLs to open on your phone / other devices)

The browser never talks to YouTube: this server does. It
  * searches / browses YouTube Music (ytmusicapi),
  * turns yt-dlp results into audio streams (direct proxy, or ffmpeg-transcoded + cached: AAC / MP3 / Opus,
    optional loudness normalisation, low-bitrate "data saver"),
  * proxies + caches album art, fetches word-synced lyrics and animated covers,
  * keeps your local library (liked songs, playlists) so it works without any account.

Standard library only — plus whatever lyricglow.py already uses (ytmusicapi, yt-dlp, ffmpeg).
"""
from __future__ import annotations

import hashlib
import http.cookies
import http.server
import ipaddress
import json
import mimetypes
import os
import re
import secrets
import shutil
import socketserver
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.realpath(__file__))
WEB_DIR = os.environ.get("LYRICGLOW_WEB_DIR") or os.path.join(HERE, "webplayfr")
WEB_TRIED: list = []


def find_web_dir(lg=None):
    """the site (webplayfr/) is looked for beside this file, beside lyricglow.py, in the install folders and in the current folder"""
    pre = os.environ.get("PREFIX", "")
    cands = [os.environ.get("LYRICGLOW_WEB_DIR", ""), os.path.join(HERE, "webplayfr")]
    if lg is not None and getattr(lg, "__file__", None):
        cands.append(os.path.join(os.path.dirname(os.path.realpath(lg.__file__)), "webplayfr"))
    cands += [os.path.expanduser("~/.local/share/lyricglow/webplayfr"), os.path.join(pre, "share", "lyricglow", "webplayfr") if pre else "",
              "/usr/local/share/lyricglow/webplayfr", "/usr/share/lyricglow/webplayfr", os.path.join(os.getcwd(), "webplayfr")]
    cands = list(dict.fromkeys(c for c in cands if c))
    for d in cands:
        if os.path.isfile(os.path.join(d, "index.html")):
            return d, cands
    return None, cands


def no_site_page() -> bytes:
    tried = "".join(f"<li><code>{c}</code></li>" for c in WEB_TRIED)
    return f"""<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>LyricGlow web — site files missing</title>
<style>body{{font:1rem/1.6 system-ui,sans-serif;background:#181614;color:#e4ddd2;margin:0;padding:2rem 1.25rem}}main{{max-width:40rem;margin:0 auto}}
code{{background:#2a2622;padding:.1rem .4rem;border-radius:.25rem}}pre{{background:#221f1c;padding:1rem;border-radius:.5rem;overflow:auto}}h1{{font-size:1.4rem}}li{{margin:.25rem 0}}</style>
<main><h1>The LyricGlow server is running, but the website files are missing</h1>
<p>The backend answers (<a style=color:#d3a58f href=/api/ping>/api/ping</a>), but it couldn't find the <code>webplayfr</code> folder with <code>index.html</code>.</p>
<p><b>Fix (pick one):</b></p>
<pre>cd &lt;your lyricglow folder&gt; &amp;&amp; sh install.sh      # installs the site to ~/.local/share/lyricglow/webplayfr
LYRICGLOW_WEB_DIR=/path/to/lyricglow/webplayfr lyricglow web
python3 /path/to/lyricglow/lyricglow_web.py            # run it from the folder that contains webplayfr/</pre>
<p>Places searched:</p><ul>{tried}</ul></main>""".encode()
VERSION = "1.1.0"
TS_V4 = ipaddress.ip_network("100.64.0.0/10")           # Tailscale CGNAT range
TS_V6 = ipaddress.ip_network("fd7a:115c:a1e0::/48")     # Tailscale ULA range
IMG_HOSTS = ("googleusercontent.com", "ggpht.com", "ytimg.com", "gstatic.com", "youtube.com", "scdn.co", "mzstatic.com")
MIME = {"m4a": "audio/mp4", "mp4": "audio/mp4", "webm": "audio/webm", "opus": "audio/ogg", "ogg": "audio/ogg", "mp3": "audio/mpeg",
        "aac": "audio/aac", "wav": "audio/wav"}
VIDEO_ID = re.compile(r"^[A-Za-z0-9_-]{6,24}$")


# ------------------------------------------------------------------------------------------------ helpers

def fix_art(it: dict) -> dict:
    """Every song gets artwork: if YouTube gave none, fall back to the video thumbnail (square-cropped by the UI)."""
    if it.get("kind", "song") == "song" and not it.get("art") and it.get("id"):
        it["art"] = f"https://i.ytimg.com/vi/{it['id']}/hqdefault.jpg"
    return it


def slim(it: dict) -> dict:
    keep = ("kind", "id", "title", "artist", "album", "album_id", "dur", "art", "seed")
    return {k: it[k] for k in keep if k in it and it[k] not in (None, "")}


def ttml_to_json(lg, ttml: str) -> dict:
    """Better-Lyrics TTML -> {lines:[{b,e,side,syl:[{t,b,e,bg}]}], duet}. Syllables keep their trailing spaces."""
    root = ET.fromstring(ttml.encode("utf-8"))
    lines = []
    for p in root.iter():
        if lg.local(p.tag) != "p":
            continue
        pb, pe = lg.pt(p.get("begin")), lg.pt(p.get("end"))
        syl: list = []
        lg._collect(p, False, syl)
        if not syl:
            txt = "".join(p.itertext()).strip()
            if not txt or pb is None:
                continue
            syl = [[txt, pb, pe if pe is not None else pb + 3.0, False]]
        out = []
        for i, (txt, b, e, bg) in enumerate(syl):
            if b is None:
                b = pb if pb is not None else (out[-1]["e"] if out else 0.0)
            if e is None:
                nxt = next((x[1] for x in syl[i + 1:] if x[1] is not None), None)
                e = nxt if nxt is not None else (pe if pe is not None else b + 0.3)
            out.append({"t": txt, "b": round(b, 3), "e": round(max(e, b), 3), "bg": bool(bg)})
        if not out or not "".join(s["t"] for s in out).strip():
            continue
        lines.append({"b": min(pb if pb is not None else out[0]["b"], out[0]["b"]), "e": max(pe if pe is not None else out[-1]["e"], out[-1]["e"]),
                      "agent": lg.attr(p, "agent"), "syl": out})
    if not lines:
        raise ValueError("no timed lines")
    lines.sort(key=lambda l: l["b"])
    agents = []
    for l in lines:
        a = l["agent"]
        if a and a not in agents and a not in ("v1000", "v2000"):
            agents.append(a)
    duet = len(agents) >= 2
    res, prev_end = [], 0.0
    for l in lines:
        if l["b"] - prev_end >= 6.0:
            res.append({"kind": "dots", "b": round(prev_end + 0.7, 3), "e": round(l["b"] - 0.5, 3), "syl": []})
        side = "l"
        if duet:
            side = "l" if l["agent"] == agents[0] else ("r" if l["agent"] == agents[1] else "c")
        l["side"] = side
        l.pop("agent", None)
        res.append(l)
        prev_end = max(prev_end, l["e"])
    return {"lines": res, "duet": duet}


# ------------------------------------------------------------------------------------------------ the app
class Web:
    def __init__(self, lg, cfg):
        self.lg, self.cfg = lg, cfg
        self.cache = os.path.join(lg.CACHE, "web")
        for d in ("img", "audio", "canvas"):
            os.makedirs(os.path.join(self.cache, d), exist_ok=True)
        self.conf_dir = os.path.dirname(lg.CONF)
        self.allow = {str(x).lower() for x in (cfg.web_allow or ["tailscale", "loopback"])}
        self.token = self._load_token()
        self.pool = ThreadPoolExecutor(8)
        self._resolved: dict = {}
        self._locks: dict = {}
        self._glock = threading.Lock()
        self.lyrics_cache: dict = {}
        self.canvas = lg.CanvasLoader(cfg) if (getattr(cfg, "canvas", None) and lg.np is not None) else None
        self.lib_lock = threading.Lock()
        self.lib_path = os.path.join(self.conf_dir, "web-library.json")
        self.prefs_path = os.path.join(self.conf_dir, "web-prefs.json")
        self.sem = threading.Semaphore(3)               # concurrent ffmpeg/yt-dlp jobs

    # ---- access control
    def _load_token(self) -> str:
        if str(self.cfg.web_auth).lower() != "token":
            return ""
        if self.cfg.web_token:
            return str(self.cfg.web_token)
        path = os.path.join(os.path.dirname(self.lg.CONF), "web-token")
        try:
            with open(path) as f:
                t = f.read().strip()
                if t:
                    return t
        except OSError:
            pass
        t = secrets.token_urlsafe(18)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(t)
        return t

    @staticmethod
    def net_class(addr: str) -> str:
        try:
            ip = ipaddress.ip_address(addr.split("%")[0])
        except ValueError:
            return "public"
        if getattr(ip, "ipv4_mapped", None):
            ip = ip.ipv4_mapped
        if ip.is_loopback:
            return "loopback"
        if (ip.version == 4 and ip in TS_V4) or (ip.version == 6 and ip in TS_V6):
            return "tailscale"
        if ip.is_private or ip.is_link_local:
            return "lan"
        return "public"

    def allowed(self, cls: str) -> bool:
        return "any" in self.allow or cls in self.allow or (cls == "loopback")

    # ---- per-key locks
    def lock(self, key) -> threading.Lock:
        with self._glock:
            return self._locks.setdefault(key, threading.Lock())

    # ---- yt-dlp: video id -> upstream audio URL
    def resolve(self, vid: str, fmt: str = "m4a") -> dict:
        key = (vid, fmt)
        hit = self._resolved.get(key)
        if hit and hit["exp"] > time.time():
            return hit
        with self.lock(("resolve",) + key):
            hit = self._resolved.get(key)
            if hit and hit["exp"] > time.time():
                return hit
            if not shutil.which("yt-dlp"):
                raise RuntimeError("yt-dlp is not installed (sudo pacman -S yt-dlp)")
            sel = {"m4a": "bestaudio[ext=m4a]/bestaudio", "webm": "bestaudio[ext=webm]/bestaudio"}.get(fmt, "bestaudio/best")
            cmd = ["yt-dlp", "-j", "--no-playlist", "--no-warnings", "-f", sel]
            if getattr(self.cfg, "ytm_cookies_browser", None):
                cmd += ["--cookies-from-browser", str(self.cfg.ytm_cookies_browser)]
            with self.sem:
                r = subprocess.run(cmd + [f"https://music.youtube.com/watch?v={vid}"], capture_output=True, text=True, timeout=60)
            if r.returncode != 0 or not r.stdout.strip():
                msg = (r.stderr.strip().splitlines() or ["yt-dlp failed"])[-1][:200]
                raise RuntimeError(msg)
            j = json.loads(r.stdout.strip().splitlines()[-1])
            url = j.get("url") or (j.get("requested_formats") or [{}])[0].get("url")
            if not url:
                raise RuntimeError("yt-dlp returned no URL")
            size = j.get("filesize") or j.get("filesize_approx")
            m = re.search(r"[?&]clen=(\d+)", url)
            if m:
                size = int(m.group(1))
            ext = (j.get("ext") or "m4a").lower()
            info = dict(url=url, headers=j.get("http_headers") or {}, size=int(size) if size else None, ext=ext,
                        mime=MIME.get(ext, "audio/mp4"), dur=j.get("duration"), exp=time.time() + 20 * 60)
            self._resolved[key] = info
            return info

    # ---- ffmpeg: transcode once, cache on disk, serve with Range
    def transcode(self, vid: str, mode: str, br: int, norm: bool) -> tuple[str, str]:
        ext = {"aac": "m4a", "mp3": "mp3", "opus": "ogg"}[mode]
        tag = f"{vid}.{mode}{br}{'n' if norm else ''}"
        path = os.path.join(self.cache, "audio", f"{tag}.{ext}")
        if os.path.exists(path) and os.path.getsize(path) > 1024:
            os.utime(path)
            return path, MIME[ext]
        with self.lock(("tc", tag)):
            if os.path.exists(path) and os.path.getsize(path) > 1024:
                return path, MIME[ext]
            if not shutil.which("ffmpeg"):
                raise RuntimeError("ffmpeg is not installed (sudo pacman -S ffmpeg)")
            info = self.resolve(vid, "any")
            hdr = "".join(f"{k}: {v}\r\n" for k, v in info["headers"].items())
            cmd = ["ffmpeg", "-v", "error", "-nostdin", "-y", "-headers", hdr, "-i", info["url"], "-vn", "-map_metadata", "-1"]
            if norm:
                cmd += ["-af", "loudnorm=I=-14:TP=-1.5:LRA=11"]
            cmd += {"aac": ["-c:a", "aac", "-b:a", f"{br}k", "-f", "mp4", "-movflags", "+faststart"],
                    "mp3": ["-c:a", "libmp3lame", "-b:a", f"{br}k", "-f", "mp3"],
                    "opus": ["-c:a", "libopus", "-b:a", f"{br}k", "-f", "ogg"]}[mode]
            tmp = path + ".part"
            with self.sem:
                r = subprocess.run(cmd + [tmp], capture_output=True, timeout=300)
            if r.returncode != 0 or not os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass
                raise RuntimeError("ffmpeg failed: " + r.stderr.decode("utf-8", "ignore")[-160:])
            os.replace(tmp, path)
            self._trim_cache()
            return path, MIME[ext]

    def _trim_cache(self):
        limit = int(getattr(self.cfg, "web_cache_mb", 2048)) * 1024 * 1024
        d = os.path.join(self.cache, "audio")
        files = [(os.path.getatime(p), os.path.getsize(p), p) for p in (os.path.join(d, f) for f in os.listdir(d)) if os.path.isfile(p)]
        total = sum(s for _, s, _ in files)
        for _, s, p in sorted(files):
            if total <= limit:
                break
            try:
                os.remove(p)
                total -= s
            except OSError:
                pass

    # ---- ytmusicapi
    def api(self):
        try:
            return self.lg.ACCOUNT.api()
        except ImportError:
            raise RuntimeError("ytmusicapi is not installed — pip install ytmusicapi")

    def songs(self, tracks, album="", art="", album_id="") -> list[dict]:
        out = []
        for it in self.lg.tracks_to_items(tracks, album, art):
            if album_id:
                it["album_id"] = album_id
            out.append(slim(fix_art(it)))
        return out

    def home(self) -> list[dict]:
        lg = self.lg
        shelves = []
        for s in self.api().get_home(limit=14) or []:
            items = [slim(fix_art(e)) for e in (lg.norm_entry(c) for c in s.get("contents", [])) if e]
            if not items:
                continue
            songs = sum(1 for i in items if i.get("kind", "song") == "song")
            shelves.append({"title": s.get("title") or "", "layout": "songs" if songs > len(items) / 2 else "cards", "items": items})
        return shelves

    def search(self, q: str, kind: str) -> list[dict]:
        lg = self.lg
        if kind == "songs":
            try:
                res = lg.search_ytm(q, 24, "songs")
            except RuntimeError:
                raise
            return [slim(fix_art(dict(r, kind="song"))) for r in res]
        return [slim(r) for r in lg.search_ytm(q, 24, kind)]

    def detail(self, kind: str, ident: str, title: str = "") -> dict:
        lg, api = self.lg, self.api()
        if kind == "album":
            a = api.get_album(ident)
            art = lg._best_thumb(a.get("thumbnails"))
            artists = ", ".join(x.get("name", "") for x in (a.get("artists") or []) if isinstance(x, dict))
            tracks = self.songs(a.get("tracks"), a.get("title", title), art, ident)
            return dict(kind="album", id=ident, title=a.get("title", title), subtitle=artists, year=a.get("year"), art=art,
                        tracks=tracks, count=len(tracks), kicker="Album")
        if kind == "artist":
            a = api.get_artist(ident)
            songs = a.get("songs") or {}
            tr = songs.get("results")
            if songs.get("browseId"):
                try:
                    tr = api.get_playlist(songs["browseId"], limit=100).get("tracks") or tr
                except Exception:
                    pass
            return dict(kind="artist", id=ident, title=a.get("name") or title, subtitle="Artist", art=lg._best_thumb(a.get("thumbnails")),
                        tracks=self.songs(tr), kicker="Artist")
        if kind == "radio":
            if ident == "SEED":
                return dict(kind="radio", id=ident, title=title or "Radio", subtitle="Songs like this", art="", tracks=self.related(title), kicker="Radio")
            tr = api.get_watch_playlist(playlistId=ident, limit=60).get("tracks")
            return dict(kind="radio", id=ident, title=title or "Radio", subtitle="Radio", art="", tracks=self.songs(tr), kicker="Radio")
        if ident == "LM":
            lg.ACCOUNT.need_auth()
            tr = api.get_liked_songs(limit=500).get("tracks")
            return dict(kind="playlist", id=ident, title="Liked Music", subtitle="Your YouTube Music likes", art="", tracks=self.songs(tr), kicker="Playlist")
        if ident == "HISTORY":
            lg.ACCOUNT.need_auth()
            return dict(kind="playlist", id=ident, title="History", subtitle="Recently played on YouTube Music", art="", tracks=self.songs(api.get_history()), kicker="Playlist")
        p = api.get_playlist(ident, limit=300)
        art = lg._best_thumb(p.get("thumbnails"))
        author = p.get("author")
        who = author.get("name", "") if isinstance(author, dict) else (author or "")
        return dict(kind="playlist", id=ident, title=p.get("title", title), subtitle=who, art=art, tracks=self.songs(p.get("tracks"), art=""),
                    year=p.get("year"), description=(p.get("description") or "")[:300], kicker="Playlist")

    def related(self, vid: str) -> list[dict]:
        return [slim(fix_art(it)) for it in self.lg.related_ytm(vid, 30)]

    def library(self, kind: str) -> list[dict]:
        return [slim(fix_art(e)) for e in self.lg.load_library(kind)]

    # ---- lyrics + animated cover
    def lyrics(self, title: str, artist: str, album: str, dur: float | None) -> dict:
        lg = self.lg
        key = (title.lower(), artist.lower(), album.lower())
        if key in self.lyrics_cache:
            return self.lyrics_cache[key]
        tr = lg.make_track(title, artist, album, dur)
        if not tr:
            return {"lines": None}
        apis = self.cfg.api if isinstance(self.cfg.api, list) and self.cfg.api else lg.DEFAULT_APIS
        try:
            res = ttml_to_json(lg, lg.fetch_ttml(tr, apis))
        except Exception as e:
            res = {"lines": None, "error": str(e)[:120]}
        if len(self.lyrics_cache) > 400:
            self.lyrics_cache.clear()
        self.lyrics_cache[key] = res
        return res

    def canvas_url(self, title: str, artist: str, album: str, vid: str) -> str | None:
        lg = self.lg
        if not self.canvas:
            return None
        tr = lg.make_track(title, artist, album, None, "", f"https://music.youtube.com/watch?v={vid}")
        if not tr:
            return None
        key = hashlib.sha1((tr.key + ",".join(self.canvas.sources)).encode()).hexdigest()[:20]
        out = os.path.join(self.cache, "canvas", key + ".mp4")
        neg = os.path.join(self.cache, "canvas", key + ".none")
        if os.path.exists(out):
            return f"/media/canvas/{key}.mp4"
        if os.path.exists(neg) and time.time() - os.path.getmtime(neg) < 3 * 86400:
            return None
        with self.lock(("canvas", key)):
            if os.path.exists(out):
                return f"/media/canvas/{key}.mp4"
            _, loc = self.canvas.resolve(tr)
            if not loc or not shutil.which("ffmpeg"):
                open(neg, "w").close()
                return None
            codec = ["-c:v", "libvpx-vp9", "-b:v", "0", "-crf", "36", "-row-mt", "1"] if str(getattr(self.cfg, "web_canvas_codec", "h264")) == "vp9" \
                else ["-c:v", "libx264", "-preset", "veryfast", "-crf", "28", "-pix_fmt", "yuv420p", "-movflags", "+faststart"]
            net = ["-user_agent", self.lg.UA] if str(loc).startswith("http") else []
            cmd = ["ffmpeg", "-v", "error", "-nostdin", "-y", *net, "-i", str(loc), "-an", "-t", "8",
                   "-vf", "crop='min(iw,ih)':'min(iw,ih)',scale=480:480:flags=lanczos,fps=24", *codec]
            tmp = out + ".part.mp4"
            if str(getattr(self.cfg, "web_canvas_codec", "h264")) == "vp9":
                tmp = out + ".part.webm"
                cmd += ["-f", "webm"]
            with self.sem:
                r = subprocess.run(cmd + [tmp], capture_output=True, timeout=180)
            if r.returncode != 0 or not os.path.exists(tmp):
                open(neg, "w").close()
                return None
            os.replace(tmp, out)
            return f"/media/canvas/{key}.mp4"

    # ---- local library (works with no account)
    def _lib(self) -> dict:
        try:
            with open(self.lib_path) as f:
                d = json.load(f)
        except (OSError, ValueError):
            d = {}
        d.setdefault("liked", [])
        d.setdefault("playlists", [])
        return d

    def _save_lib(self, d: dict):
        os.makedirs(self.conf_dir, exist_ok=True)
        tmp = self.lib_path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(d, f)
        os.replace(tmp, self.lib_path)

    def lib_edit(self, fn):
        with self.lib_lock:
            d = self._lib()
            res = fn(d)
            self._save_lib(d)
            return res

    def prefs(self, new=None):
        if new is None:
            try:
                with open(self.prefs_path) as f:
                    return json.load(f)
            except (OSError, ValueError):
                return {}
        os.makedirs(self.conf_dir, exist_ok=True)
        with open(self.prefs_path, "w") as f:
            json.dump(new, f)
        return new

    # ---- images
    def image(self, url: str) -> tuple[bytes, str]:
        u = urllib.parse.urlparse(url)
        host = (u.hostname or "").lower()
        if u.scheme != "https" or not any(host == h or host.endswith("." + h) for h in IMG_HOSTS):
            raise PermissionError("image host not allowed")
        key = hashlib.sha1(url.encode()).hexdigest()
        path = os.path.join(self.cache, "img", key)
        if os.path.exists(path) and os.path.exists(path + ".t"):
            with open(path, "rb") as f, open(path + ".t") as t:
                return f.read(), t.read().strip() or "image/jpeg"
        req = urllib.request.Request(url, headers={"User-Agent": self.lg.UA, "Accept": "image/*"})
        with urllib.request.urlopen(req, timeout=12) as r:
            data = r.read(6_000_000)
            ctype = r.headers.get("Content-Type", "image/jpeg").split(";")[0]
        if not ctype.startswith("image/"):
            raise ValueError("not an image")
        with open(path, "wb") as f:
            f.write(data)
        with open(path + ".t", "w") as f:
            f.write(ctype)
        return data, ctype

    # ---- account (acts on the SERVER's browser, i.e. your laptop)
    def account(self) -> dict:
        lg = self.lg
        out = {"signed_in": lg.ACCOUNT.signed_in, "ytmusicapi": True, "name": None}
        try:
            import ytmusicapi  # noqa: F401
        except ImportError:
            out["ytmusicapi"] = False
            return out
        if out["signed_in"]:
            try:
                out["name"] = lg.ACCOUNT.api().get_account_info().get("accountName")
            except Exception as e:
                out["error"] = str(e)[:100]
        return out


# ------------------------------------------------------------------------------------------------ HTTP
def make_handler(web: Web):
    lg, cfg = web.lg, web.cfg
    use_token = bool(web.token)

    class H(http.server.BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        server_version = "lyricglow-web/" + VERSION

        def log_message(self, fmt, *a):
            if getattr(cfg, "debug", False):
                sys.stderr.write("[web] " + fmt % a + "\n")

        # ---- plumbing
        def send_json(self, obj, status=200, headers=None):
            body = json.dumps(obj, separators=(",", ":")).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            for k, v in (headers or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)

        def err(self, status, code, msg=""):
            self.send_json({"error": code, "message": msg}, status)

        def body_json(self, limit=2_000_000):
            n = int(self.headers.get("Content-Length") or 0)
            if n > limit:
                raise ValueError("body too large")
            raw = self.rfile.read(n) if n else b""
            return json.loads(raw or b"{}")

        def cookies(self):
            c = http.cookies.SimpleCookie()
            try:
                c.load(self.headers.get("Cookie", ""))
            except http.cookies.CookieError:
                pass
            return c

        def funnel(self) -> bool:
            return bool(self.headers.get("Tailscale-Funnel-Request"))

        def authed(self) -> bool:
            if not (use_token or self.funnel()):
                return True
            if not web.token:
                return False                      # Funnel (public) with auth disabled is never allowed
            ck = self.cookies().get("lg_token")
            got = self.headers.get("X-LG-Token") or (self._q.get("t") or [""])[0] or (ck.value if ck else "")
            return secrets.compare_digest(str(got), web.token)

        # ---- CORS: lets a static site (python -m http.server on another port) use this backend
        _q: dict = {}

        def cors_headers(self) -> dict:
            origin = self.headers.get("Origin")
            if not origin:
                return {}
            host = (urllib.parse.urlparse(origin).hostname or "").lower()
            allow = [str(x) for x in (getattr(cfg, "web_cors", None) or [])]
            ok = origin in allow or (("*" in allow) and (bool(web.token) or host in ("localhost", "127.0.0.1", "::1")))
            if not ok:
                return {}
            return {"Access-Control-Allow-Origin": origin, "Vary": "Origin", "Access-Control-Allow-Headers": "Content-Type, X-LG-Token, Range",
                    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, HEAD, OPTIONS", "Access-Control-Expose-Headers": "Content-Range, Accept-Ranges, Content-Length",
                    "Access-Control-Max-Age": "600"}

        def end_headers(self):
            sent = {k.lower() for k in getattr(self, "_hdr_sent", [])}
            for k, v in self.cors_headers().items():
                if k.lower() not in sent:
                    super().send_header(k, v)
            super().end_headers()
            self._hdr_sent = []

        def send_header(self, k, v):
            self._hdr_sent = getattr(self, "_hdr_sent", []) + [k]
            super().send_header(k, v)

        # ---- entry
        def do_GET(self): self.route("GET")
        def do_HEAD(self): self.route("HEAD")
        def do_POST(self): self.route("POST")
        def do_PUT(self): self.route("PUT")
        def do_DELETE(self): self.route("DELETE")

        def do_OPTIONS(self):
            self._q = {}
            self.send_response(204)
            self.send_header("Content-Length", "0")
            self.end_headers()

        def route(self, method):
            u = urllib.parse.urlparse(self.path)
            path, q = urllib.parse.unquote(u.path), urllib.parse.parse_qs(u.query)
            self._q = q
            try:
                cls = web.net_class(self.client_address[0])
                if not web.allowed(cls):
                    return self.err(403, "network_not_allowed", f"clients from '{cls}' networks are not allowed (see [web] allow)")
                if self.funnel() and not web.token:
                    return self.err(403, "funnel_needs_token", "Tailscale Funnel exposes this to the internet: set [web] auth = \"token\"")
                # one-time sign-in link:  /?token=XXXX  -> cookie, then clean URL
                if method == "GET" and q.get("token") and web.token and secrets.compare_digest(q["token"][0], web.token):
                    clean = urllib.parse.urlencode([(k, v) for k, vs in q.items() if k != "token" for v in vs])
                    self.send_response(302)
                    self.send_header("Set-Cookie", f"lg_token={web.token}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Lax")
                    self.send_header("Location", path + ("?" + clean if clean else ""))
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                if method in ("GET", "HEAD") and not path.startswith(("/api/", "/stream/", "/media/")):
                    return self.static(path)
                if path == "/api/ping":
                    return self.send_json({"app": "lyricglow-web", "version": VERSION, "auth_required": bool(use_token or self.funnel()), "authed": self.authed()})
                if path == "/api/auth" and method == "POST":
                    b = self.body_json()
                    if web.token and secrets.compare_digest(str(b.get("token", "")), web.token):
                        return self.send_json({"ok": True}, headers={"Set-Cookie": f"lg_token={web.token}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Lax"})
                    return self.err(401, "bad_token", "wrong token")
                if not self.authed():
                    return self.err(401, "token_required", "open the sign-in link printed by `lyricglow web`, or enter the token")
                self.dispatch(method, path, q, cls)
            except (BrokenPipeError, ConnectionResetError):
                pass
            except PermissionError as e:
                self.err(403, "signin_required", str(e))
            except RuntimeError as e:
                self.err(501, "unavailable", str(e))
            except Exception as e:                # never kill the server thread
                lg.log(f"web {method} {path}: {e!r}")
                try:
                    self.err(500, "server_error", str(e)[:200])
                except Exception:
                    pass

        # ---- static
        def static(self, path):
            if not WEB_DIR:                                           # no site anywhere: explain, don't crash (a crash looks like "Bad Gateway" behind a proxy)
                data = no_site_page()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                if self.command != "HEAD":
                    self.wfile.write(data)
                return
            if path in ("", "/"):
                path = "/index.html"
            rel = os.path.normpath(path.lstrip("/"))
            full = os.path.realpath(os.path.join(WEB_DIR, rel))
            if not full.startswith(os.path.realpath(WEB_DIR) + os.sep) or not os.path.isfile(full):
                if "." not in os.path.basename(path):                      # SPA fallback for deep links
                    full = os.path.join(WEB_DIR, "index.html")
                else:
                    return self.err(404, "not_found", path)
            try:
                st = os.stat(full)
            except OSError:
                return self.err(404, "not_found", os.path.basename(full))
            etag = f'"{st.st_mtime_ns:x}-{st.st_size:x}"'
            if self.headers.get("If-None-Match") == etag:
                self.send_response(304)
                self.send_header("ETag", etag)
                self.send_header("Content-Length", "0")
                return self.end_headers()
            ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
            if full.endswith(".js"):
                ctype = "text/javascript"
            elif full.endswith(".webmanifest"):
                ctype = "application/manifest+json"
            with open(full, "rb") as f:
                data = f.read()
            self.send_response(200)
            self.send_header("Content-Type", ctype + ("; charset=utf-8" if ctype.startswith(("text/", "application/json")) else ""))
            self.send_header("Content-Length", str(len(data)))
            self.send_header("ETag", etag)
            self.send_header("Cache-Control", "no-cache")
            if full.endswith("sw.js"):
                self.send_header("Service-Worker-Allowed", "/")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(data)

        # ---- file with Range support (cached transcodes, animated covers)
        def serve_file(self, path, mime, cache="no-store"):
            size = os.path.getsize(path)
            start, end, status = 0, size - 1, 200
            rng = self.headers.get("Range")
            if rng:
                m = re.match(r"bytes=(\d*)-(\d*)", rng)
                if m:
                    a, b = m.groups()
                    if a == "" and b:
                        start = max(0, size - int(b))
                    elif a:
                        start = int(a)
                        end = min(int(b), size - 1) if b else size - 1
                    if start > end or start >= size:
                        self.send_response(416)
                        self.send_header("Content-Range", f"bytes */{size}")
                        self.send_header("Content-Length", "0")
                        return self.end_headers()
                    status = 206
            self.send_response(status)
            self.send_header("Content-Type", mime)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(end - start + 1))
            self.send_header("Cache-Control", cache)
            if status == 206:
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            self.end_headers()
            if self.command == "HEAD":
                return
            with open(path, "rb") as f:
                f.seek(start)
                left = end - start + 1
                while left > 0:
                    chunk = f.read(min(65536, left))
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    left -= len(chunk)

        # ---- direct audio proxy (yt-dlp URL -> browser), chunked ranges like yt-dlp does
        def proxy_audio(self, vid, fmt):
            for attempt in (0, 1):
                info = web.resolve(vid, fmt)
                size = info["size"]
                if not size:
                    try:
                        req = urllib.request.Request(info["url"], headers={**info["headers"], "Range": "bytes=0-0"})
                        with urllib.request.urlopen(req, timeout=15) as r:
                            cr = r.headers.get("Content-Range", "")
                            size = int(cr.rsplit("/", 1)[1]) if "/" in cr else None
                    except Exception:
                        size = None
                if not size:
                    raise RuntimeError("could not determine the audio size")
                start, end, status = 0, size - 1, 200
                rng = self.headers.get("Range")
                if rng:
                    m = re.match(r"bytes=(\d*)-(\d*)", rng)
                    if m:
                        a, b = m.groups()
                        if a == "" and b:
                            start = max(0, size - int(b))
                        elif a:
                            start = int(a)
                            end = min(int(b), size - 1) if b else size - 1
                        status = 206
                        if start > end or start >= size:
                            self.send_response(416)
                            self.send_header("Content-Range", f"bytes */{size}")
                            self.send_header("Content-Length", "0")
                            return self.end_headers()
                # open the first upstream chunk BEFORE sending headers, so an expired URL can be re-resolved
                chunk = 2 * 1024 * 1024
                try:
                    first_end = min(end, start + chunk - 1)
                    up = urllib.request.urlopen(urllib.request.Request(info["url"], headers={**info["headers"], "Range": f"bytes={start}-{first_end}"}), timeout=20)
                except urllib.error.HTTPError as e:
                    if attempt == 0 and e.code in (403, 404, 410):
                        web._resolved.pop((vid, fmt), None)
                        continue
                    raise RuntimeError(f"YouTube refused the stream (HTTP {e.code}) — update yt-dlp")
                break
            self.send_response(status)
            self.send_header("Content-Type", info["mime"])
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(end - start + 1))
            self.send_header("Cache-Control", "no-store")
            if status == 206:
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            self.end_headers()
            if self.command == "HEAD":
                up.close()
                return
            pos = start
            try:
                while pos <= end:
                    with up:
                        while True:
                            data = up.read(65536)
                            if not data:
                                break
                            self.wfile.write(data)
                            pos += len(data)
                    if pos > end:
                        break
                    nxt = min(end, pos + chunk - 1)
                    up = urllib.request.urlopen(urllib.request.Request(info["url"], headers={**info["headers"], "Range": f"bytes={pos}-{nxt}"}), timeout=20)
            except (BrokenPipeError, ConnectionResetError):
                pass

        # ---- API
        def dispatch(self, method, path, q, cls):
            g = lambda k, d="": (q.get(k) or [d])[0]
            if path.startswith("/stream/"):
                vid = path[len("/stream/"):]
                if not VIDEO_ID.match(vid):
                    return self.err(400, "bad_id")
                mode = g("mode", str(getattr(cfg, "web_stream_mode", "direct"))).lower()
                if mode == "direct":
                    return self.proxy_audio(vid, g("fmt", "m4a"))
                if mode not in ("aac", "mp3", "opus"):
                    return self.err(400, "bad_mode")
                br = max(32, min(320, int(g("br", str(getattr(cfg, "web_bitrate", 160))) or 160)))
                p, mime = web.transcode(vid, mode, br, g("norm", "0") == "1")
                return self.serve_file(p, mime)
            if path.startswith("/media/canvas/"):
                name = os.path.basename(path)
                p = os.path.join(web.cache, "canvas", name)
                if not re.fullmatch(r"[0-9a-f]{20}\.mp4", name) or not os.path.exists(p):
                    return self.err(404, "not_found")
                return self.serve_file(p, "video/webm" if str(getattr(cfg, "web_canvas_codec", "h264")) == "vp9" else "video/mp4", "public, max-age=86400")
            if method == "GET":
                if path == "/api/info":
                    return self.send_json({"version": VERSION, "app_version": lg.VERSION, "account": web.account(), "ytdlp": bool(shutil.which("yt-dlp")),
                                           "ffmpeg": bool(shutil.which("ffmpeg")), "canvas": bool(web.canvas), "canvas_sources": (web.canvas.sources if web.canvas else []),
                                           "stream_mode": getattr(cfg, "web_stream_mode", "direct"), "net": cls, "token": bool(web.token),
                                           "can_manage_account": bool(cls == "loopback" or web.token)})
                if path == "/api/home":
                    return self.send_json({"shelves": web.home()})
                if path == "/api/search":
                    text = g("q").strip()
                    if not text:
                        return self.send_json({"songs": [], "albums": [], "playlists": []})
                    kind = g("type", "all")
                    if kind != "all":
                        return self.send_json({kind: web.search(text, kind)})
                    futs = {k: web.pool.submit(web.search, text, k) for k in ("songs", "albums", "artists", "playlists")}
                    out = {}
                    for k, f in futs.items():
                        try:
                            out[k] = f.result(timeout=30)
                        except Exception as e:
                            out[k] = []
                            out.setdefault("errors", {})[k] = str(e)[:100]
                    return self.send_json(out)
                if path == "/api/suggest":
                    try:
                        return self.send_json({"items": (web.api().get_search_suggestions(g("q")) or [])[:8]})
                    except Exception:
                        return self.send_json({"items": []})
                if path == "/api/detail":
                    return self.send_json(web.detail(g("kind"), g("id"), g("title")))
                if path == "/api/radio":
                    vid = g("id")
                    if not VIDEO_ID.match(vid):
                        return self.err(400, "bad_id")
                    return self.send_json({"tracks": web.related(vid)})
                if path == "/api/library":
                    return self.send_json({"items": web.library(g("kind", "playlists"))})
                if path == "/api/lyrics":
                    d = g("dur")
                    return self.send_json(web.lyrics(g("title"), g("artist"), g("album"), float(d) if d else None))
                if path == "/api/canvas":
                    return self.send_json({"url": web.canvas_url(g("title"), g("artist"), g("album"), g("id"))})
                if path == "/api/img":
                    data, ctype = web.image(g("u"))
                    self.send_response(200)
                    self.send_header("Content-Type", ctype)
                    self.send_header("Content-Length", str(len(data)))
                    self.send_header("Cache-Control", "public, max-age=604800, immutable")
                    self.end_headers()
                    if self.command != "HEAD":
                        self.wfile.write(data)
                    return
                if path == "/api/my":
                    return self.send_json(web.lib_edit(lambda d: d))
                if path == "/api/prefs":
                    return self.send_json(web.prefs())
                if path == "/api/account":
                    return self.send_json(web.account())
            if method == "PUT" and path == "/api/prefs":
                return self.send_json(web.prefs(self.body_json(65536)))
            if method == "POST":
                b = self.body_json()
                if path == "/api/prefetch":
                    mode = str(b.get("mode") or "direct")
                    for vid in [v for v in (b.get("ids") or [])[:3] if VIDEO_ID.match(str(v))]:
                        if mode == "direct":
                            web.pool.submit(lambda v=vid: web.resolve(v, b.get("fmt", "m4a")))
                        elif mode in ("aac", "mp3", "opus"):
                            web.pool.submit(lambda v=vid: web.transcode(v, mode, int(b.get("br", 160)), bool(b.get("norm"))))
                    return self.send_json({"ok": True})
                if path == "/api/like":
                    return self.send_json(self.like(b))
                if path == "/api/my/playlists":
                    return self.send_json(self.pl_create(b))
                m = re.fullmatch(r"/api/my/playlists/([\w-]+)/tracks", path)
                if m:
                    return self.send_json(self.pl_tracks(m.group(1), b))
                if path.startswith("/api/account/"):
                    return self.account_post(path.rsplit("/", 1)[1], b, cls)
            m = re.fullmatch(r"/api/my/playlists/([\w-]+)", path)
            if m and method in ("PUT", "DELETE"):
                return self.send_json(self.pl_edit(m.group(1), method, self.body_json() if method == "PUT" else {}))
            self.err(404, "not_found", path)

        # ---- local library mutations
        def like(self, b):
            t = slim(b.get("track") or {})
            if not t.get("id"):
                raise ValueError("track.id required")
            liked = bool(b.get("liked"))

            def edit(d):
                d["liked"] = [x for x in d["liked"] if x.get("id") != t["id"]]
                if liked:
                    d["liked"].insert(0, t)
                return {"liked": liked, "count": len(d["liked"])}

            res = web.lib_edit(edit)
            if b.get("sync") and lg.ACCOUNT.signed_in:                    # also like it on YouTube Music (best effort, background)
                web.pool.submit(lambda: web.api().rate_song(t["id"], "LIKE" if liked else "INDIFFERENT"))
            return res

        def pl_create(self, b):
            name = str(b.get("name") or "New playlist").strip()[:80] or "New playlist"
            pl = {"id": secrets.token_hex(5), "name": name, "created": int(time.time()), "tracks": [slim(t) for t in (b.get("tracks") or [])[:500]]}
            web.lib_edit(lambda d: d["playlists"].append(pl))
            return pl

        def pl_edit(self, pid, method, b):
            def edit(d):
                pl = next((p for p in d["playlists"] if p["id"] == pid), None)
                if not pl:
                    raise ValueError("no such playlist")
                if method == "DELETE":
                    d["playlists"].remove(pl)
                    return {"deleted": pid}
                if b.get("name"):
                    pl["name"] = str(b["name"]).strip()[:80]
                return pl

            return web.lib_edit(edit)

        def pl_tracks(self, pid, b):
            def edit(d):
                pl = next((p for p in d["playlists"] if p["id"] == pid), None)
                if not pl:
                    raise ValueError("no such playlist")
                op = b.get("op", "add")
                if op == "add":
                    have = {t["id"] for t in pl["tracks"]}
                    pl["tracks"] += [slim(t) for t in (b.get("tracks") or []) if slim(t).get("id") not in have]
                elif op == "remove":
                    pl["tracks"] = [t for t in pl["tracks"] if t["id"] != b.get("id")]
                elif op == "set":                                        # reorder
                    by = {t["id"]: t for t in pl["tracks"]}
                    pl["tracks"] = [by[i] for i in (b.get("order") or []) if i in by]
                return pl

            return web.lib_edit(edit)

        # ---- account
        def account_post(self, action, b, cls):
            if not (cls == "loopback" or web.token):
                return self.err(403, "forbidden", "enable [web] auth = \"token\" to manage the account from another device")
            if action == "login":
                try:
                    name, browser = lg.bind_account(cfg)
                    return self.send_json({"ok": True, "name": name, "browser": browser})
                except lg.LoginError as e:
                    return self.send_json({"ok": False, "message": str(e)})
            if action == "logout":
                if lg.ACCOUNT.signed_in:
                    os.remove(lg.ACCOUNT.auth)
                lg.ACCOUNT._api = None
                return self.send_json({"ok": True})
            if action == "manual":
                raw = str(b.get("headers", ""))
                if "cookie" not in raw.lower():
                    return self.send_json({"ok": False, "message": "no Cookie line found"})
                import ytmusicapi
                os.makedirs(os.path.dirname(lg.ACCOUNT.auth), exist_ok=True)
                ytmusicapi.setup(filepath=lg.ACCOUNT.auth, headers_raw=raw)
                os.chmod(lg.ACCOUNT.auth, 0o600)
                lg.ACCOUNT._api = None
                try:
                    lg.ACCOUNT.api().get_library_playlists(limit=1)
                except Exception as e:
                    return self.send_json({"ok": False, "message": f"saved, but rejected: {e}"})
                return self.send_json({"ok": True})
            return self.err(404, "not_found")

    return H


class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True
    request_queue_size = 64


# ------------------------------------------------------------------------------------------------ run
def tailscale_info():
    exe = shutil.which("tailscale")
    if not exe:
        return None
    try:
        j = json.loads(subprocess.run([exe, "status", "--json"], capture_output=True, text=True, timeout=6).stdout)
        me = j.get("Self") or {}
        return {"dns": (me.get("DNSName") or "").rstrip("."), "ips": me.get("TailscaleIPs") or [], "https": bool(j.get("CertDomains"))}
    except Exception:
        return None


def serve(cfg, lg):
    web = Web(lg, cfg)
    host = str(cfg.web_host)
    bind = "0.0.0.0" if host in ("auto", "") else host
    port = int(cfg.web_port)
    srv = Server((bind, port), make_handler(web))
    ts = tailscale_info()
    tok = f"?token={web.token}" if web.token else ""
    print(f"\n\x1b[1mlyricglow web {VERSION}\x1b[0m   (network access: {sorted(web.allow)}, auth: {'token' if web.token else 'none'})\n")
    print(f"  on this computer :  http://127.0.0.1:{port}/{tok}")
    if ts and ts["ips"]:
        v4 = next((i for i in ts["ips"] if ":" not in i), ts["ips"][0])
        print(f"  over Tailscale   :  http://{v4}:{port}/{tok}")
        if ts["dns"]:
            print(f"                      http://{ts['dns']}:{port}/{tok}")
        print(f"\n  \x1b[2mHTTPS (needed to install it as an app on your phone):\x1b[0m")
        print(f"    tailscale serve --bg {port}" + ("" if ts["https"] else "      # first enable HTTPS in the Tailscale admin console (DNS → HTTPS Certificates)"))
        if ts["dns"]:
            print(f"    then open  https://{ts['dns']}/{tok}")
    else:
        print("  Tailscale not detected — install it (https://tailscale.com/download) and run `tailscale up`, or use the LAN address with allow = [\"lan\"].")
    if not shutil.which("yt-dlp"):
        print("\n  \x1b[33m! yt-dlp not found\x1b[0m — playback needs it (sudo pacman -S yt-dlp)")
    if not shutil.which("ffmpeg"):
        print("  \x1b[33m! ffmpeg not found\x1b[0m — transcoding / animated covers need it (sudo pacman -S ffmpeg)")
    print("\n  Ctrl+C to stop.\n")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()


if __name__ == "__main__":
    # python3 lyricglow_web.py [--port 9000 --no-auth …]   ==   lyricglow web [...]
    sys.path.insert(0, HERE)
    import lyricglow as _lg
    sys.argv.insert(1, "web")
    _lg.main()
