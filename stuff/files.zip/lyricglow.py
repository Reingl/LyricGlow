#!/usr/bin/env python3
"""
lyricglow — a YouTube Music app for your terminal: synced word-by-word lyrics, animated covers, Discord presence.

  lyricglow ytm [search]      the player: Quick picks, Albums, Radios, Playlists, Search, Queue  (TAB switches views)
  lyricglow ytm login         sign in with your browser's YouTube login (or press  l  inside the app)
  lyricglow                   lyrics for whatever is already playing (MPRIS / mpv / Android)
  lyricglow doctor            diagnose players, terminal, account, Discord
  lyricglow --demo            preview, no player needed

  * syllable-synced lyrics from the Better Lyrics API
  * kitty: pixel renderer — real typography, depth blur, glow styles, animated album cover, 60/120 fps motion
  * every other terminal + Termux: truecolor cell renderer, plus a low-end mode for weak machines
  * ad-free: audio streams come straight from yt-dlp through mpv
"""
from __future__ import annotations

import argparse
import base64
import bisect
import colorsys
import configparser
import fcntl
import hashlib
import heapq
import io
import json
import math
import os
import re
import select
import glob
import random
import shlex
import shutil
import signal
import socket
import sqlite3
import stat
import struct
import subprocess
import sys
import tempfile
import termios
import threading
import types
import uuid
from concurrent.futures import ThreadPoolExecutor
import time
import unicodedata
import zlib
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field

try:                      # numpy + Pillow are optional: they unlock the pixel-perfect kitty renderer
    import numpy as np
except Exception:
    np = None

try:
    from PIL import Image, ImageDraw, ImageFilter, ImageFont
except Exception:
    Image = ImageDraw = ImageFilter = ImageFont = None

try:
    import tomllib
except Exception:
    tomllib = None

VERSION = "4.0.0"
DEFAULT_APIS = ["https://lyrics-api.boidu.dev", "https://api.betterlyrics.org"]
UA = "lyricglow/1.0 (terminal lyrics widget)"
CACHE = os.path.join(os.environ.get("XDG_CACHE_HOME", os.path.expanduser("~/.cache")), "lyricglow")
CONF = os.path.join(os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")), "lyricglow", "config.toml")
IS_TERMUX = "com.termux" in os.environ.get("PREFIX", "") or os.path.isdir("/data/data/com.termux")
GROUP_AGENTS = {"v1000", "v2000"}


def log(msg: str) -> None:
    try:
        os.makedirs(CACHE, exist_ok=True)
        with open(os.path.join(CACHE, "log.txt"), "a") as f:
            f.write(time.strftime("%H:%M:%S ") + msg + "\n")
    except Exception:
        pass


# --------------------------------------------------------------------------- colour

WHITE = (255.0, 250.0, 244.0)


def clamp(x, lo=0.0, hi=1.0):
    return lo if x < lo else hi if x > hi else x


def mix(a, b, t):
    return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t)


def lum(c):
    return 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]


def desat(c, amt):
    g = lum(c)
    return mix(c, (g, g, g), amt)


def hsl(h, s, l):
    r, g, b = colorsys.hls_to_rgb(h % 1.0, clamp(l), clamp(s))
    return (r * 255.0, g * 255.0, b * 255.0)


def to_hsl(c):
    h, l, s = colorsys.rgb_to_hls(c[0] / 255.0, c[1] / 255.0, c[2] / 255.0)
    return h, s, l


def pk(c):
    return (min(255, max(0, int(c[0]))) << 16) | (min(255, max(0, int(c[1]))) << 8) | min(255, max(0, int(c[2])))


@dataclass
class Palette:
    a: tuple      # main vivid accent
    b: tuple      # secondary accent
    deep: tuple   # very dark background tone

    def lerp(self, o: "Palette", t: float) -> "Palette":
        return Palette(mix(self.a, o.a, t), mix(self.b, o.b, t), mix(self.deep, o.deep, t))


def make_palette(h1: float, s1: float, h2: float, s2: float | None = None) -> Palette:
    s2 = s1 if s2 is None else s2
    a = hsl(h1, clamp(s1, 0.0, 0.95), 0.67)
    b = hsl(h2, clamp(s2, 0.0, 0.95), 0.62)
    deep = hsl(h1, 0.45, 0.045)
    return Palette(a, b, deep)


def fallback_palette(seed: str) -> Palette:
    n = int(hashlib.sha1(seed.encode("utf-8", "ignore")).hexdigest()[:8], 16)
    h = (n % 360) / 360.0
    return make_palette(h, 0.72, h + 0.09)


DEFAULT_PALETTE = make_palette(0.60, 0.70, 0.74)


def palette_from_image(img) -> Palette:
    small = img.convert("RGB").resize((40, 40))
    data = small.tobytes()
    buckets: dict[int, list] = {}
    all_r = all_g = all_b = 0
    n = 0
    for i in range(0, len(data), 3):
        r, g, b = data[i], data[i + 1], data[i + 2]
        all_r += r; all_g += g; all_b += b; n += 1
        h, s, l = to_hsl((r, g, b))
        if s < 0.18 or l < 0.12 or l > 0.92:
            continue
        w = s * (1.0 - abs(l - 0.5) * 1.2) + 0.02
        k = int(h * 18) % 18
        e = buckets.setdefault(k, [0.0, 0.0, 0.0, 0.0])
        e[0] += r * w; e[1] += g * w; e[2] += b * w; e[3] += w
    if not buckets:  # monochrome artwork -> keep it elegant and neutral
        base = (all_r / max(n, 1), all_g / max(n, 1), all_b / max(n, 1))
        h, s, l = to_hsl(base)
        if s < 0.06:      # truly neutral cover -> moonlight blue, so "saturated" still reads differently from "grey"
            h = 0.56
        return Palette(hsl(h, 0.30, 0.82), hsl(h + 0.05, 0.38, 0.66), hsl(h, 0.22, 0.045))
    ranked = sorted(buckets.items(), key=lambda kv: -kv[1][3])
    k1, e1 = ranked[0]
    c1 = (e1[0] / e1[3], e1[1] / e1[3], e1[2] / e1[3])
    h1, s1, _ = to_hsl(c1)
    h2, s2 = h1 + 0.09, s1
    for k, e in ranked[1:]:
        d = min((k - k1) % 18, (k1 - k) % 18)
        if d >= 3 and e[3] >= e1[3] * 0.25:
            c2 = (e[0] / e[3], e[1] / e[3], e[2] / e[3])
            h2, s2, _ = to_hsl(c2)
            break
    return make_palette(h1, max(s1, 0.55), h2, max(s2, 0.5))


# --------------------------------------------------------------------------- text width helpers

def cw(ch: str) -> int:
    return 2 if unicodedata.east_asian_width(ch[0]) in ("W", "F") else 1


def strw(s: str) -> int:
    return sum(cw(c) for c in s if not unicodedata.combining(c))


def trunc(s: str, w: int) -> str:
    if w <= 0:
        return ""
    if strw(s) <= w:
        return s
    out, n = [], 0
    for c in s:
        if unicodedata.combining(c):
            out.append(c)
            continue
        k = cw(c)
        if n + k > w - 1:
            break
        out.append(c)
        n += k
    return "".join(out) + "…"


def clusters(s: str) -> list[str]:
    out: list[str] = []
    for ch in s:
        if unicodedata.combining(ch) and out:
            out[-1] += ch
        else:
            out.append(ch)
    return out


# --------------------------------------------------------------------------- lyrics model

@dataclass
class Cell:
    __slots__ = ("ch", "b", "e", "bg", "w")
    ch: str
    b: float
    e: float
    bg: bool
    w: int


@dataclass
class Line:
    b: float
    e: float
    agent: str | None
    cells: list
    kind: str = "line"


class Row:
    __slots__ = ("cells", "xs", "w", "b", "e")

    def __init__(self, cells):
        while cells and cells[0].ch.isspace():
            cells = cells[1:]
        while cells and cells[-1].ch.isspace():
            cells = cells[:-1]
        self.cells = cells
        self.xs = []
        x = 0
        for c in cells:
            self.xs.append(x)
            x += c.w
        self.w = x
        self.b = min((c.b for c in cells), default=0.0)
        self.e = max((c.e for c in cells), default=0.0)


def wrap_cells(cells: list, width: int) -> list[Row]:
    rows, cur, curw, last_break = [], [], 0, -1
    for c in cells:
        if curw + c.w > width and cur:
            if last_break > 0:
                rows.append(Row(cur[:last_break]))
                cur = cur[last_break:]
                curw = sum(x.w for x in cur)
            else:
                rows.append(Row(cur))
                cur, curw = [], 0
            last_break = -1
        cur.append(c)
        curw += c.w
        if c.ch.isspace():
            last_break = len(cur)
    if cur:
        rows.append(Row(cur))
    rows = [r for r in rows if r.cells]
    return rows or [Row([])]


class Lyrics:
    def __init__(self, lines: list[Line]):
        self.lines = lines
        self.starts = [ln.b for ln in lines]
        agents: list[str] = []
        for ln in lines:
            if ln.kind == "line" and ln.agent and ln.agent not in agents and ln.agent not in GROUP_AGENTS:
                agents.append(ln.agent)
        self.agents = agents
        self.duet = len(agents) >= 2
        self.end = max((ln.e for ln in lines), default=0.0)
        self._lay: dict = {}

    def current(self, t: float) -> int:
        return bisect.bisect_right(self.starts, t + 0.04) - 1

    def align(self, ln: Line, default: str) -> str:
        if self.duet and ln.kind == "line":
            if ln.agent == self.agents[0]:
                return "left"
            if ln.agent == self.agents[1]:
                return "right"
            return "center"
        return default

    def layout(self, width: int, gap: int):
        key = (width, gap)
        got = self._lay.get(key)
        if got:
            return got
        rows_per, ys, y = [], [], 0
        for ln in self.lines:
            rows = wrap_cells(ln.cells, width)
            rows_per.append(rows)
            ys.append(y)
            y += len(rows) + gap
        got = (rows_per, ys)
        self._lay = {key: got}
        return got


# --------------------------------------------------------------------------- TTML parsing

def local(tag) -> str:
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def attr(el, name: str):
    for k, v in el.attrib.items():
        if k.rsplit("}", 1)[-1] == name:
            return v
    return None


def pt(s):
    """'1:16.656', '00:01:30.500', '12.5' (optionally with trailing s) -> seconds"""
    if s is None:
        return None
    s = s.strip().rstrip("s")
    try:
        v = 0.0
        for part in s.split(":"):
            v = v * 60.0 + float(part)
        return v
    except ValueError:
        return None


def _collect(el, bg: bool, out: list) -> None:
    for child in el:
        name = local(child.tag)
        if name == "span":
            is_bg = bg or attr(child, "role") == "x-bg"
            if child.get("begin") is not None:
                out.append([("".join(child.itertext())), pt(child.get("begin")), pt(child.get("end")), is_bg])
            else:
                _collect(child, is_bg, out)
        # whitespace *between* spans is the space between syllables — keep it (but not pretty-print newlines)
        tail = child.tail
        if tail and out and tail.strip() == "" and "\n" not in tail:
            out[-1][0] += tail


def make_cells(text: str, b: float, e: float, bg: bool) -> list[Cell]:
    cells: list[Cell] = []
    lead = len(text) - len(text.lstrip())
    trail = len(text) - len(text.rstrip())
    core = text.strip()
    if lead:
        cells.append(Cell(" ", b, b, bg, 1))
    cl = clusters(core)
    n = max(len(cl), 1)
    for i, ch in enumerate(cl):
        cells.append(Cell(ch, b + (e - b) * i / n, b + (e - b) * (i + 1) / n, bg, cw(ch)))
    if trail:
        cells.append(Cell(" ", e, e, bg, 1))
    return cells


def parse_ttml(ttml: str) -> Lyrics:
    root = ET.fromstring(ttml.encode("utf-8"))
    lines: list[Line] = []
    for p in root.iter():
        if local(p.tag) != "p":
            continue
        pb, pe = pt(p.get("begin")), pt(p.get("end"))
        syl: list = []
        _collect(p, False, syl)
        cells: list[Cell] = []
        if syl:
            for i, s in enumerate(syl):
                txt, b, e, bg = s
                if b is None:
                    b = pb if pb is not None else 0.0
                if e is None:
                    nxt = next((x[1] for x in syl[i + 1:] if x[1] is not None), None)
                    e = nxt if nxt is not None else (pe if pe is not None else b + 0.3)
                if e < b:
                    e = b
                cells += make_cells(txt, b, e, bg)
        else:  # line-level only lyrics: sweep across the whole line
            txt = "".join(p.itertext()).strip()
            if txt and pb is not None:
                cells = make_cells(txt, pb, pe if pe is not None else pb + 3.0, False)
        while cells and cells[-1].ch.isspace():
            cells.pop()
        while cells and cells[0].ch.isspace():
            cells.pop(0)
        if not cells:
            continue
        b = min(pb if pb is not None else cells[0].b, cells[0].b)
        e = max(pe if pe is not None else cells[-1].e, max(c.e for c in cells))
        lines.append(Line(b, e, attr(p, "agent"), cells))
    if not lines:
        raise ValueError("no timed lines in TTML")
    lines.sort(key=lambda l: l.b)
    return Lyrics(add_interludes(lines))


def add_interludes(lines: list[Line], min_gap: float = 6.0) -> list[Line]:
    out, prev_end = [], 0.0
    for ln in lines:
        if ln.b - prev_end >= min_gap:
            b, e = prev_end + 0.7, ln.b - 0.5
            cells, span = [], (e - b)
            for i in range(3):
                if i:
                    cells.append(Cell(" ", b + span * i / 3, b + span * i / 3, False, 1))
                cells.append(Cell("●", b + span * i / 3, b + span * (i + 1) / 3, False, 1))
            out.append(Line(b, e, None, cells, "interlude"))
        out.append(ln)
        prev_end = max(prev_end, ln.e)
    return out


# --------------------------------------------------------------------------- player state

@dataclass
class Track:
    title: str
    artist: str
    album: str = ""
    duration: float | None = None
    art_url: str = ""
    uri: str = ""
    key: str = field(default="", init=False)

    def __post_init__(self):
        self.key = f"{self.artist}|{self.title}|{self.album}".lower()

    @property
    def spotify_id(self) -> str:
        m = re.search(r"spotify[:/]track[:/]([A-Za-z0-9]{22})", self.uri or "")
        return m.group(1) if m else ""


def clean_title(s: str) -> str:
    s = re.sub(r"\s*[\(\[]\s*(official|lyric|lyrics|audio|video|music video|visuali[sz]er|hd|hq|4k|"
               r"remaster(ed)?|feat|ft)[^\)\]]*[\)\]]", "", s, flags=re.I)
    s = re.sub(r"\s*-\s*(\d{4}\s+)?(remaster(ed)?|single version|radio edit|mono|stereo)( version)?( \d{4})?\s*$", "", s, flags=re.I)
    return s.strip()


def make_track(title, artist, album="", duration=None, art_url="", uri="") -> Track | None:
    title, artist = (title or "").strip(), (artist or "").strip()
    if not title:
        return None
    if not artist and " - " in title:
        artist, title = [x.strip() for x in title.split(" - ", 1)]
    artist = re.sub(r"\s*-\s*Topic$", "", artist).strip()
    artist = re.sub(r"VEVO$", "", artist).strip() or artist
    return Track(title, artist, (album or "").strip(), duration if duration and duration > 0 else None, art_url or "", uri or "")


class State:
    def __init__(self):
        self.lock = threading.Lock()
        self.track: Track | None = None
        self.playing = False
        self.pos = 0.0
        self.mono = time.monotonic()
        self.rate = 1.0
        self.player: str | None = None
        self.error = ""

    def clear(self):
        with self.lock:
            self.track, self.playing, self.player = None, False, None

    def set(self, track, playing, pos, mono, rate=1.0, player=None):
        with self.lock:
            if self.track and track and self.track.key == track.key and self.playing and playing:
                pred = self.pos + (mono - self.mono) * self.rate
                err = pos - pred
                if abs(err) < 0.30:  # glide small corrections instead of jumping
                    pos = pred + err * 0.35
            self.track, self.playing, self.pos, self.mono, self.rate, self.player = track, playing, pos, mono, rate, player

    def position(self) -> float:
        with self.lock:
            return self.pos + (time.monotonic() - self.mono) * self.rate if self.playing else self.pos

    def snapshot(self):
        with self.lock:
            return self.track, self.playing, self.player


# --------------------------------------------------------------------------- backends

def _us(s):
    try:
        return float(s) / 1_000_000.0
    except Exception:
        return None


def _run(cmd, timeout=6):
    if isinstance(cmd, str):
        cmd = shlex.split(cmd)           # never rely on /bin/sh: Termux doesn't have one
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout


# ---- every backend exposes poll() -> bool ("I found a track") and .err (human-readable problem, or "")

class PlayerctlBackend:
    """Any MPRIS player on Linux: Spotify, Firefox, mpv+mpris, ytm-player, ..."""
    name = "mpris"
    FMT = ("{{playerInstance}}\t{{status}}\t{{position}}\t{{mpris:length}}\t"
           "{{artist}}\t{{title}}\t{{album}}\t{{mpris:artUrl}}\t{{xesam:url}}\t{{mpris:trackid}}")

    def __init__(self, state: State, player: str | None = None):
        self.state, self.player, self.sticky, self.err = state, player, None, ""

    def poll(self) -> bool:
        cmd = ["playerctl"] + (["-p", self.player] if self.player else ["-a"]) + ["metadata", "--format", self.FMT]
        t0 = time.monotonic()
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=3)
        except FileNotFoundError:
            self.err = "playerctl not found — sudo pacman -S playerctl"
            return False
        mono = (t0 + time.monotonic()) / 2.0  # midpoint of the request = best estimate of when position was read
        self.err = ""
        rows = [f for f in (ln.split("\t") for ln in r.stdout.splitlines()) if len(f) >= 8]
        playing = [f for f in rows if f[1] == "Playing"]
        pool = playing or [f for f in rows if f[1] == "Paused"]
        if not pool:
            return False
        pick = next((f for f in pool if f[0] == self.sticky), pool[0])
        self.sticky = pick[0]
        inst, status, pos, length, artist, title, album, art = pick[:8]
        uri = (pick[8] if len(pick) > 8 else "") or (pick[9] if len(pick) > 9 else "")
        tr = make_track(title, artist, album, _us(length), art, uri)
        if not tr:
            return False
        self.state.set(tr, status == "Playing", (_us(pos) or 0.0), mono, 1.0, inst)
        return True


MEDIA_PKGS = {
    "com.spotify.music", "com.google.android.apps.youtube.music", "com.google.android.youtube",
    "com.apple.android.music", "deezer.android.app", "com.aspiro.tidal", "com.amazon.mp3",
    "org.videolan.vlc", "com.soundcloud.android", "org.mozilla.firefox", "org.mozilla.fenix",
    "com.brave.browser", "com.android.chrome", "app.revanced.android.apps.youtube.music",
    "com.anghami", "com.jio.media.jiobeats", "com.gaana", "in.startv.hotstar", "com.maxmpz.audioplayer",
    "org.schabi.newpipe", "com.github.libretube", "it.vfsfitvnm.vimusic", "com.zionhuang.music",
    "moe.koiverse.archivetune", "com.metrolist.music", "com.poixson.pipemusic",
}


def parse_media_sessions(out: str):
    """Parse `dumpsys media_session` into [{pkg, state, position_ms, speed, updated_ms, desc}].
    Handles both `state=3` and the newer `state=PLAYING(3)` spellings, and both `metadata: size=` / `metadata:size=`."""
    sessions = []
    for seg in re.split(r"(?m)^\s*package=", out)[1:]:
        pkg = seg.split(None, 1)[0].strip() if seg.strip() else ""
        m = re.search(r"PlaybackState\s*\{\s*state=([^,}]+),\s*position=(-?\d+)[^}]*?speed=([\d.\-]+)[^}]*?updated=(\d+)", seg)
        md = re.search(r"metadata:\s*size=\d+,\s*description=(.*)", seg)
        if not m or not md:
            continue
        tok = m.group(1)
        n = re.search(r"\((\d+)\)", tok) or re.search(r"(\d+)", tok)
        if not n:
            continue
        sessions.append(dict(pkg=pkg, state=int(n.group(1)), position_ms=int(m.group(2)),
                             speed=float(m.group(3)), updated_ms=int(m.group(4)), desc=md.group(1).strip()))
    return sessions


def split_description(desc: str):
    parts = [("" if p.strip() == "null" else p.strip()) for p in desc.split(", ")]
    return (parts[0] if parts else ""), (parts[1] if len(parts) > 1 else ""), (parts[2] if len(parts) > 2 else "")


class AndroidBackend:
    """Termux. Exact position from `dumpsys media_session` (needs adb-over-wifi / Shizuku rish / root);
    otherwise title+artist from the media notification via termux-notification-list."""
    name = "android"

    def __init__(self, state: State):
        self.state, self.cmd, self.checked_at = state, None, -999.0
        self.last_key, self.next, self.last, self.err = None, 0.0, False, ""
        self.how = "none"

    def find_cmd(self):
        cands = []
        if os.environ.get("LYRICGLOW_DUMPSYS"):
            cands.append(os.environ["LYRICGLOW_DUMPSYS"])
        if shutil.which("rish"):
            cands.append("rish -c 'dumpsys media_session'")
        if shutil.which("su"):
            cands.append("su -c 'dumpsys media_session'")
        if shutil.which("adb"):
            try:
                _, out = _run(["adb", "devices"], 8)
                for ln in out.splitlines():
                    p = ln.split()
                    if len(p) == 2 and p[1] == "device":
                        cands.append(f"adb -s {shlex.quote(p[0])} shell dumpsys media_session")
            except Exception as e:
                log(f"adb devices: {e!r}")
        for c in cands:
            try:
                rc, out = _run(c, 10)
                if rc == 0 and "media_session" in out.lower():
                    return c
            except Exception as e:
                log(f"dumpsys candidate {c!r}: {e!r}")
        return None

    def poll(self) -> bool:
        now = time.monotonic()
        if now < self.next:
            return self.last
        self.next = now + 1.0
        if not self.cmd and now - self.checked_at > 20:          # re-probe: adb may be connected later
            self.checked_at = now
            self.cmd = self.find_cmd()
            self.how = "dumpsys" if self.cmd else "notifications"
            log(f"android source: {self.how} ({self.cmd})")
        if self.cmd:
            try:
                res = self.poll_dumpsys()
                if res is not None:
                    self.last = res
                    return res
            except Exception as e:
                log(f"dumpsys poll: {e!r}")
                self.cmd = None
        self.last = self.poll_notifications()
        return self.last

    def poll_dumpsys(self):
        t0 = time.monotonic()
        rc, out = _run(self.cmd, 10)
        mono = (t0 + time.monotonic()) / 2.0
        if rc != 0:
            self.cmd = None
            return None
        self.err = ""
        best = None
        for s in parse_media_sessions(out):
            rank = {3: 0, 2: 1, 6: 2}.get(s["state"])
            if rank is not None and (best is None or rank < best[0]):
                best = (rank, s)
        if not best:
            return False
        s = best[1]
        title, artist, album = split_description(s["desc"])
        tr = make_track(title, artist, album)
        if not tr:
            return False
        pos = float(s["position_ms"])
        playing = s["state"] == 3
        if playing:
            boot_ms = time.clock_gettime(time.CLOCK_BOOTTIME) * 1000.0
            pos += max(0.0, boot_ms - s["updated_ms"]) * s["speed"]
        self.state.set(tr, playing, pos / 1000.0, mono, s["speed"] if s["speed"] > 0 else 1.0, "android")
        return True

    def poll_notifications(self) -> bool:
        try:
            rc, out = _run(["termux-notification-list"], 10)
        except FileNotFoundError:
            self.err = "termux-notification-list missing — pkg install termux-api (and install the Termux:API app)"
            return False
        if rc != 0:
            self.err = "termux-notification-list failed — open Termux:API and allow notification access"
            return False
        self.err = ""
        try:
            items = json.loads(out or "[]")
        except ValueError:
            self.err = "termux-notification-list returned garbage — update the Termux:API app"
            return False
        for n in items:
            pkgname = n.get("packageName", "")
            if (pkgname in MEDIA_PKGS or os.environ.get("LYRICGLOW_ANY_NOTIFICATION")) and n.get("title") and n.get("content"):
                artist, album = n["content"], ""
                if re.search(r"\s[•·]\s", n["content"]):
                    bits = re.split(r"\s[•·]\s", n["content"])
                    artist, album = bits[0], (bits[1] if len(bits) > 1 else "")
                tr = make_track(n["title"], artist, album)
                if not tr:
                    continue
                if tr.key != self.last_key:
                    self.last_key = tr.key
                    self.state.set(tr, True, 1.5, time.monotonic(), 1.0, "android-notif")
                return True
        return False


class MpvBackend:
    """mpv over its JSON IPC socket — covers terminal YouTube-Music clients that play through mpv
    (ytm, ytermusic-style wrappers, yewtube, plain `mpv --input-ipc-server=...`). Works on Termux too."""
    name = "mpv"
    PROPS = ("pause", "time-pos", "duration", "media-title", "metadata", "path")

    def __init__(self, state: State, sock: str | None = None):
        self.state, self.sock_path, self.err = state, sock or os.environ.get("LYRICGLOW_MPV_SOCKET"), ""
        self.s, self.rid, self.found, self.next_scan = None, 0, "", 0.0

    @staticmethod
    def candidates(extra: str | None = None):
        dirs = [os.environ.get(k) for k in ("XDG_RUNTIME_DIR", "TMPDIR")] + ["/tmp", "/var/tmp",
                os.path.expanduser("~/.config/mpv"), os.path.expanduser("~/.cache"),
                os.path.expanduser("~/.local/state"), os.path.expanduser("~")]
        out = [extra] if extra else []
        for d in [d for d in dirs if d and os.path.isdir(d)]:
            for pat in ("mpv*", "*mpv*", "*.sock", "*/*mpv*", "*/*.sock", "ytm*/*sock*"):
                out += glob.glob(os.path.join(d, pat))
        seen, res = set(), []
        for p in out:
            try:
                if p not in seen and stat.S_ISSOCK(os.stat(p).st_mode):
                    seen.add(p)
                    res.append(p)
            except OSError:
                pass
        return res

    def _connect(self, path) -> bool:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(0.6)
        try:
            s.connect(path)
            s.sendall(b'{"command":["get_property","mpv-version"],"request_id":1}\n')
            data, good = b"", False
            end = time.monotonic() + 0.8
            while time.monotonic() < end and not good:     # mpv interleaves event lines with replies
                chunk = s.recv(4096)
                if not chunk:
                    break
                data += chunk
                while b"\n" in data:
                    line, data = data.split(b"\n", 1)
                    try:
                        obj = json.loads(line)
                    except ValueError:
                        continue
                    if isinstance(obj, dict) and obj.get("request_id") == 1 and "error" in obj:
                        good = True
            if not good:
                raise OSError("not mpv")
        except Exception:
            s.close()
            return False
        self.s, self.found = s, path
        return True

    def _query(self):
        """Pipeline all property reads in one write; returns ({prop: value}, t_mid)."""
        want = {}
        msg = b""
        for p in self.PROPS:
            self.rid += 1
            want[self.rid] = p
            msg += json.dumps({"command": ["get_property", p], "request_id": self.rid}).encode() + b"\n"
        t0 = time.monotonic()
        self.s.sendall(msg)
        got, buf = {}, b""
        end = t0 + 1.0
        while len(got) < len(want) and time.monotonic() < end:
            chunk = self.s.recv(65536)
            if not chunk:
                raise ConnectionError("mpv closed the socket")
            buf += chunk
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                try:
                    obj = json.loads(line)
                except ValueError:
                    continue
                rid = obj.get("request_id")
                if rid in want:
                    got[want[rid]] = obj.get("data") if obj.get("error") == "success" else None
        return got, (t0 + time.monotonic()) / 2.0

    def poll(self) -> bool:
        now = time.monotonic()
        if self.s is None:
            if now < self.next_scan:
                return False
            self.next_scan = now + 3.0
            for p in self.candidates(self.sock_path):
                if self._connect(p):
                    log(f"mpv socket: {p}")
                    break
            if self.s is None:
                return False
        try:
            got, mono = self._query()
        except Exception as e:
            log(f"mpv query: {e!r}")
            try:
                self.s.close()
            except Exception:
                pass
            self.s = None
            return False
        if got.get("path") is None and got.get("media-title") is None:
            return False                               # mpv is idle
        md = {str(k).lower(): v for k, v in (got.get("metadata") or {}).items()}
        title = md.get("title") or got.get("media-title") or ""
        artist = md.get("artist") or md.get("album_artist") or md.get("uploader") or md.get("channel") or ""
        path = str(got.get("path") or "")
        art, vid = "", re.search(r"(?:[?&]v=|youtu\.be/)([\w-]{11})", path)
        if vid:                                        # YouTube: its thumbnail is the cover (square art, pillarboxed)
            art = f"https://i.ytimg.com/vi/{vid.group(1)}/hqdefault.jpg"
        tr = make_track(title, artist, md.get("album", ""), got.get("duration"), art, path)
        if not tr:
            return False
        self.state.set(tr, not got.get("pause"), float(got.get("time-pos") or 0.0), mono, 1.0, "mpv")
        return True


# --------------------------------------------------------------------------- YouTube Music player (search + queue + mpv)
#
# `lyricglow ytm` = a terminal music player. Search uses ytmusicapi (pip install ytmusicapi; no login needed) and falls
# back to yt-dlp's search. Audio is streamed by mpv (which calls yt-dlp), so there are no ads — just the audio stream.
# Metadata comes from the search result, so lyrics are matched by the proper artist/title, not a messy video title.

def _thumb(url: str) -> str:
    if url and ("googleusercontent" in url or "ggpht" in url):
        return re.sub(r"=w\d+-h\d+.*$", "=w544-h544-l90-rj", url)
    return url or ""


def _best_thumb(th) -> str:
    th = th or []
    if not th:
        return ""
    best = max(th, key=lambda t: (t.get("width") or 0) * (t.get("height") or 0))
    return _thumb(best.get("url", ""))


def _parse_dur(x) -> float | None:
    if isinstance(x, (int, float)):
        return float(x)
    if isinstance(x, str) and re.fullmatch(r"(\d+:)?\d+:\d{2}", x.strip()):
        v = 0.0
        for part in x.strip().split(":"):
            v = v * 60 + float(part)
        return v
    return None


def norm_item(r: dict) -> dict | None:
    """ytmusicapi search / watch-playlist entry -> our queue item"""
    vid = r.get("videoId")
    if not vid or not r.get("title"):
        return None
    artists = ", ".join(a.get("name", "") for a in (r.get("artists") or r.get("artist") or []) if a.get("name"))
    album = (r.get("album") or {}).get("name", "") if isinstance(r.get("album"), dict) else ""
    dur = r.get("duration_seconds") or _parse_dur(r.get("duration")) or _parse_dur(r.get("length"))
    art = _best_thumb(r.get("thumbnails") or r.get("thumbnail"))
    alb = r.get("album")
    return dict(id=vid, title=r["title"], artist=artists, album=album, dur=dur, art=art,
                url=f"https://music.youtube.com/watch?v={vid}", album_id=(alb.get("id") or "") if isinstance(alb, dict) else "")


def _ytdlp_json(args: list[str], timeout: int = 40) -> list[dict]:
    if not shutil.which("yt-dlp"):
        raise RuntimeError("yt-dlp not installed (Arch: sudo pacman -S yt-dlp   Termux: pkg install yt-dlp)")
    r = subprocess.run(["yt-dlp", "--flat-playlist", "--dump-json", "--no-warnings", *args],
                       capture_output=True, text=True, timeout=timeout)
    out = []
    for ln in r.stdout.splitlines():
        try:
            out.append(json.loads(ln))
        except ValueError:
            pass
    if not out and r.returncode != 0:
        raise RuntimeError((r.stderr.strip().splitlines() or ["yt-dlp failed"])[-1][:120])
    return out


def _item_from_ytdlp(d: dict) -> dict | None:
    vid = d.get("id")
    if not vid or not d.get("title"):
        return None
    artist = re.sub(r"\s*-\s*Topic$", "", d.get("artist") or d.get("channel") or d.get("uploader") or "")
    return dict(id=vid, title=d["title"], artist=artist, album=d.get("album") or "", dur=d.get("duration"),
                art=f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg", url=f"https://music.youtube.com/watch?v={vid}")


def expand_url(url: str) -> list[dict]:
    """a pasted video / playlist URL -> items"""
    return [it for it in (_item_from_ytdlp(d) for d in _ytdlp_json([url], 60)) if it]


# --------------------------------------------------------------------------- YouTube Music account + browsing data
#
# Signing in uses ytmusicapi "browser authentication": you copy one request's headers from a logged-in
# music.youtube.com tab, and `lyricglow ytm login` turns them into ~/.config/lyricglow/ytm-auth.json (mode 0600).
# Everything below works signed-out except your library (Playlists / library Albums / Liked Music / History).

AUTH_FILE = os.path.join(os.path.dirname(CONF), "ytm-auth.json")


class YtmAccount:
    def __init__(self):
        self.auth, self.user, self.language, self.oauth = AUTH_FILE, None, "en", None
        self._api, self._lock = None, threading.RLock()

    def configure(self, cfg):
        self.auth = os.path.expanduser(getattr(cfg, "ytm_auth", None) or AUTH_FILE)
        self.user = getattr(cfg, "ytm_user", None) or None
        self.language = getattr(cfg, "ytm_language", None) or "en"
        cid, sec = getattr(cfg, "ytm_oauth_client_id", None), getattr(cfg, "ytm_oauth_client_secret", None)
        self.oauth = (cid, sec) if cid and sec else None
        self._api = None

    @property
    def signed_in(self) -> bool:
        return os.path.exists(self.auth)

    def api(self):
        """ytmusicapi client (ImportError if the package is missing)."""
        with self._lock:
            if self._api is None:
                from ytmusicapi import YTMusic
                kw = {"language": self.language}
                if self.user:
                    kw["user"] = self.user
                if self.signed_in:
                    if self.oauth:
                        from ytmusicapi import OAuthCredentials
                        kw["oauth_credentials"] = OAuthCredentials(client_id=self.oauth[0], client_secret=self.oauth[1])
                    self._api = YTMusic(self.auth, **kw)
                else:
                    self._api = YTMusic(**kw)
            return self._api

    def need_auth(self):
        if not self.signed_in:
            raise PermissionError("press  l  to sign in with your browser's YouTube login (or run: lyricglow ytm login)")


ACCOUNT = YtmAccount()


def _artists(r: dict) -> str:
    a = r.get("artists") or r.get("artist") or []
    if isinstance(a, list):
        return ", ".join(x.get("name", "") for x in a if isinstance(x, dict) and x.get("name"))
    if isinstance(a, dict):
        return a.get("name", "")
    return str(a)


def norm_entry(r: dict, hint: str | None = None) -> dict | None:
    """Any ytmusicapi result -> a browser entry. kind: song | album | playlist | radio"""
    if not isinstance(r, dict):
        return None
    if r.get("videoId"):
        it = norm_item(r)
        if it:
            it["kind"] = "song"
        return it
    title = r.get("title")
    if not title:
        return None
    bid, pid = r.get("browseId") or "", r.get("playlistId") or ""
    rtype = str(r.get("resultType") or r.get("type") or "").lower()
    author = r.get("author")
    who = _artists(r) or (author.get("name", "") if isinstance(author, dict) else (author or ""))
    count = r.get("count") or r.get("itemCount") or ""
    sub = " · ".join(x for x in [who, str(r.get("year") or ""), (f"{count} songs" if count else ""),
                                  (r.get("description") or "")[:50]] if x)
    if bid.startswith("UC") or rtype == "artist":
        return None
    if bid.startswith("MPRE") or rtype in ("album", "single", "ep") or (hint == "albums" and bid):
        kind, ident = "album", bid
    elif pid.startswith("RD"):
        kind, ident = "radio", pid
    elif pid or bid:
        kind, ident = "playlist", (pid or (bid[2:] if bid.startswith("VL") else bid))
    else:
        return None
    return dict(kind=kind, id=ident, title=title, artist=sub, album="", dur=None,
                art=_best_thumb(r.get("thumbnails") or r.get("thumbnail")), url="")


def tracks_to_items(tracks, album: str = "", art: str = "") -> list[dict]:
    out = []
    for t in tracks or []:
        if not isinstance(t, dict):
            continue
        r = dict(t)
        if album and not isinstance(r.get("album"), dict):
            r["album"] = {"name": album}
        if art and not (r.get("thumbnails") or r.get("thumbnail")):
            r["thumbnails"] = [{"url": art}]
        it = norm_item(r)
        if it:
            it["kind"] = "song"
            out.append(it)
    return out


def _need_api():
    try:
        return ACCOUNT.api()
    except ImportError:
        raise RuntimeError("needs ytmusicapi:  pip install ytmusicapi")


def norm_artist(r: dict) -> dict | None:
    bid = r.get("browseId") or ""
    name = r.get("artist") or r.get("title") or ""
    if not bid or not name:
        return None
    subs = r.get("subscribers") or ""
    return dict(kind="artist", id=bid, title=name, artist=("Artist · " + str(subs)) if subs else "Artist", album="", dur=None,
                art=_best_thumb(r.get("thumbnails") or r.get("thumbnail")), url="")


def search_ytm(query: str, n: int = 20, kind: str = "songs") -> list[dict]:
    """kind: songs | albums | artists | playlists | all (a mix of everything, in YouTube Music's own order)"""
    try:
        api = ACCOUNT.api()
    except ImportError:
        if kind not in ("songs", "all"):
            raise RuntimeError("album / artist / playlist search needs ytmusicapi:  pip install ytmusicapi")
        return [it for it in (_item_from_ytdlp(d) for d in _ytdlp_json([f"ytsearch{n}:{query}"])) if it]
    if kind == "all":
        out = []
        for r in api.search(query, limit=n) or []:
            rt = str(r.get("resultType") or "")
            e = None
            if rt in ("song", "video"):
                e = norm_item(r)
                if e:
                    e["kind"] = "song"
            elif rt == "artist":
                e = norm_artist(r)
            elif rt in ("album", "single", "ep"):
                e = norm_entry(r, "albums")
            elif "playlist" in rt:
                e = norm_entry(r)
            if e:
                out.append(e)
        return out
    if kind == "artists":
        return [e for e in (norm_artist(r) for r in api.search(query, filter="artists", limit=n) or []) if e]
    res = api.search(query, filter=kind, limit=n)
    if kind == "songs":
        return [it for it in (norm_item(r) for r in res) if it and not it.update(kind="song")]
    return [e for e in (norm_entry(r, "albums" if kind == "albums" else None) for r in res) if e]


def related_ytm(video_id: str, n: int = 25) -> list[dict]:
    """a song's radio: what YouTube Music would autoplay after it"""
    try:
        api = ACCOUNT.api()
    except ImportError:
        return []
    res = api.get_watch_playlist(videoId=video_id, radio=True, limit=n)
    return tracks_to_items(res.get("tracks"))


def load_quick_picks() -> list[dict]:
    api = _need_api()
    shelves = api.get_home(limit=6) or []
    pick = next((s for s in shelves if "quick" in str(s.get("title", "")).lower()), None)
    out = [e for e in (norm_entry(c) for c in (pick or {}).get("contents", [])) if e and e["kind"] == "song"]
    if len(out) < 8:                                  # not enough? top up with songs from the other shelves
        seen = {e["id"] for e in out}
        for s in shelves:
            for c in s.get("contents", []):
                e = norm_entry(c)
                if e and e["kind"] == "song" and e["id"] not in seen:
                    seen.add(e["id"])
                    out.append(e)
    return out


def load_home_kind(kind: str) -> list[dict]:
    api = _need_api()
    out, seen = [], set()
    for s in api.get_home(limit=10) or []:
        for c in s.get("contents", []):
            e = norm_entry(c)
            if e and e["kind"] == kind and e["id"] not in seen:
                seen.add(e["id"])
                out.append(e)
    return out


def load_library(kind: str) -> list[dict]:
    ACCOUNT.need_auth()
    api = _need_api()
    if kind == "albums":
        return [e for e in (norm_entry(r, "albums") for r in api.get_library_albums(limit=100)) if e]
    out = [dict(kind="playlist", id="LM", title="Liked Music", artist="your liked songs", album="", dur=None, art="", url=""),
           dict(kind="playlist", id="HISTORY", title="History", artist="recently played", album="", dur=None, art="", url="")]
    out += [e for e in (norm_entry(r) for r in api.get_library_playlists(limit=100)) if e]
    return out


def open_entry(e: dict) -> list[dict]:
    """a browser entry -> playable songs"""
    api = _need_api()
    k, ident = e["kind"], e["id"]
    if k == "song":
        return [e]
    if k == "artist":                                 # an artist = their songs (the full list when YouTube Music has one)
        a = api.get_artist(ident)
        songs = a.get("songs") or {}
        items = tracks_to_items(songs.get("results"))
        if songs.get("browseId"):
            try:
                items = tracks_to_items(api.get_playlist(songs["browseId"], limit=100).get("tracks")) or items
            except Exception as ex:
                log(f"artist songs: {ex!r}")
        return items
    if k == "album":
        alb = api.get_album(ident)
        return tracks_to_items(alb.get("tracks"), alb.get("title", e["title"]), _best_thumb(alb.get("thumbnails")) or e.get("art", ""))
    if k == "radio":
        if ident == "SEED":                           # "radio from what's playing now"
            return related_ytm(e["seed"])
        return tracks_to_items(api.get_watch_playlist(playlistId=ident, limit=50).get("tracks"))
    if ident == "LM":
        ACCOUNT.need_auth()
        return tracks_to_items(api.get_liked_songs(limit=200).get("tracks"))
    if ident == "HISTORY":
        ACCOUNT.need_auth()
        return tracks_to_items(api.get_history())
    return tracks_to_items(api.get_playlist(ident, limit=200).get("tracks"), art=e.get("art", ""))


def parse_search(q: str, default: str = "songs"):
    """'album: discovery' / 'artist: daft punk' / 'playlist: lofi' / 'song: x' / 'all: x' -> (filter, text); plain text -> (default, text)"""
    m = re.match(r"^\s*(songs?|albums?|artists?|playlists?|all)\s*:\s*(.+)$", q, re.I)
    if m:
        return {"song": "songs", "album": "albums", "artist": "artists", "playlist": "playlists", "all": "all"}[m.group(1).lower().rstrip("s")], m.group(2).strip()
    return default, q.strip()


# --------------------------------------------------------------------------- easy sign-in: reuse the browser's login
#
# No DevTools, no pasting. Your browser already holds a logged-in YouTube session (cookies). lyricglow reads those
# cookies once, builds the same six headers ytmusicapi's "browser authentication" needs, and saves them (mode 0600).
#   Firefox-family  (Firefox, LibreWolf, Zen, Floorp, Waterfox): read straight from cookies.sqlite — no extras
#   Chrome-family   (Chrome, Chromium, Brave, Vivaldi, Edge, Opera): decrypted with yt-dlp's cookie reader (yt-dlp is installed anyway)

BROWSER_ORDER = ["firefox", "librewolf", "zen", "floorp", "waterfox", "chrome", "chromium", "brave", "vivaldi", "edge", "opera"]
_FF_ROOTS = {
    "firefox": ["~/.mozilla/firefox", "~/.var/app/org.mozilla.firefox/.mozilla/firefox", "~/snap/firefox/common/.mozilla/firefox"],
    "librewolf": ["~/.librewolf", "~/.var/app/io.gitlab.librewolf-community/.librewolf"],
    "zen": ["~/.zen", "~/.var/app/app.zen_browser.zen/.zen"],
    "floorp": ["~/.floorp", "~/.var/app/one.ablaze.floorp/.floorp"],
    "waterfox": ["~/.waterfox"],
}
NO_LOGIN_SHORT = "no YouTube login found — log in at music.youtube.com in your browser, then press l again"


class LoginError(Exception):
    pass


class _QuietLogger:
    def debug(self, *a, **k): pass
    def info(self, *a, **k): pass
    def warning(self, *a, **k): pass
    def error(self, *a, **k): pass


def _ff_profiles(name: str) -> list[str]:
    out = []
    for root in _FF_ROOTS.get(name, []):
        root = os.path.expanduser(root)
        if not os.path.isdir(root):
            continue
        ranked = []
        ini = os.path.join(root, "profiles.ini")
        if os.path.exists(ini):
            cp = configparser.RawConfigParser()
            try:
                cp.read(ini)
            except configparser.Error:
                pass
            installs = [cp.get(sec, "Default") for sec in cp.sections() if sec.startswith("Install") and cp.has_option(sec, "Default")]
            for sec in cp.sections():
                if sec.startswith("Profile") and cp.has_option(sec, "Path"):
                    pth = cp.get(sec, "Path")
                    full = os.path.join(root, pth) if cp.get(sec, "IsRelative", fallback="1") == "1" else pth
                    is_def = cp.get(sec, "Default", fallback="0") == "1" or pth in installs
                    ranked.append((0 if is_def else 1, full))
        ranked.sort()
        out += [p for _, p in ranked]
        out += [p for p in sorted(glob.glob(os.path.join(root, "*"))) if os.path.isdir(p) and p not in out]
    return [p for p in out if os.path.exists(os.path.join(p, "cookies.sqlite"))]


def _read_ff(profile: str) -> dict:
    tmp = tempfile.mkdtemp(prefix="lyricglow-")
    try:
        for suf in ("", "-wal", "-shm"):                 # copy the WAL too: Firefox keeps fresh cookies there while running
            src = os.path.join(profile, "cookies.sqlite" + suf)
            if os.path.exists(src):
                shutil.copy2(src, os.path.join(tmp, "cookies.sqlite" + suf))
        con = sqlite3.connect(os.path.join(tmp, "cookies.sqlite"))
        try:
            rows = con.execute("SELECT name, value FROM moz_cookies WHERE host LIKE '%youtube.com' ORDER BY lastAccessed").fetchall()
        finally:
            con.close()
        return dict(rows)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _has_login(c: dict) -> bool:
    return bool(("SAPISID" in c or "__Secure-3PAPISID" in c) and ("SID" in c or "__Secure-3PSID" in c))


def read_browser_cookies(spec: str) -> dict:
    """spec = 'firefox' or 'chrome:Profile 1'. -> YouTube cookies of a logged-in session, or {}"""
    name, _, profile = spec.lower().partition(":")
    if name in _FF_ROOTS:
        for p in ([profile] if profile else _ff_profiles(name)):
            try:
                c = _read_ff(p)
            except Exception as e:
                log(f"cookies {p}: {e!r}")
                continue
            if _has_login(c):
                return c
        return {}
    try:
        from yt_dlp.cookies import extract_cookies_from_browser
    except ImportError:
        raise LoginError("Chrome-family browsers need yt-dlp's Python module (Arch: sudo pacman -S yt-dlp) — or use Firefox")
    jar = extract_cookies_from_browser(name, profile or None, _QuietLogger())
    c = {ck.name: ck.value for ck in jar if str(ck.domain).endswith("youtube.com")}
    return c if _has_login(c) else {}


def find_browser_sessions(only: str | None = None) -> list:
    """-> [(browser, cookies)] for every browser that has a logged-in YouTube session"""
    found = []
    for spec in ([only] if only else BROWSER_ORDER):
        try:
            c = read_browser_cookies(spec)
        except LoginError:
            if only:
                raise
            continue
        except Exception as e:
            log(f"browser {spec}: {e!r}")
            if only:
                raise LoginError(f"couldn't read {spec}'s cookies: {e}")
            continue
        if c:
            found.append((spec, c))
    return found


def sapisid_hash(cookies: dict, origin: str = "https://music.youtube.com", ts: int | None = None) -> str:
    sid = cookies.get("SAPISID") or cookies.get("__Secure-3PAPISID") or ""
    ts = int(ts or time.time())
    return f"SAPISIDHASH {ts}_{hashlib.sha1(f'{ts} {sid} {origin}'.encode()).hexdigest()}"


def write_auth(cookies: dict, path: str, authuser="0"):
    """the exact 'manual browser.json' layout from the ytmusicapi docs"""
    hdr = {"Accept": "*/*", "Authorization": sapisid_hash(cookies), "Content-Type": "application/json",
           "X-Goog-AuthUser": str(authuser), "x-origin": "https://music.youtube.com",
           "Cookie": "; ".join(f"{k}={v}" for k, v in cookies.items())}
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(hdr, f, indent=1)
    os.chmod(path, 0o600)


def bind_account(cfg, sessions: list | None = None):
    """Sign in using a browser session. -> (account name, browser). Raises LoginError with a friendly message."""
    ACCOUNT.configure(cfg)
    if IS_TERMUX and sessions is None:
        raise LoginError("library sign-in needs a desktop browser — not available on Termux (search, quick picks, albums & radios work signed-out)")
    if sessions is None:
        sessions = find_browser_sessions()
    if not sessions:
        raise LoginError(NO_LOGIN_SHORT)
    last = None
    for spec, cookies in sessions:
        write_auth(cookies, ACCOUNT.auth, getattr(cfg, "ytm_authuser", 0) or 0)
        ACCOUNT._api = None
        try:
            info = ACCOUNT.api().get_account_info()
            return (info.get("accountName") or "your account"), spec
        except ImportError:
            os.remove(ACCOUNT.auth)
            raise LoginError("ytmusicapi isn't installed — pip install ytmusicapi")
        except Exception as e:
            last = e
            try:
                os.remove(ACCOUNT.auth)
            except OSError:
                pass
    raise LoginError(f"{spec} has a Google login, but YouTube Music rejected it ({str(last)[:60]}) — open music.youtube.com there, make sure you're signed in, and retry")


def open_url(url: str):
    for cmd in (["termux-open-url", url], ["xdg-open", url]):
        if shutil.which(cmd[0]):
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
    import webbrowser
    webbrowser.open(url)


def run_login(cfg):
    """`lyricglow ytm login [browser]` — friendly flow; `--manual` for the paste-headers method."""
    if getattr(cfg, "manual", False):
        return run_login_manual(cfg)
    ACCOUNT.configure(cfg)
    only = cfg.query[1] if len(cfg.query) > 1 else None
    print("\x1b[1mSign in to YouTube Music\x1b[0m\n")
    print("lyricglow will reuse the YouTube login your browser already has — nothing to copy or paste.")
    print(f"It is saved to {ACCOUNT.auth} (readable only by you).\n")
    try:
        import ytmusicapi  # noqa: F401
    except ImportError:
        sys.exit("First install ytmusicapi:   pip install --user ytmusicapi     (Arch with PEP 668: pipx install ytmusicapi, or add --break-system-packages)")
    try:
        sessions = find_browser_sessions(only)
        if not sessions:
            print("I couldn't find a YouTube login in your browsers" + (f" ({only})" if only else "") + ".")
            if sys.stdin.isatty():
                if input("Open music.youtube.com so you can log in now? [Y/n] ").strip().lower() in ("", "y", "yes"):
                    open_url("https://music.youtube.com")
                    input("Log in there, then come back and press Enter… ")
                    sessions = find_browser_sessions(only)
        if not sessions:
            sys.exit("Still nothing. Log in at https://music.youtube.com with Firefox or Chrome, then run:  lyricglow ytm login\n"
                     "(Firefox may need a minute to write its cookies; or try   lyricglow ytm login --manual )")
        if len(sessions) > 1 and sys.stdin.isatty():
            print("Found a login in several browsers:")
            for i, (b, _) in enumerate(sessions, 1):
                print(f"  {i}) {b}")
            pick = input(f"Which one? [1-{len(sessions)}, default 1] ").strip()
            sessions = [sessions[int(pick) - 1]] if pick.isdigit() and 1 <= int(pick) <= len(sessions) else sessions[:1]
        name, browser = bind_account(cfg, sessions[:1] if len(sessions) > 1 else sessions)
    except LoginError as e:
        sys.exit(str(e))
    print(f"\n\x1b[32m✔ signed in as {name}\x1b[0m  (using your {browser} login)")
    print("Open `lyricglow ytm`, press TAB until you reach the song picker, then ←/→ to Playlists / Albums.")
    print("Signed out later? Just press  l  inside the app, or run this again.  `lyricglow ytm logout` removes it.")


def run_login_manual(cfg):
    """Advanced: paste request headers copied from the browser's developer tools."""
    ACCOUNT.configure(cfg)
    print("\x1b[1mManual sign-in\x1b[0m (advanced) — needs:  pip install ytmusicapi\n")
    try:
        import ytmusicapi
    except ImportError:
        sys.exit("ytmusicapi is not installed.  pip install --user ytmusicapi")
    print("  1. In Firefox open https://music.youtube.com (logged in) → Ctrl+Shift+I → Network, filter  /browse")
    print("  2. Click Library until a POST to music.youtube.com/youtubei/v1/browse… appears")
    print("  3. Right-click it → Copy → Copy Request Headers, paste below, then press Ctrl+D on an empty line.\n")
    try:
        raw = sys.stdin.read()
    except KeyboardInterrupt:
        sys.exit("\ncancelled")
    if "cookie" not in raw.lower():
        sys.exit("\nThat doesn't look like request headers (no Cookie line).")
    os.makedirs(os.path.dirname(ACCOUNT.auth), exist_ok=True)
    try:
        ytmusicapi.setup(filepath=ACCOUNT.auth, headers_raw=raw)
        os.chmod(ACCOUNT.auth, 0o600)
        ACCOUNT._api = None
        ACCOUNT.api().get_library_playlists(limit=1)
    except Exception as e:
        sys.exit(f"\nSaved, but YouTube Music rejected the session: {e}")
    print("\n\x1b[32m✔ signed in.\x1b[0m")


def run_logout(cfg):
    ACCOUNT.configure(cfg)
    if ACCOUNT.signed_in:
        os.remove(ACCOUNT.auth)
        print("signed out (auth file deleted).")
    else:
        print("not signed in.")


def run_status(cfg):
    ACCOUNT.configure(cfg)
    if not ACCOUNT.signed_in:
        return print("not signed in — run `lyricglow ytm login`")
    try:
        info = ACCOUNT.api().get_account_info()
        print(f"signed in as {info.get('accountName', '?')}  ({ACCOUNT.auth})")
    except Exception as e:
        print(f"auth file present ({ACCOUNT.auth}) but the session failed: {e}\nrun `lyricglow ytm login` again")



# =========================================================================== audio cache + gapless
#
# Every queued song is downloaded (yt-dlp "bestaudio", no re-encoding) into ~/.cache/lyricglow/audio. Playing from disk starts instantly,
# lets mpv join tracks WITHOUT a gap, and makes a replay seamless. An album is cached whole. Least-recently-played files go first once the
# size cap is reached (songs in the current queue are never evicted).

_VID = re.compile(r"(?:[?&]v=|youtu\.be/)([\w-]{11})")
AUDIO_DIR = os.path.join(CACHE, "audio")


def _safe_id(vid: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]", "_", str(vid))[:64]


def cached_audio_for_url(url: str):
    """path of an already-downloaded song for a YouTube URL, else None (the beat analysis uses it so nothing is downloaded twice)"""
    m = _VID.search(str(url or ""))
    return AudioCache.find(m.group(1)) if m else None


class AudioCache:
    SKIP = (".part", ".ytdl", ".tmp", ".temp")
    _idx: dict = {}
    _idx_t = -9.0

    def __init__(self, cfg):
        self.enabled = bool(getattr(cfg, "ytm_cache", True)) and bool(shutil.which("yt-dlp"))
        self.max = int(float(getattr(cfg, "ytm_cache_mb", 0) or (600 if IS_TERMUX else 2000)) * 1024 * 1024)
        self.cookies = getattr(cfg, "ytm_cookies_browser", None)
        self.cv = threading.Condition()
        self.heap: list = []
        self.n = 0
        self.state: dict = {}                 # id -> "queued" | "loading"
        self.prio_of: dict = {}
        self.failed: dict = {}
        self.protect: set = set()
        self.closed = False
        self.threads: list = []
        self.workers = 1 if IS_TERMUX else 2

    # ---- what is on disk (listing cached for 1 s so drawing a long list stays cheap)
    @classmethod
    def _index(cls, fresh: bool = False) -> dict:
        now = time.monotonic()
        if fresh or now - cls._idx_t > 1.0:
            d = {}
            try:
                for e in os.scandir(AUDIO_DIR):
                    if e.is_file() and not e.name.endswith(cls.SKIP) and e.stat().st_size > 20 * 1024:
                        d[e.name.rsplit(".", 1)[0]] = e.path
            except OSError:
                pass
            cls._idx, cls._idx_t = d, now
        return cls._idx

    @classmethod
    def find(cls, vid: str, fresh: bool = False):
        return cls._index(fresh).get(_safe_id(vid))

    def path(self, vid: str, touch: bool = False, fresh: bool = True):
        p = self.find(vid, fresh)
        if p and touch:
            try:
                os.utime(p, None)                # "recently played" for the LRU eviction
            except OSError:
                pass
        return p

    def status(self, vid: str) -> str:
        if self.find(vid):
            return "cached"
        return self.state.get(vid, "")

    def counts(self, items) -> tuple:
        songs = [it for it in items if it.get("kind", "song") == "song"]
        return sum(1 for it in songs if self.find(it["id"])), len(songs)

    # ---- downloads
    def want(self, items, prio: int = 1):
        """prio 0 = now (the song playing) · 1 = the next songs · 2 = the rest of an album / playlist"""
        if not self.enabled:
            return
        with self.cv:
            for it in items:
                vid, url = it.get("id"), it.get("url")
                if not vid or not url or it.get("kind", "song") != "song" or self.find(vid, True):
                    continue
                st = self.state.get(vid)
                if st == "loading" or (st == "queued" and prio >= self.prio_of.get(vid, 9)):
                    continue
                if st != "queued" and time.time() - self.failed.get(vid, 0) < 120:
                    continue
                self.state[vid], self.prio_of[vid] = "queued", prio
                self.n += 1
                heapq.heappush(self.heap, (prio, self.n, vid, url))
            self.cv.notify_all()
        self._spawn()

    def _spawn(self):
        self.threads = [t for t in self.threads if t.is_alive()]
        while len(self.threads) < self.workers and not self.closed:
            t = threading.Thread(target=self._run, daemon=True)
            t.start()
            self.threads.append(t)

    def _run(self):
        while not self.closed:
            with self.cv:
                while not self.heap and not self.closed:
                    if not self.cv.wait(timeout=20) and not self.heap:
                        return                   # idle: the thread ends, _spawn() starts a new one when needed
                if self.closed:
                    return
                prio, _, vid, url = heapq.heappop(self.heap)
                if self.state.get(vid) != "queued" or self.prio_of.get(vid, prio) < prio or self.find(vid, True):
                    if self.state.get(vid) == "queued" and self.find(vid, True):
                        self.state.pop(vid, None)
                    continue
                self.state[vid] = "loading"
            ok = self._download(vid, url)
            with self.cv:
                self.state.pop(vid, None)
                self.prio_of.pop(vid, None)
                if not ok:
                    self.failed[vid] = time.time()
            if ok:
                self.evict()

    def _download(self, vid: str, url: str) -> bool:
        try:
            os.makedirs(AUDIO_DIR, exist_ok=True)
            cmd = ["yt-dlp", "-f", "bestaudio[ext=m4a]/bestaudio", "--no-playlist", "--no-warnings", "--quiet", "--no-progress",
                   "-o", os.path.join(AUDIO_DIR, _safe_id(vid) + ".%(ext)s")]
            if self.cookies:
                cmd += ["--cookies-from-browser", str(self.cookies)]
            subprocess.run(cmd + [url], capture_output=True, timeout=300)
            return self.find(vid, True) is not None
        except Exception as e:
            log(f"cache {vid}: {e!r}")
            return False

    def evict(self):
        try:
            keep = {_safe_id(v) for v in self.protect}
            files, total = [], 0
            for e in os.scandir(AUDIO_DIR):
                if e.is_file() and not e.name.endswith(self.SKIP):
                    st = e.stat()
                    files.append((st.st_mtime, st.st_size, e.path, e.name.rsplit(".", 1)[0]))
                    total += st.st_size
            for _, size, p, base in sorted(files):
                if total <= self.max:
                    break
                if base not in keep:
                    os.remove(p)
                    total -= size
            self._index(True)
        except OSError:
            pass

    def close(self):
        self.closed = True
        with self.cv:
            self.cv.notify_all()


class YtmPlayer(MpvBackend):
    """Owns an mpv process (JSON IPC) + the queue. Acts as the lyrics backend: exact position from mpv,
    exact metadata from the queue item."""
    name = "ytm"
    PROPS = MpvBackend.PROPS + ("playlist-pos",)

    def __init__(self, state: State, cfg):
        super().__init__(state, None)
        self.cfg, self.proc, self.lock = cfg, None, threading.RLock()
        self.queue: list[dict] = []
        self.idx, self.expect, self.started, self.fails = -1, False, 0.0, 0
        self.volume, self.repeat = int(getattr(cfg, "volume", 70)), "off"
        self.radio_busy, self.closed = False, False
        self.cache = AudioCache(cfg)                                   # downloaded songs: instant starts, gapless joins, seamless replays
        self.mpl: list = []                                            # ids in mpv's own playlist: [playing, (next — appended for a gapless join)]
        self.gapless = bool(getattr(cfg, "ytm_gapless", True))
        self.ahead = max(1, int(getattr(cfg, "ytm_cache_ahead", 3) or 3))
        self.dirty, self.saved_t = False, 0.0
        self.sock_path = os.path.join(tempfile.gettempdir(), f"lyricglow-mpv-{os.getpid()}.sock")

    # ---- process / socket
    def missing(self) -> str:
        pkg = "pkg install" if IS_TERMUX else "sudo pacman -S"
        if not shutil.which("mpv"):
            return f"mpv not found — {pkg} mpv"
        if not shutil.which("yt-dlp"):
            return f"yt-dlp not found — {pkg} yt-dlp"
        return ""

    def ensure(self) -> bool:
        with self.lock:
            if self.closed:                      # never respawn mpv after shutdown (the poller thread outlives us briefly)
                return False
            if self.proc and self.proc.poll() is None and self.s:
                return True
            if self.proc is None or self.proc.poll() is not None:
                miss = self.missing()
                if miss:
                    self.err = miss
                    return False
                try:
                    os.remove(self.sock_path)
                except OSError:
                    pass
                self.s = None
                args = ["mpv", "--idle=yes", "--no-video", "--no-terminal", "--really-quiet", "--force-window=no",
                        "--audio-display=no", "--gapless-audio=yes", "--ytdl-format=bestaudio/best", f"--volume={self.volume}",
                        f"--input-ipc-server={self.sock_path}", *list(getattr(self.cfg, "mpv_args", None) or [])]
                if getattr(self.cfg, "ytm_cookies_browser", None):     # e.g. "firefox": lets yt-dlp play as your logged-in account
                    args.append(f"--ytdl-raw-options=cookies-from-browser={self.cfg.ytm_cookies_browser}")
                self.proc = subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            for _ in range(60):
                if os.path.exists(self.sock_path) and self._connect(self.sock_path):
                    self.err = ""
                    return True
                if self.proc.poll() is not None:
                    break
                time.sleep(0.1)
            self.err = "could not start mpv (check `lyricglow doctor`)"
            return False

    def cmd(self, *args) -> bool:
        if not self.ensure():
            return False
        with self.lock:
            try:
                self.s.sendall(json.dumps({"command": list(args)}).encode() + b"\n")
                return True
            except OSError:
                self.s = None
                return False

    def _query(self):
        with self.lock:
            return super()._query()

    def shutdown(self):
        self.cache.close()
        self.save_queue(True)
        with self.lock:
            self.closed = True
            try:
                if self.s:
                    self.s.sendall(b'{"command":["quit"]}\n')
            except Exception:
                pass
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=2)
            except Exception:
                self.proc.kill()
        try:
            os.remove(self.sock_path)
        except OSError:
            pass

    # ---- queue / transport. Songs play from the audio cache when they are on disk: instant starts, gapless joins, seamless replays.
    QFILE = os.path.join(os.path.dirname(CONF), "queue.json")

    def src_for(self, item: dict) -> str:
        return self.cache.path(item["id"], touch=True) or item["url"]

    def _next_index(self):
        if not self.queue or self.idx < 0 or self.repeat == "one":       # repeat-one loops the file inside mpv (loop-file)
            return None
        ni = self.idx + 1
        if ni >= len(self.queue):
            return 0 if self.repeat == "all" else None
        return ni

    def _prefetch(self):
        """download the current + next songs now; keep the whole queue safe from cache eviction"""
        with self.lock:
            if not self.queue or not (0 <= self.idx < len(self.queue)):
                return
            cur = self.queue[self.idx]
            nxt = self.queue[self.idx + 1: self.idx + 1 + self.ahead]
            if self.repeat == "all" and len(nxt) < self.ahead:
                nxt = nxt + self.queue[: self.ahead - len(nxt)]
            self.cache.protect = {q["id"] for q in self.queue}
        self.cache.want([cur], 0)
        self.cache.want(nxt, 1)

    def _refill(self):
        """gapless: as soon as the NEXT song is on disk, hand it to mpv so it joins the current one without a gap"""
        if not self.gapless:
            return
        with self.lock:
            if len(self.mpl) != 1 or not (0 <= self.idx < len(self.queue)) or self.closed:
                return
            ni = self._next_index()
            if ni is None:
                return
            nxt = self.queue[ni]
            p = self.cache.path(nxt["id"])
            if not p:
                return
            self.mpl.append(nxt["id"])
        if not self.cmd("loadfile", p, "append"):
            with self.lock:
                self.mpl = self.mpl[:1]

    def _resync(self):
        """the queue changed (reorder / insert / remove / repeat): make sure the entry mpv has lined up next is still the right one"""
        if not self.gapless:
            return
        drop = False
        with self.lock:
            ni = self._next_index()
            want = self.queue[ni]["id"] if ni is not None else None
            if len(self.mpl) >= 2 and self.mpl[1] != want:
                self.mpl, drop = self.mpl[:1], True
        if drop:
            self.cmd("playlist-remove", 1)
        self._refill()

    def play_index(self, i: int):
        with self.lock:
            if not (0 <= i < len(self.queue)):
                return
            self.idx, self.expect, self.started = i, True, time.monotonic()
            item = self.queue[i]
            self.mpl = [item["id"]]
        self.cmd("loadfile", self.src_for(item), "replace")
        self.cmd("set_property", "loop-file", "inf" if self.repeat == "one" else "no")
        self.cmd("set_property", "pause", False)
        self._prefetch()
        self._refill()
        self.dirty = True
        if self.cfg.ytm_radio and len(self.queue) - i <= 2:
            self.extend_radio()

    def play_items(self, items: list[dict], start: int = 0, cache_n: int = 0):
        with self.lock:
            self.queue = list(items)
        if cache_n:
            self.cache.want([it for it in items[:cache_n]], 2)           # an album is cached whole
        self.play_index(start)

    def enqueue(self, items: list[dict], next_up: bool = False, cache_n: int = 0) -> int:
        """add songs to the end (or right after the current song). returns how many were new"""
        with self.lock:
            have = {q["id"] for q in self.queue}
            new = [it for it in items if it["id"] not in have]
            at = min(self.idx + 1, len(self.queue)) if (next_up and self.idx >= 0) else len(self.queue)
            self.queue[at:at] = new
        if cache_n:
            self.cache.want(new[:cache_n], 2)
        if self.idx < 0 and new:
            self.play_index(at)
        else:
            self._resync()
            self._prefetch()
        self.dirty = True
        return len(new)

    def remove(self, i: int):
        with self.lock:
            if not (0 <= i < len(self.queue)):
                return
            self.queue.pop(i)
            if i < self.idx:
                self.idx -= 1
            elif i == self.idx:
                if self.queue:
                    self.idx = min(i, len(self.queue) - 1)
                    threading.Thread(target=self.play_index, args=(self.idx,), daemon=True).start()
                else:
                    self.idx, self.expect, self.mpl = -1, False, []
                    self.cmd("stop")
        self._resync()
        self.dirty = True

    def move(self, i: int, d: int) -> int:
        """reorder: move queue item i by d places (the playing song keeps playing). returns its new index"""
        with self.lock:
            j = i + d
            if not (0 <= i < len(self.queue) and 0 <= j < len(self.queue)):
                return i
            self.queue[i], self.queue[j] = self.queue[j], self.queue[i]
            if self.idx == i:
                self.idx = j
            elif self.idx == j:
                self.idx = i
        self._resync()
        self.dirty = True
        return j

    def clear_upcoming(self) -> int:
        with self.lock:
            n = len(self.queue) - (self.idx + 1)
            if n > 0:
                del self.queue[self.idx + 1:]
        self._resync()
        self.dirty = True
        return max(n, 0)

    def save_queue(self, force: bool = False):
        if not (self.dirty or force):
            return
        self.dirty = False
        try:
            with self.lock:
                data = {"v": 1, "idx": self.idx, "queue": [{k: v for k, v in q.items() if isinstance(v, (str, int, float, type(None)))} for q in self.queue[:500]]}
            os.makedirs(os.path.dirname(self.QFILE), exist_ok=True)
            tmp = self.QFILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f)
            os.replace(tmp, self.QFILE)
        except OSError as e:
            log(f"save queue: {e!r}")

    def load_queue(self) -> int:
        """restore the last session's queue (not playing — open it with Q)"""
        try:
            with open(self.QFILE, encoding="utf-8") as f:
                data = json.load(f)
            q = [it for it in data.get("queue", []) if isinstance(it, dict) and it.get("id") and it.get("url") and it.get("title")]
        except (OSError, ValueError):
            return 0
        with self.lock:
            self.queue, self.idx = q, -1
        return len(q)

    def next(self, auto: bool = False):
        with self.lock:
            if not self.queue:
                return
            if auto and self.repeat == "one":
                i = self.idx
            else:
                i = self.idx + 1
                if i >= len(self.queue):
                    if self.repeat == "all":
                        i = 0
                    else:
                        self.expect = False
                        return
        self.play_index(i)

    def prev(self):
        try:
            if self.state.position() > 5.0 or self.idx <= 0:
                self.cmd("seek", 0, "absolute")
                return
        except Exception:
            pass
        self.play_index(self.idx - 1)

    def toggle_pause(self):
        self.cmd("cycle", "pause")

    def seek(self, sec: float):
        self.cmd("seek", sec, "relative")

    def change_volume(self, d: int) -> int:
        self.volume = int(clamp(self.volume + d, 0, 130))
        self.cmd("set_property", "volume", self.volume)
        return self.volume

    def cycle_repeat(self) -> str:
        self.repeat = {"off": "all", "all": "one", "one": "off"}[self.repeat]
        self.cmd("set_property", "loop-file", "inf" if self.repeat == "one" else "no")
        self._resync()
        return self.repeat

    def shuffle_upcoming(self):
        with self.lock:
            tail = self.queue[self.idx + 1:]
            random.shuffle(tail)
            self.queue[self.idx + 1:] = tail
        self._resync()
        self.dirty = True

    def extend_radio(self):
        if self.radio_busy or not (0 <= self.idx < len(self.queue)):
            return
        self.radio_busy = True
        vid = self.queue[self.idx]["id"]

        def work():
            try:
                items = related_ytm(vid)
                if items:
                    with self.lock:
                        have = {q["id"] for q in self.queue}
                        self.queue += [it for it in items if it["id"] not in have]
            except Exception as e:
                log(f"radio: {e!r}")
            finally:
                self.radio_busy = False

        threading.Thread(target=work, daemon=True).start()

    # ---- lyrics backend interface
    def poll(self) -> bool:
        if self.dirty and time.monotonic() - self.saved_t > 3.0:
            self.saved_t = time.monotonic()
            self.save_queue()
        if not self.queue or self.idx < 0:
            return False
        if not self.ensure():
            return False
        try:
            got, mono = self._query()
        except Exception as e:
            log(f"ytm query: {e!r}")
            self.s = None
            return False
        now = time.monotonic()
        pos = got.get("playlist-pos")
        if self.gapless and isinstance(pos, int) and pos >= 1 and len(self.mpl) > pos:        # mpv joined the next song by itself (no gap)
            nid, moved = self.mpl[pos], False
            with self.lock:
                for k in list(range(self.idx + 1, len(self.queue))) + list(range(0, self.idx + 1)):
                    if self.queue[k]["id"] == nid:
                        self.idx, self.started, moved = k, now, True
                        break
                self.mpl = self.mpl[pos:]
            for _ in range(pos):
                self.cmd("playlist-remove", 0)
            if moved:
                self.dirty = True
                self._prefetch()
                if self.cfg.ytm_radio and len(self.queue) - self.idx <= 2:
                    self.extend_radio()
        self._refill()
        if not (0 <= self.idx < len(self.queue)):
            return False
        item = self.queue[self.idx]
        if got.get("path") is None and self.expect:
            if now - self.started > 1.5:                 # mpv went idle: track ended (or failed to load)
                self.fails = self.fails + 1 if now - self.started < 4.0 else 0
                if self.fails >= 3:
                    self.expect, self.fails = False, 0
                    self.err = "playback keeps failing — update yt-dlp (sudo pacman -Syu yt-dlp / yt-dlp -U)"
                else:
                    self.next(auto=True)
        elif got.get("time-pos") is not None:
            self.fails = 0
        tpos = got.get("time-pos")
        tr = make_track(item["title"], item["artist"], item["album"], item["dur"] or got.get("duration"), item["art"], item["url"])
        if not tr:
            return False
        self.state.set(tr, (not got.get("pause")) and tpos is not None, float(tpos or 0.0), mono, 1.0, "ytm")
        return True



class CmdBackend:
    """Run any command that prints the current track. JSON object (keys: title, artist, album, position,
    duration, playing|status, art) or tab-separated: status<TAB>position<TAB>duration<TAB>artist<TAB>title<TAB>album."""
    name = "cmd"

    def __init__(self, state: State, cmd: str):
        self.state, self.cmd, self.err = state, cmd, ""

    def poll(self) -> bool:
        t0 = time.monotonic()
        try:
            rc, out = _run(self.cmd, 5)
        except Exception as e:
            self.err = f"--cmd failed: {e}"
            return False
        mono = (t0 + time.monotonic()) / 2.0
        out = out.strip()
        if rc != 0 or not out:
            return False
        self.err = ""
        d = {}
        try:
            obj = json.loads(out.splitlines()[0] if not out.startswith("{") or "\n" not in out else out)
            d = obj if isinstance(obj, dict) else {}
        except ValueError:
            f = out.splitlines()[0].split("\t")
            if len(f) >= 5:
                d = dict(status=f[0], position=f[1], duration=f[2], artist=f[3], title=f[4], album=f[5] if len(f) > 5 else "")
        if not d:
            self.err = "--cmd output is neither JSON nor the tab format (see README)"
            return False
        num = lambda *ks: next((float(d[k]) for k in ks if d.get(k) not in (None, "") and re.fullmatch(r"-?[\d.]+", str(d[k]))), None)
        st = d.get("playing", d.get("status", True))
        playing = st if isinstance(st, bool) else str(st).lower() in ("playing", "play", "true", "1", "yes")
        tr = make_track(d.get("title"), d.get("artist"), d.get("album", ""), num("duration", "length"),
                        d.get("art") or d.get("art_url") or "", d.get("uri") or d.get("url") or "")
        if not tr:
            return False
        self.state.set(tr, playing, num("position", "pos", "elapsed") or 0.0, mono, 1.0, "cmd")
        return True


# --------------------------------------------------------------------------- Discord Rich Presence (Linux only)
#
# Speaks Discord's local IPC protocol directly (no pypresence): frames are  <opcode u32 LE><length u32 LE><json>.
# You need a Discord application id (https://discord.com/developers/applications → New Application). The
# application's NAME is what friends see: "Listening to <name>".

class _Safe(dict):
    def __missing__(self, k):
        return ""


class DiscordRPC(threading.Thread):
    TYPES = {"playing": 0, "listening": 2, "watching": 3, "competing": 5}

    def __init__(self, state: State, cfg):
        super().__init__(daemon=True)
        self.state, self.cfg = state, cfg
        self.sock, self.stop, self.status = None, False, "starting"
        self.retry_at, self.last_sig, self.last_send, self.last_start = 0.0, None, 0.0, 0.0
        self.last_activity = None

    @staticmethod
    def supported() -> bool:
        return sys.platform.startswith("linux") and not IS_TERMUX

    @staticmethod
    def socket_paths() -> list[str]:
        dirs = [d for d in (os.environ.get("XDG_RUNTIME_DIR"), os.environ.get("TMPDIR"), "/tmp") if d]
        subs = ["", "app/com.discordapp.Discord/", "app/com.discordapp.DiscordCanary/", "snap.discord/", "snap.discord-canary/"]
        out = []
        for n in range(10):
            for d in dirs:
                for sub in subs:
                    pth = os.path.join(d, f"{sub}discord-ipc-{n}")
                    try:
                        if stat.S_ISSOCK(os.stat(pth).st_mode) and pth not in out:
                            out.append(pth)
                    except OSError:
                        pass
        return out

    # ---- wire format
    def _send(self, op: int, payload: dict):
        data = json.dumps(payload, separators=(",", ":")).encode()
        self.sock.sendall(struct.pack("<II", op, len(data)) + data)

    def _recv(self, timeout: float = 2.0):
        self.sock.settimeout(timeout)
        hdr = b""
        while len(hdr) < 8:
            chunk = self.sock.recv(8 - len(hdr))
            if not chunk:
                raise ConnectionError("discord closed the socket")
            hdr += chunk
        op, ln = struct.unpack("<II", hdr)
        body = b""
        while len(body) < ln:
            chunk = self.sock.recv(ln - len(body))
            if not chunk:
                raise ConnectionError("discord closed the socket")
            body += chunk
        try:
            return op, json.loads(body or b"{}")
        except ValueError:
            return op, {}

    def connect(self) -> bool:
        for path in self.socket_paths():
            s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            s.settimeout(2.0)
            try:
                s.connect(path)
                self.sock = s
                self._send(0, {"v": 1, "client_id": str(self.cfg.discord_client_id)})
                for _ in range(4):                       # wait for READY (Discord may send other frames first)
                    op, obj = self._recv(3.0)
                    if op == 1 and obj.get("evt") == "READY":
                        return True
                    if op == 2:
                        raise ConnectionError(obj.get("message", "handshake refused (bad client id?)"))
            except Exception as e:
                log(f"discord connect {path}: {e!r}")
                self.status = f"handshake failed: {e}"[:80]
                try:
                    s.close()
                except OSError:
                    pass
                self.sock = None
        return False

    def set_activity(self, act: dict | None):
        self._send(1, {"cmd": "SET_ACTIVITY", "args": {"pid": os.getpid(), "activity": act}, "nonce": uuid.uuid4().hex})
        self.last_activity = act
        op, obj = self._recv(2.0)
        while op in (3,):                                  # PING
            self._send(4, obj)
            op, obj = self._recv(2.0)
        if obj.get("evt") == "ERROR":
            d = obj.get("data") or {}
            self.status = f"rejected: {d.get('message', d)}"[:90]
            log(f"discord rejected activity: {obj}")
        else:
            self.status = "connected"

    # ---- content
    def _fmt(self, tpl: str, tr: Track, player: str | None) -> str:
        url = tr.uri if str(tr.uri).startswith("http") else ""
        s = str(tpl).format_map(_Safe(title=tr.title, artist=tr.artist, album=tr.album, player=player or "", url=url))
        s = s.strip()[:128]
        return s + "\u200b" if 0 < len(s) < 2 else (s or "\u200b\u200b")

    def build(self, tr: Track, playing: bool, pos: float, player: str | None) -> dict:
        c = self.cfg
        act = {"type": self.TYPES.get(str(c.discord_type).lower(), 2),
               "details": self._fmt(c.discord_details, tr, player),
               "state": self._fmt(c.discord_state + ("" if playing else " (paused)"), tr, player)}
        mode = str(c.discord_timestamps).lower()
        if playing and mode != "off":
            start = int(time.time() - pos)
            act["timestamps"] = {"start": start}
            if mode == "bar" and tr.duration:
                act["timestamps"]["end"] = int(start + tr.duration)
        assets = {}
        art = str(c.discord_art).lower()
        if art == "url" and str(tr.art_url).startswith("http"):
            assets["large_image"] = tr.art_url
        elif art in ("url", "app") and c.discord_large_image:
            assets["large_image"] = c.discord_large_image
        if assets.get("large_image") and c.discord_large_text:
            assets["large_text"] = self._fmt(c.discord_large_text, tr, player)
        if c.discord_small_image:
            assets["small_image"] = c.discord_small_image
            if c.discord_small_text:
                assets["small_text"] = self._fmt(c.discord_small_text, tr, player)
        if assets:
            act["assets"] = assets
        btns = []
        for b in (c.discord_buttons or [])[:2]:
            if not isinstance(b, dict):
                continue
            url = str(b.get("url", "")).format_map(_Safe(url=tr.uri if str(tr.uri).startswith("http") else "", title=tr.title))
            if url.startswith(("http://", "https://")) and b.get("label"):
                btns.append({"label": str(b["label"])[:32], "url": url})
        if btns:
            act["buttons"] = btns
        return act

    # ---- main loop
    def run(self):
        c = self.cfg
        while not self.stop:
            try:
                if self.sock is None:
                    if time.time() < self.retry_at:
                        time.sleep(0.5)
                        continue
                    if self.connect():
                        self.status, self.last_sig = "connected", None
                    else:
                        self.status = self.status if self.status.startswith("handshake") else "discord not running"
                        self.sock, self.retry_at = None, time.time() + 15.0
                        continue
                tr, playing, player = self.state.snapshot()
                if str(c.discord_scope).lower() == "ytm" and player != "ytm":
                    tr = None
                hide_paused = str(c.discord_paused).lower() != "show"
                now = time.time()
                if tr is None or (not playing and hide_paused):
                    act, sig, start = None, ("clear",), 0.0
                else:
                    pos = self.state.position()
                    start = now - pos
                    act, sig = self.build(tr, playing, pos, player), (tr.key, playing)
                seek = bool(act) and playing and self.last_sig == sig and abs(start - self.last_start) > 2.5
                if sig != self.last_sig or seek:
                    if act is None and self.last_activity is None:
                        self.last_sig = sig                  # nothing is shown, so there is nothing to clear (and no rate-limit spent)
                    elif act is None or now - self.last_send >= float(c.discord_min_interval):
                        self.set_activity(act)               # clears go out immediately; updates respect the interval
                        self.last_sig, self.last_send, self.last_start = sig, now, start
                time.sleep(0.5)
            except (OSError, ConnectionError, struct.error) as e:
                log(f"discord: {e!r}")
                self.close()
                self.status = "connection lost — retrying"
                self.retry_at = time.time() + 5.0

    def close(self):
        try:
            if self.sock:
                self.sock.close()
        except OSError:
            pass
        self.sock = None

    def shutdown(self):
        self.stop = True
        try:
            if self.sock:
                self.set_activity(None)                    # take the presence down when lyricglow quits
        except Exception:
            pass
        self.close()


class Composite(threading.Thread):
    """Polls backends in priority order; the first one that finds a playing/paused track wins."""

    def __init__(self, state: State, backends: list, interval: float = 0.4):
        super().__init__(daemon=True)
        self.state, self.backends, self.interval, self.active = state, backends, interval, ""

    def run(self):
        while True:
            found = False
            for b in self.backends:
                try:
                    if b.poll():
                        found, self.active = True, b.name
                        break
                except Exception as e:
                    log(f"{b.name} poll: {e!r}")
            if found:
                self.state.error = ""
            else:
                self.state.clear()
                self.state.error = next((b.err for b in self.backends if getattr(b, "err", "")), "")
            time.sleep(self.interval)


DEMO_LINES = [
    "Midnight hums beneath the city light",
    "Every heartbeat paints the glass in gold",
    "Hold the silence, let it breathe tonight",
    "Words are starlight, soft and bold",
    None,  # long instrumental gap
    "Carry me through the electric rain",
    "Dissolve the dark into a golden flame",
    "Every syllable a spark, every breath a name",
    "We are glowing, glowing, never the same",
]


def demo_ttml() -> str:
    t, out = 3.0, []
    for text in DEMO_LINES:
        if text is None:
            t += 9.0
            continue
        b, spans = t, []
        for w in text.split():
            dur = 0.26 + 0.04 * len(w)
            if len(w) >= 7:  # split long words into two syllables
                h = len(w) // 2
                spans.append((w[:h], dur * 0.5))
                spans.append((w[h:] + " ", dur * 0.5))
            else:
                spans.append((w + " ", dur))
        body = ""
        for s, d in spans:
            body += f'<span begin="{t:.3f}" end="{t + d:.3f}">{s}</span>'
            t += d
        out.append(f'<p begin="{b:.3f}" end="{t:.3f}">{body.rstrip()}</p>')
        t += 0.55
    return '<?xml version="1.0" encoding="UTF-8"?><tt xmlns="http://www.w3.org/ns/ttml"><body><div>' + "".join(out) + "</div></body></tt>"


class DemoBackend:
    name = "demo"

    def __init__(self, state: State):
        self.state, self.err, self.t0 = state, "", time.monotonic()
        self.tr = make_track("Neon Rain", "lyricglow demo", "Preview", 62.0)

    def poll(self) -> bool:
        now = time.monotonic()
        self.state.set(self.tr, True, (now - self.t0) % 66.0, now, 1.0, "demo")
        return True


# --------------------------------------------------------------------------- network: lyrics + art

def http_get(url: str, timeout: float = 12.0) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def fetch_ttml(track: Track, apis: list[str]) -> str:
    ck = hashlib.sha1(track.key.encode("utf-8", "ignore")).hexdigest()
    path = os.path.join(CACHE, "ttml", ck + ".xml")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            return f.read()
    dur = int(round(track.duration)) if track.duration else None
    tc = clean_title(track.title) or track.title

    def V(title, album, d):
        p = {"s": title, "a": track.artist}
        if album:
            p["al"] = album
        if d:
            p["d"] = d
        return p

    variants = [V(tc, track.album, dur)]
    if tc != track.title:
        variants.append(V(track.title, track.album, dur))
    if track.album:
        variants.append(V(tc, None, dur))
    if dur:
        variants.append(V(tc, track.album, None))
    variants.append(V(tc, None, None))
    uniq, seen = [], set()
    for v in variants:
        k = json.dumps(v, sort_keys=True)
        if k not in seen:
            seen.add(k)
            uniq.append(v)
    last = None
    for api in apis:
        net_fail = False
        for p in uniq:
            url = f"{api.rstrip('/')}/getLyrics?{urllib.parse.urlencode(p)}"
            try:
                body = http_get(url)
            except urllib.error.HTTPError as e:
                last = f"HTTP {e.code}"
                continue
            except Exception as e:
                last, net_fail = str(e), True
                break
            try:
                data = json.loads(body)
            except Exception:
                continue
            ttml = data.get("ttml") if isinstance(data, dict) else None
            if ttml and "<p" in ttml:
                os.makedirs(os.path.dirname(path), exist_ok=True)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(ttml)
                return ttml
        if not net_fail:
            break
    raise LookupError(last or "no lyrics")


def load_art(url: str):
    if not url or Image is None:
        return None
    try:
        if url.startswith("file://"):
            with open(urllib.parse.unquote(url[7:]), "rb") as f:
                data = f.read()
        elif url.startswith("http"):
            p = os.path.join(CACHE, "art", hashlib.sha1(url.encode()).hexdigest())
            if os.path.exists(p):
                with open(p, "rb") as f:
                    data = f.read()
            else:
                data = http_get(url, 10)
                os.makedirs(os.path.dirname(p), exist_ok=True)
                with open(p, "wb") as f:
                    f.write(data)
        else:
            return None
        img = Image.open(io.BytesIO(data))
        img.load()
        return square_thumb(img)
    except Exception as e:
        log(f"art: {e!r}")
        return None


def square_thumb(img, size: int = 384):
    img = img.convert("RGB")
    w, h = img.size
    s = min(w, h)
    img = img.crop(((w - s) // 2, (h - s) // 2, (w - s) // 2 + s, (h - s) // 2 + s))
    return img.resize((size, size))


def demo_art():
    if Image is None:
        return None
    n = 256
    buf = bytearray()
    for y in range(n):
        for x in range(n):
            dx, dy = (x - n * 0.5) / n, (y - n * 0.62) / n
            d = math.hypot(dx, dy)
            sun = math.exp(-(d * 5.5) ** 2)
            h = 0.78 - 0.30 * (y / n) + 0.04 * math.sin(x * 0.12)
            r, g, b = hsl(h, 0.8, 0.22 + 0.45 * sun)
            r, g, b = mix((r, g, b), (255, 220, 190), sun * 0.8)
            buf += bytes((int(r), int(g), int(b)))
    return Image.frombytes("RGB", (n, n), bytes(buf))


# --------------------------------------------------------------------------- animated cover ("canvas")
#
# Sources, tried in the order you list them in `canvas = [...]` (default: none — nothing is fetched):
#   local      files you put in ~/.config/lyricglow/canvas/   ("Artist - Title.mp4", "Album.webp", "<spotify id>.mp4", ...)
#   endpoints  URL templates you configure (e.g. your own self-hosted Spotify-Canvas API). {artist} {title} {album} {spotify_id}
#   apple      Apple Music motion artwork through a community REST wrapper (artist+album are sent to that server)
# The response of an endpoint is searched for a video URL, so any JSON shape works.

CANVAS_DIR = os.path.join(os.path.dirname(CONF), "canvas")
VIDEO_EXT = (".mp4", ".m4v", ".mov", ".webm", ".mkv")
IMAGE_EXT = (".gif", ".webp", ".apng")
APPLE_DEFAULT_APIS = ["https://artwork.m8tec.top", "https://amaa.tromme.app"]


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def canvas_local(track: Track, dirs: list[str]):
    names = [f"{track.artist} - {track.title}", track.title, f"{track.artist} - {track.album}", track.album, track.spotify_id]
    want = [_norm(n) for n in names if n]
    for d in dirs:
        d = os.path.expanduser(d)
        if not os.path.isdir(d):
            continue
        files = {}
        for f in os.listdir(d):
            stem, ext = os.path.splitext(f)
            if ext.lower() in VIDEO_EXT + IMAGE_EXT + (".m3u8",):
                files.setdefault(_norm(stem), os.path.join(d, f))
        for w in want:
            if w in files:
                return files[w]
    return None


def extract_media_url(obj):
    """Find the best video/animation URL anywhere in an arbitrary JSON document (or plain-text body)."""
    cands = []

    def score(url: str, path: list[str]):
        u = url.lower().split("?")[0]
        if u.endswith(VIDEO_EXT):
            s = 3.0
        elif u.endswith(".m3u8") or ".m3u8" in url.lower():
            s = 2.0
        elif u.endswith(IMAGE_EXT):
            s = 1.0
        else:
            return
        blob = " ".join(path) + " " + u
        if "square" in blob:
            s += 2
        if "canvas" in blob:
            s += 1
        if "tall" in blob or "portrait" in blob:
            s -= 0.5
        cands.append((s, url))

    def walk(o, path):
        if isinstance(o, str):
            for tok in o.split():
                if tok.startswith(("http://", "https://")):
                    score(tok, path)
        elif isinstance(o, dict):
            for k, v in o.items():
                walk(v, path + [str(k).lower()])
        elif isinstance(o, list):
            for v in o:
                walk(v, path)

    walk(obj, [])
    return max(cands)[1] if cands else None


def _json_or_text(body: bytes):
    try:
        return json.loads(body)
    except ValueError:
        return body.decode("utf-8", "ignore").strip()


def canvas_endpoints(track: Track, templates: list[str], headers: dict):
    vals = dict(artist=track.artist, title=track.title, album=track.album, spotify_id=track.spotify_id,
                duration=int(track.duration or 0))
    for tpl in templates:
        need = re.findall(r"\{(\w+)\}", tpl)
        if any(not vals.get(k) for k in need):
            continue                                   # e.g. a Spotify-id template while playing from Firefox
        url = tpl.format(**{k: urllib.parse.quote(str(v)) for k, v in vals.items()})
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, **(headers or {})})
            with urllib.request.urlopen(req, timeout=12) as r:
                hit = extract_media_url(_json_or_text(r.read()))
            if hit:
                return hit
        except Exception as e:
            log(f"canvas endpoint {tpl}: {e!r}")
    return None


def canvas_apple(track: Track, bases: list[str]):
    album = track.album or track.title
    if not (track.artist and album):
        return None
    q = urllib.parse.urlencode({"artist": track.artist, "album": album})
    for base in bases:
        try:
            hit = extract_media_url(_json_or_text(http_get(f"{base.rstrip('/')}/api/v1/artwork/search?{q}", 15)))
            if hit:
                return hit
        except Exception as e:
            log(f"apple artwork {base}: {e!r}")
    return None


def _square_resize(im, S):
    w, h = im.size
    s = min(w, h)
    return im.convert("RGB").crop(((w - s) // 2, (h - s) // 2, (w - s) // 2 + s, (h - s) // 2 + s)).resize((S, S), Image.LANCZOS)


def decode_canvas(src: str, S: int, fps: int, max_s: float):
    """-> uint8 array (N, S, S, 3): centre-cropped square loop at constant fps."""
    low = src.lower().split("?")[0]
    if low.endswith(IMAGE_EXT) and Image is not None:
        path = src
        if src.startswith("http"):
            path = os.path.join(CACHE, "canvas", hashlib.sha1(src.encode()).hexdigest() + os.path.splitext(low)[1])
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "wb") as f:
                f.write(http_get(src, 30))
        im = Image.open(path)
        frames, durs = [], []
        for i in range(min(getattr(im, "n_frames", 1), 900)):
            im.seek(i)
            frames.append(im.convert("RGB").copy())
            durs.append(max(20, im.info.get("duration", 80) or 80) / 1000.0)
        total = min(sum(durs), max_s)
        out, t, idx, acc = [], 0.0, 0, durs[0]
        while t < total - 1e-6 and frames:
            while idx < len(frames) - 1 and acc <= t:
                idx += 1
                acc += durs[idx]
            out.append(np.asarray(_square_resize(frames[idx], S)))
            t += 1.0 / fps
        return np.stack(out)
    if not shutil.which("ffmpeg"):
        raise RuntimeError("ffmpeg not installed (sudo pacman -S ffmpeg)")
    net = ["-user_agent", UA] if src.startswith("http") else []      # http-only option: rejected for local files
    cmd = ["ffmpeg", "-v", "error", "-nostdin", *net, "-i", src, "-an", "-t", str(max_s),
           "-vf", f"fps={fps},crop='min(iw,ih)':'min(iw,ih)',scale={S}:{S}:flags=lanczos",
           "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
    r = subprocess.run(cmd, capture_output=True, timeout=120)
    n = len(r.stdout) // (S * S * 3)
    if r.returncode != 0 or n < 4:
        raise RuntimeError("ffmpeg could not decode it: " + r.stderr.decode("utf-8", "ignore")[-200:])
    return np.frombuffer(r.stdout[: n * S * S * 3], np.uint8).reshape(n, S, S, 3)


def demo_canvas(S: int = 320, n: int = 72):
    """Synthetic loop for `--demo`: drifting colour waves with a pulsing sun."""
    y, x = np.mgrid[0:S, 0:S].astype(np.float32) / S
    out = np.empty((n, S, S, 3), np.uint8)
    for i in range(n):
        ph = 2 * math.pi * i / n
        v = np.sin(6 * x + ph) + np.sin(5 * y - ph) + np.sin(7 * (x + y) + 2 * ph)
        r = np.hypot(x - 0.5 - 0.18 * math.cos(ph), y - 0.58 - 0.12 * math.sin(ph))
        sun = np.exp(-(r * 4.2) ** 2) * (0.85 + 0.15 * math.sin(3 * ph))
        h = 0.78 - 0.3 * y + 0.05 * v
        rgb = np.stack([0.5 + 0.5 * np.sin(6.283 * (h + o)) for o in (0.0, 0.33, 0.67)], -1) * (0.35 + 0.2 * v[..., None] / 3)
        rgb = rgb * (1 - sun[..., None]) + np.array([1.0, 0.86, 0.74]) * sun[..., None]
        out[i] = np.clip(rgb * 255, 0, 255).astype(np.uint8)
    return out


class CanvasData:
    def __init__(self, frames, fps: int, source: str):
        self.frames, self.fps, self.source = frames, fps, source


class CanvasLoader:
    def __init__(self, cfg):
        self.sources = [s.strip().lower() for s in (cfg.canvas if isinstance(cfg.canvas, list) else str(cfg.canvas or "").split(",")) if s.strip()]
        self.dirs = [cfg.canvas_dir] if getattr(cfg, "canvas_dir", None) else [CANVAS_DIR]
        self.endpoints = list(getattr(cfg, "canvas_endpoint", None) or [])
        self.headers = dict(getattr(cfg, "canvas_header", None) or {})
        self.apple = list(getattr(cfg, "apple_api", None) or APPLE_DEFAULT_APIS)
        self.S, self.fps, self.secs = 320, int(getattr(cfg, "canvas_fps", 12)), float(getattr(cfg, "canvas_seconds", 6))

    @property
    def enabled(self) -> bool:
        return bool(self.sources)

    def resolve(self, track: Track):
        for s in self.sources:
            hit = None
            if s == "local":
                hit = canvas_local(track, self.dirs)
            elif s in ("endpoints", "spotify", "http"):
                hit = canvas_endpoints(track, self.endpoints, self.headers)
            elif s == "apple":
                hit = canvas_apple(track, self.apple)
            if hit:
                return s, hit
        return None, None

    def load(self, track: Track):
        os.makedirs(os.path.join(CACHE, "canvas"), exist_ok=True)
        neg = os.path.join(CACHE, "canvas", "none-" + hashlib.sha1((track.key + ",".join(self.sources)).encode()).hexdigest())
        if os.path.exists(neg) and time.time() - os.path.getmtime(neg) < 3 * 86400:
            return None
        src, loc = self.resolve(track)
        if not loc:
            open(neg, "w").close()
            return None
        ck = os.path.join(CACHE, "canvas", hashlib.sha1(f"{loc}|{self.S}|{self.fps}|{self.secs}".encode()).hexdigest() + ".npz")
        if os.path.exists(ck):
            z = np.load(ck)
            os.utime(ck)
            return CanvasData(z["frames"], int(z["fps"]), src)
        frames = decode_canvas(loc, self.S, self.fps, self.secs)
        np.savez_compressed(ck, frames=frames, fps=self.fps)
        files = sorted((f for f in glob.glob(os.path.join(CACHE, "canvas", "*.npz"))), key=os.path.getmtime)
        for f in files[:-24]:                                   # keep the 24 most recent loops
            os.remove(f)
        return CanvasData(frames, self.fps, src)


class Fetcher:
    """Fetches lyrics + cover art for the current track, off the render thread."""

    def __init__(self, apis, demo=False, canvas: "CanvasLoader | None" = None):
        self.apis, self.demo, self.cloader = apis, demo, canvas
        self.canvas: CanvasData | None = None
        self.canvas_status = "off"      # off | searching | none | ok | error
        self.canvas_note = ""
        self.gen = 0
        self.lyrics: Lyrics | None = None
        self.status = "idle"      # idle | loading | ok | none
        self.err = ""
        self.art = None
        self.palette = DEFAULT_PALETTE
        self.misses: dict = {}

    def request(self, track: Track | None, force: bool = False):
        self.gen += 1
        g = self.gen
        self.lyrics, self.art, self.err = None, None, ""
        self.canvas, self.canvas_note = None, ""
        self.canvas_status = "searching" if (track and self.cloader and self.cloader.enabled and np is not None) else "off"
        if track is None:
            self.status = "idle"
            return
        self.status = "loading"
        self.palette = fallback_palette(track.key)
        threading.Thread(target=self._lyrics, args=(g, track, force), daemon=True).start()
        threading.Thread(target=self._art, args=(g, track), daemon=True).start()
        if self.canvas_status == "searching":
            threading.Thread(target=self._canvas, args=(g, track), daemon=True).start()

    def _canvas(self, g, track):
        try:
            if self.demo:
                data = CanvasData(demo_canvas(), 12, "demo")
            else:
                data = self.cloader.load(track)
            if g == self.gen:
                self.canvas = data
                self.canvas_status = "ok" if data else "none"
                self.canvas_note = data.source if data else ""
        except Exception as e:
            log(f"canvas {track.key}: {e!r}")
            if g == self.gen:
                self.canvas_status, self.canvas_note = "error", str(e)[:120]

    def _lyrics(self, g, track, force):
        try:
            if self.demo:
                ttml = demo_ttml()
            else:
                if time.time() - self.misses.get(track.key, 0) < 300 and not force:
                    raise LookupError("recently not found")
                if force:
                    p = os.path.join(CACHE, "ttml", hashlib.sha1(track.key.encode("utf-8", "ignore")).hexdigest() + ".xml")
                    if os.path.exists(p):
                        os.remove(p)
                ttml = fetch_ttml(track, self.apis)
            ly = parse_ttml(ttml)
            if g == self.gen:
                self.lyrics, self.status = ly, "ok"
        except Exception as e:
            log(f"lyrics {track.key}: {e!r}")
            self.misses[track.key] = time.time()
            if g == self.gen:
                self.status, self.err = "none", str(e)

    def _art(self, g, track):
        img = demo_art() if self.demo else load_art(track.art_url)
        if img is not None and g == self.gen:
            try:
                pal = palette_from_image(img)
            except Exception as e:
                log(f"palette: {e!r}")
                pal = None
            if g == self.gen:
                self.art = img
                if pal:
                    self.palette = pal


# =========================================================================== shared UI state

PRESETS = [("desat", "sat", "mono → colour"), ("sat", "desat", "colour → mono"),
           ("desat", "desat", "monochrome"), ("sat", "sat", "full colour")]


def auto_low_end() -> bool:
    if os.environ.get("LYRICGLOW_LOW_END") in ("1", "true", "on"):
        return True
    try:
        return (os.cpu_count() or 4) <= 2
    except Exception:
        return False


# glow styles. kitty renderer: sigma/gain/tight/follow/pulse/aurora.  cell renderer: cell=(rx, ry, bloom_k, core_k, strip_k)
GLOW_STYLES = {
    "soft":   dict(sigma=1.0, gain=1.0, tight=0.0, follow="trail", pulse=0.0, aurora=False, cell=(10.0, 2.2, 0.26, 0.09, 0.035)),
    "neon":   dict(sigma=0.5, gain=1.7, tight=0.9, follow="trail", pulse=0.0, aurora=False, cell=(5.0, 1.2, 0.34, 0.15, 0.02)),
    "bloom":  dict(sigma=2.1, gain=1.3, tight=0.0, follow="trail", pulse=0.0, aurora=False, cell=(16.0, 3.4, 0.34, 0.10, 0.05)),
    "halo":   dict(sigma=1.5, gain=1.1, tight=0.35, follow="head", pulse=0.0, aurora=False, cell=(12.0, 2.6, 0.30, 0.12, 0.0)),
    "pulse":  dict(sigma=1.2, gain=1.15, tight=0.0, follow="trail", pulse=0.4, aurora=False, cell=(10.0, 2.2, 0.28, 0.09, 0.035)),
    "aurora": dict(sigma=1.4, gain=1.15, tight=0.0, follow="trail", pulse=0.0, aurora=True, cell=(11.0, 2.4, 0.28, 0.09, 0.05)),
    "none":   dict(sigma=1.0, gain=0.0, tight=0.0, follow="trail", pulse=0.0, aurora=False, cell=(10.0, 2.2, 0.0, 0.0, 0.0)),
}
GLOW_ORDER = list(GLOW_STYLES)
GLOW_COLORS = ["album", "white", "accent", "warm", "cool"]


def glow_colors(pal: Palette, mode: str):
    """-> (colour A, colour B); B only differs from A for the `aurora` style's gradient."""
    m = (mode or "album").lower()
    if m == "white":
        return WHITE, WHITE
    if m == "accent":
        return pal.a, pal.b
    if m == "warm":
        return (255.0, 176.0, 110.0), (255.0, 120.0, 150.0)
    if m == "cool":
        return (120.0, 200.0, 255.0), (170.0, 150.0, 255.0)
    if re.fullmatch(r"#?[0-9a-fA-F]{6}", m):
        h = m.lstrip("#")
        c = (float(int(h[0:2], 16)), float(int(h[2:4], 16)), float(int(h[4:6], 16)))
        return c, c
    return mix(pal.a, WHITE, 0.30), mix(pal.b, WHITE, 0.30)


def fmt_time(s: float) -> str:
    s = max(0, int(s))
    return f"{s // 60}:{s % 60:02d}"


def term_size() -> tuple[int, int]:
    try:
        sz = os.get_terminal_size(sys.stdout.fileno())
        return max(sz.columns, 20), max(sz.lines, 8)
    except Exception:
        sz = shutil.get_terminal_size((80, 24))
        return sz.columns, sz.lines


def fill_of(c: Cell, t: float) -> float:
    if t >= c.e:
        return 1.0
    if t <= c.b:
        return 0.0
    f = (t - c.b) / (c.e - c.b)
    return f * f * (3.0 - 2.0 * f)


# =========================================================================== beat engine
#
# A terminal can't listen to the music, so the beat comes from the best source available. It follows the INSTRUMENTS, not the voice:
# bass + kick + low synth + hi-hats. The vocal range (≈410 Hz–5.6 kHz) is skipped — unless a track has no beat sounds at all, then voices count.
#   track    decode the real audio with ffmpeg in the background (ytm songs, local files, YouTube URLs) -> onset map
#   monitor  Linux: live capture of the system audio via `parec` (any player). Bass-only; falls back to broadband after 6 s of silence
#   lyrics   last resort (no audio access, e.g. Spotify on Termux): syllable starts are soft pulses, line starts stronger
# sample(t, now) -> (pulse 0..1, energy 0..1)

def peak_pick(flux: list, hz: float, min_gap: float = 0.21) -> list:
    """flux envelope -> [(time, strength)] using an adaptive threshold (mean + 1.1*std over ~1.5 s)"""
    n = len(flux)
    if n < 8:
        return []
    w = max(4, int(hz * 1.5))
    out, last = [], -9.0
    for i in range(n):
        seg = flux[max(0, i - w // 2): min(n, i + w // 2)]
        mean = sum(seg) / len(seg)
        sd = (sum((x - mean) ** 2 for x in seg) / len(seg)) ** 0.5
        t = i / hz
        if (flux[i] > mean + 1.1 * sd + 1e-9 and (i == 0 or flux[i] >= flux[i - 1]) and (i + 1 >= n or flux[i] >= flux[i + 1])
                and t - last >= min_gap):
            out.append((t, min(1.0, 0.45 + (flux[i] - mean) / (3 * sd + 1e-9) * 0.55)))
            last = t
    return out


def analyze_pcm(data: bytes, rate: int = 22050):
    """16-bit mono PCM -> (onsets [(t, strength)], energy [0..1], source 'music'|'voice').
    'music' = bass + low synth + hi-hat bands only; 'voice' = everything, used only when the track has (almost) no beat sounds."""
    hop = 512
    hz = rate / hop
    if np is not None:
        x = np.frombuffer(data[: len(data) // 2 * 2], np.int16).astype(np.float32) / 32768.0
        nf = (len(x) - 1024) // hop
        if nf < 16:
            return [], [], "none"
        idx = np.arange(1024)[None, :] + hop * np.arange(nf)[:, None]
        mag = np.abs(np.fft.rfft(x[idx] * np.hanning(1024).astype(np.float32), axis=1))       # 21.5 Hz per bin

        def flux(lo, hi):
            m = mag[:, lo:hi]
            return np.maximum(0, np.diff(m, axis=0, prepend=m[:1])).sum(axis=1)

        music = flux(1, 11) + 0.55 * flux(11, 19) + 0.35 * flux(260, 480)                      # 21-236 Hz, 236-410 Hz, 5.6-10 kHz
        on, src = peak_pick(music.tolist(), hz), "music"
        if len(on) / (nf / hz) < 0.35:                                                         # no beat sounds -> let voices drive it
            on, src = peak_pick(flux(1, 200).tolist(), hz), "voice"
        e = (mag[:, 1:11] if src == "music" else mag[:, 1:200]).sum(axis=1)
        return on, np.clip(e / (np.percentile(e, 98) + 1e-9), 0, 1).tolist(), src
    import array                                                                              # pure python (Termux without numpy)
    a = array.array("h")
    a.frombytes(data[: len(data) // 2 * 2])
    nf = len(a) // hop
    if nf < 16:
        return [], [], "none"
    bass, full, y = [], [], 0.0
    for f in range(nf):
        sb = sf = 0.0
        for v in a[f * hop:(f + 1) * hop:3]:           # every 3rd sample = ~7 kHz; one-pole low-pass ≈ 190 Hz = kick / bass / low synth
            y += 0.16 * (v - y)
            sb += y * y
            sf += v * v
        bass.append(sb)
        full.append(sf)
    fl = lambda r: [max(0.0, r[i] - r[i - 1]) ** 0.5 if i else 0.0 for i in range(len(r))]
    on, src, r = peak_pick(fl(bass), hz), "music", bass
    if len(on) / (nf / hz) < 0.35:
        on, src, r = peak_pick(fl(full), hz), "voice", full
    top = sorted(r)[int(len(r) * 0.98)] or 1.0
    return on, [min(1.0, v / top) for v in r], src


class Beat:
    def __init__(self, cfg):
        self.enabled = str(getattr(cfg, "beat", True)).lower() not in ("off", "false", "0")
        self.source = str(getattr(cfg, "beat_source", "auto")).lower()
        self.strength = float(getattr(cfg, "beat_strength", 1.0))
        self.key = None
        self.lyr_on: list = []
        self.lyr_id = None
        self.audio_on: list = []
        self.env: list = []
        self.env_hz = 22050 / 512
        self.live_pulse, self.live_t, self.live_e = 0.0, -9.0, 0.0
        self.mon = None
        self.mode = "lyrics"
        self.analysis = ""            # 'music' (instruments) or 'voice' (no beat sounds found)
        self.gen = 0

    def bind(self, track, lyrics):
        k = track.key if track else None
        if k != self.key:
            self.key = k
            self.gen += 1
            self.audio_on, self.env, self.mode, self.analysis = [], [], "lyrics", ""
            if track and self.enabled and self.source in ("auto", "track"):
                src = self._audio_source(track)
                if src:
                    threading.Thread(target=self._analyze, args=(self.gen, src), daemon=True).start()
            if self.enabled and self.source in ("auto", "monitor") and shutil.which("parec") and not IS_TERMUX:
                self._start_monitor()
        if lyrics is not None and id(lyrics) != self.lyr_id:
            self.lyr_id = id(lyrics)
            on = []
            for ln in lyrics.lines:
                if ln.kind != "line":
                    continue
                on.append((ln.b, 1.0))
                for c in ln.cells:
                    if c.ch.strip() and c.b > ln.b + 0.05:
                        on.append((c.b, 0.42))
            on.sort()
            self.lyr_on = on

    @staticmethod
    def _audio_source(track):
        u = str(track.uri or "")
        cp = cached_audio_for_url(u)
        if cp:
            return ("file", cp)
        if u.startswith("http") and ("youtube" in u or "youtu.be" in u) and shutil.which("yt-dlp"):
            return ("yt", u)
        if u and os.path.exists(u):
            return ("file", u)
        return None

    def _analyze(self, gen, src):
        try:
            if not shutil.which("ffmpeg"):
                return
            url = src[1]
            if src[0] == "yt":
                r = subprocess.run(["yt-dlp", "-g", "-f", "bestaudio/best", "--no-playlist", "--no-warnings", url],
                                   capture_output=True, text=True, timeout=45)
                url = (r.stdout.strip().splitlines() or [""])[0]
                if not url:
                    return
            r = subprocess.run(["ffmpeg", "-v", "error", "-nostdin", "-i", url, "-vn", "-ac", "1", "-ar", "22050", "-t", "720",
                                "-f", "s16le", "-"], capture_output=True, timeout=240)
            if gen != self.gen or not r.stdout:
                return
            on, env, kind = analyze_pcm(r.stdout)
            if gen == self.gen and on:
                self.audio_on, self.env, self.mode, self.analysis = on, env, "track", kind
        except Exception as e:
            log(f"beat analyze: {e!r}")

    def _start_monitor(self):
        if self.mon and self.mon.is_alive():
            return
        self.mon = threading.Thread(target=self._monitor, daemon=True)
        self.mon.start()

    def _monitor(self):
        try:
            p = subprocess.Popen(["parec", "--format=s16le", "--rate=11025", "--channels=1", "--latency-msec=40",
                                  "-d", "@DEFAULT_MONITOR@"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            import array
            y, hb, hf, last = 0.0, [], [], 0.0
            while True:
                chunk = p.stdout.read(1024)
                if not chunk or len(chunk) < 64:
                    return
                a = array.array("h")
                a.frombytes(chunk[: len(chunk) // 2 * 2])
                sb = sf = 0.0
                for v in a[::2]:
                    y += 0.12 * (v - y)                  # bass / kick / low synth (~210 Hz low-pass): no voices
                    sb += y * y
                    sf += v * v
                n = max(1, len(a) // 2)
                eb, ef = (sb / n) ** 0.5 / 3000.0, (sf / n) ** 0.5 / 5000.0
                hb.append(eb), hf.append(ef)
                if len(hb) > 40:
                    hb.pop(0), hf.pop(0)
                now = time.monotonic()
                mb, mf = sum(hb) / len(hb), sum(hf) / len(hf)
                self.live_e = min(1.0, eb)
                hit = len(hb) > 12 and eb > mb * 1.45 + 0.02
                if not hit and now - last > 6.0 and len(hf) > 12 and ef > mf * 1.5 + 0.03:      # nothing but voices/ambience: use everything
                    hit, eb = True, ef
                if hit and now - last > 0.2:
                    self.live_pulse, self.live_t, last = min(1.0, 0.5 + (eb - mb) * 3), now, now
                    if self.mode == "lyrics":
                        self.mode = "monitor"
        except Exception as ex:
            log(f"beat monitor: {ex!r}")

    @staticmethod
    def _near(on, t, tau=0.16):
        if not on:
            return 0.0
        i = bisect.bisect_right(on, (t, 9.0)) - 1
        v = 0.0
        for j in (i, i - 1):
            if j >= 0:
                dt = t - on[j][0]
                if 0 <= dt < 0.8:
                    v = max(v, on[j][1] * math.exp(-dt / tau))
        return v

    def sample(self, t: float, now: float):
        if not self.enabled:
            return 0.0, 0.0
        s = self.strength
        if self.mode == "track" and self.audio_on:
            pulse = self._near(self.audio_on, t)
            i = int(t * self.env_hz)
            en = self.env[i] if 0 <= i < len(self.env) else 0.0
        elif self.mode == "monitor" and now - self.live_t < 1.5:
            pulse = self.live_pulse * math.exp(-(now - self.live_t) / 0.16)
            en = self.live_e
        else:
            pulse = self._near(self.lyr_on, t, 0.2)
            en = min(1.0, 0.25 + pulse * 0.6)
        return min(1.0, pulse * s), min(1.0, en * s)


# =========================================================================== cyberpsychosis (tribute: "I Really Want to Stay at Your House")
#
# Text does NOT get corrupted: it DUPLICATES (red/cyan echo copies that spread with the intensity) and STUTTERS (the sweep jumps back
# and forth for a moment on a beat). The cover splits and echoes the same way. All effects are rate-limited (no strobing).

_TRIB = re.compile(r"really\s*(?:want|wanna)\s*(?:to\s*)?stay\s*at\s*your\s*house")
TRIBUTE_IDS = ("Rbgw_rduQpM",)


def is_tribute(track) -> bool:
    if not track:
        return False
    if any(i in str(track.uri or "") for i in TRIBUTE_IDS):
        return True
    t = re.sub(r"[^a-z ]+", " ", (track.title or "").lower().replace("’", "").replace("'", ""))
    return bool(_TRIB.search(re.sub(r"\s+", " ", t)))


def echo_pil(im, k: float, rng):
    """cover 'cyberpsychosis': RGB split + a doubled ghost image + faint scanlines (no random blocks)"""
    from PIL import ImageChops
    w, h = im.size
    k = max(0.0, min(0.9, k))
    d = int(1 + k * w * 0.03)
    r, g, b = im.split()
    out = Image.merge("RGB", (ImageChops.offset(r, d, 0), g, ImageChops.offset(b, -d, 0)))
    ghost = ImageChops.offset(out, int(w * 0.05 * k) + 2, int(h * 0.02 * k))
    out = Image.blend(out, ghost, 0.30 * k)
    for _ in range(int(k * 3)):                                    # a few small slice nudges (the "stutter")
        y0 = rng.randrange(h)
        sh = rng.randrange(max(3, h // 18))
        band = out.crop((0, y0, w, min(h, y0 + sh)))
        out.paste(ImageChops.offset(band, int(rng.uniform(-1, 1) * k * w * 0.07), 0), (0, y0))
    ov = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    od = ImageDraw.Draw(ov)
    for y in range(0, h, 3):
        od.line([(0, y), (w, y)], fill=(0, 0, 0, int(26 + 30 * k)))
    return Image.alpha_composite(out.convert("RGBA"), ov).convert("RGB")


def echo_rgba(arr, k: float, stutter: bool):
    """lyric row 'cyberpsychosis' (numpy RGBA): duplicated red/cyan echo copies spreading sideways; a double-strike while stuttering"""
    k = max(0.0, min(0.9, k))
    H, W = arr.shape[:2]
    a = arr[..., 3].astype(np.float32)
    d = max(2, int(2 + k * 9))
    layers = [(d, (40, 235, 255), 0.55), (-d, (255, 45, 80), 0.55)]
    if k > 0.35:
        layers += [(2 * d, (40, 235, 255), 0.25), (-2 * d, (255, 45, 80), 0.25)]
    if k > 0.6:
        layers += [(3 * d, (255, 225, 60), 0.14)]
    if stutter:
        layers += [(int(d * 1.5), (255, 255, 255), 0.55)]          # the "stutter": a hard duplicate right next to the word
    rgb = np.zeros((H, W, 3), np.float32)
    al = np.zeros((H, W), np.float32)
    for shift, col, gain in layers:
        ga = np.roll(a, shift, 1) * gain / 255.0
        rgb = rgb * (1 - ga[..., None]) + np.array(col, np.float32) * ga[..., None]
        al = al + ga * (1 - al)
    ma = a / 255.0
    rgb = rgb * (1 - ma[..., None]) + arr[..., :3].astype(np.float32) * ma[..., None]
    al = al + ma * (1 - al)
    out = np.empty_like(arr)
    out[..., :3] = np.clip(rgb, 0, 255)
    out[..., 3] = np.clip(al * 255, 0, 255)
    out[out[..., 3] < 2] = 0
    return out


class FlashGuard:
    """keeps big changes under ~3 per second (photosensitivity): returns True when a burst is allowed"""
    def __init__(self):
        self.last = [-9.0, -9.0, -9.0]

    def ok(self, now: float) -> bool:
        if now - self.last[0] > 1.0:
            self.last = [self.last[1], self.last[2], now]
            return True
        return False


def moon_art(w: int, h: int, level: int = 0, figures: bool = True):
    """Built-in scene (original art, PIL RGBA): a huge Earth rising over the lunar horizon, stars, and — if `figures` — two seated
    silhouettes seen from behind: David (yellow rim light) and Lucy (cyan rim light). level 0..5 = beat pulse (Earth glow + rim light)."""
    from PIL import ImageFilter, ImageChops
    S = 2
    W, H = w * S, h * S
    pulse = max(0, min(5, level)) / 5.0
    rng = random.Random(11)
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    for _ in range(max(40, W * H // 2000)):
        x, y = rng.randrange(W), rng.randrange(int(H * 0.8))
        r = rng.choice((1, 1, 1, 2))
        d.ellipse([x, y, x + r, y + r], fill=(255, 255, 255, rng.randrange(70, 220)))
    cx, cy, R = int(W * 0.64), int(H * 0.60), int(min(W * 0.40, H * 0.62))
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))                                          # atmosphere halo
    ImageDraw.Draw(glow).ellipse([cx - R * 1.12, cy - R * 1.12, cx + R * 1.12, cy + R * 1.12], fill=(70, 190, 255, int(70 + 100 * pulse)))
    im = Image.alpha_composite(im, glow.filter(ImageFilter.GaussianBlur(R * (0.07 + 0.05 * pulse))))
    disc = Image.new("L", (W, H), 0)
    ImageDraw.Draw(disc).ellipse([cx - R, cy - R, cx + R, cy + R], fill=255)
    earth = Image.new("RGBA", (W, H), (8, 30, 78, 255))
    ed = ImageDraw.Draw(earth)
    lit = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(lit).ellipse([cx - R * 0.95, cy - R * 1.0, cx + R * 0.55, cy + R * 0.7], fill=(40, 135, 160, 170))
    earth = Image.alpha_composite(earth, lit.filter(ImageFilter.GaussianBlur(R * 0.22)))
    land = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ld = ImageDraw.Draw(land)
    for _ in range(14):                                                                     # brown-green continents
        ang, rad = rng.uniform(0, 6.28), rng.uniform(0.05, 0.8) * R
        px, py = cx + math.cos(ang) * rad, cy + math.sin(ang) * rad
        rw, rh = rng.uniform(0.07, 0.2) * R, rng.uniform(0.05, 0.14) * R
        ld.ellipse([px - rw, py - rh, px + rw, py + rh], fill=rng.choice(((150, 118, 74, 150), (96, 128, 84, 140), (176, 140, 92, 130))))
    earth = Image.alpha_composite(earth, land.filter(ImageFilter.GaussianBlur(R * 0.025)))
    cloud = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    cd = ImageDraw.Draw(cloud)
    for _ in range(46):                                                                     # swirling cloud streaks
        ang, rad = rng.uniform(0, 6.28), rng.uniform(0.0, 0.92) * R
        px, py = cx + math.cos(ang) * rad, cy + math.sin(ang) * rad
        rw, rh = rng.uniform(0.08, 0.3) * R, rng.uniform(0.015, 0.05) * R
        cd.ellipse([px - rw, py - rh, px + rw, py + rh], fill=(236, 228, 210, rng.randrange(60, 150)))
    earth = Image.alpha_composite(earth, cloud.filter(ImageFilter.GaussianBlur(R * 0.012)))
    earth.putalpha(disc)
    rim = ImageChops.subtract(disc, disc.filter(ImageFilter.MinFilter(max(3, int(R * 0.04) | 1)))).filter(ImageFilter.GaussianBlur(R * 0.012))
    rimc = Image.new("RGBA", (W, H), (110, 220, 255, 255))
    rimc.putalpha(rim.point(lambda v: min(255, int(v * (1.2 + 1.2 * pulse)))))
    im = Image.alpha_composite(Image.alpha_composite(im, earth), rimc)
    g = ImageDraw.Draw(im)                                                                  # lunar ground
    horizon = H * 0.80
    pts = [(0, H)]
    for i in range(0, W + 1, max(6, W // 50)):
        pts.append((i, int(horizon + math.sin(i / W * 8) * H * 0.014 + rng.uniform(-1, 1) * H * 0.007)))
    pts.append((W, H))
    g.polygon(pts, fill=(88, 86, 84, 255))
    for _ in range(40):
        x, y = rng.randrange(W), rng.randrange(int(horizon), H)
        rw = rng.randrange(max(3, W // 70), max(4, W // 18))
        g.ellipse([x - rw, y - rw // 4, x + rw, y + rw // 4], fill=rng.choice(((70, 68, 66, 200), (108, 106, 102, 160), (60, 58, 58, 200))))
    shade = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(shade).rectangle([0, int(H * 0.93), W, H], fill=(0, 0, 0, 120))
    im = Image.alpha_composite(im, shade.filter(ImageFilter.GaussianBlur(H * 0.02)))
    if figures:
        def seated(kind):
            m = Image.new("L", (W, H), 0)
            dm = ImageDraw.Draw(m)
            fh = H * 0.20
            gx = cx - R * (0.78 if kind == "d" else 0.62)
            gy = horizon + H * 0.025
            X = lambda u: gx + (u - 0.5) * fh * 0.8
            Y = lambda v: gy - fh + v * fh
            P = lambda pl: [(X(a), Y(b)) for a, b in pl]
            if kind == "d":
                dm.ellipse([X(.40), Y(.02), X(.60), Y(.26)], fill=255)
                for sp in (((.38, .12), (.33, .0), (.45, .06)), ((.46, .05), (.50, -.07), (.55, .05)), ((.54, .05), (.64, -.02), (.62, .14))):
                    dm.polygon(P(sp), fill=255)
                dm.polygon(P(((.22, .30), (.78, .30), (.86, .62), (.82, 1.05), (.18, 1.05), (.14, .62))), fill=255)
            else:
                dm.ellipse([X(.42), Y(.10), X(.58), Y(.32)], fill=255)
                dm.polygon(P(((.38, .12), (.62, .12), (.65, .30), (.35, .30))), fill=255)
                dm.polygon(P(((.30, .34), (.70, .34), (.76, .66), (.74, 1.05), (.26, 1.05), (.24, .66))), fill=255)
            return m
        for kind, rimcol in (("d", (255, 215, 50)), ("l", (60, 225, 255))):
            m = seated(kind)
            ring = ImageChops.subtract(m.filter(ImageFilter.MaxFilter(5)), m)
            glw = ring.filter(ImageFilter.GaussianBlur(R * 0.03)).point(lambda v: min(255, int(v * (1.3 + 2.8 * pulse))))
            col = Image.new("RGBA", (W, H), rimcol + (255,))
            col.putalpha(glw)
            im = Image.alpha_composite(im, col)
            sil = Image.new("RGBA", (W, H), (5, 5, 11, 255))
            sil.putalpha(m)
            im = Image.alpha_composite(im, sil)
            rl = Image.new("RGBA", (W, H), rimcol + (255,))
            rl.putalpha(ring.point(lambda v: int(v * (0.4 + 0.5 * pulse))))
            im = Image.alpha_composite(im, rl)
    return im.resize((w, h), Image.LANCZOS)


# =========================================================================== backgrounds: images, GIFs, videos (+ .add addons)
#
# A background is any image / animated GIF / WebP / video. Sources, first match wins:
#   1. addons: ~/.config/lyricglow/addons/*.add  (TOML, see example.addon.add) — rules like "this title -> that file"
#   2. [background] file = "…"  in the config (every song), or --bg FILE
#   3. ~/.config/lyricglow/backgrounds/  files named "Artist - Title.ext", "Title.ext", or default.ext
# Nothing is bundled: you point lyricglow at your own files (or URLs).

BG_IMAGE = (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".apng")
BG_VIDEO = (".mp4", ".webm", ".mkv", ".mov", ".m4v", ".avi")
BG_DIR = os.path.join(os.path.dirname(CONF), "backgrounds")
ADDON_DIR = os.path.join(os.path.dirname(CONF), "addons")


class BgMedia:
    def __init__(self, frames: list, durs: list, spec: dict):
        self.frames, self.durs, self.spec = frames, durs or [0.1] * len(frames), spec
        self.total = max(0.001, sum(self.durs))
        self.cum = []
        t = 0.0
        for d in self.durs:
            t += d
            self.cum.append(t)
        self._cells: dict = {}
        self._fit: dict = {}

    @classmethod
    def load(cls, spec: dict, width: int = 480, max_frames: int = 80):
        path = str(spec.get("file") or "")
        if path.startswith("http"):
            cp = os.path.join(CACHE, "bg", hashlib.sha1(path.encode()).hexdigest() + os.path.splitext(path.split("?")[0])[1])
            if not os.path.exists(cp):
                os.makedirs(os.path.dirname(cp), exist_ok=True)
                with open(cp, "wb") as f:
                    f.write(http_get(path, 40))
            path = cp
        if not os.path.exists(path):
            raise FileNotFoundError(path)
        ext = os.path.splitext(path)[1].lower()
        frames, durs = [], []
        if ext in BG_VIDEO:
            if not shutil.which("ffmpeg"):
                raise RuntimeError("videos need ffmpeg (Arch: pacman -S ffmpeg · Termux: pkg install ffmpeg)")
            fps = float(spec.get("fps") or 10)
            pr = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height", "-of", "csv=p=0", path],
                                capture_output=True, text=True, timeout=30)
            vw, vh = (int(x) for x in pr.stdout.strip().split(",")[:2])
            h = max(2, int(round(width * vh / vw / 2)) * 2)
            r = subprocess.run(["ffmpeg", "-v", "error", "-nostdin", "-i", path, "-an", "-t", "10", "-vf", f"fps={fps},scale={width}:{h}",
                                "-frames:v", str(max_frames), "-f", "rawvideo", "-pix_fmt", "rgb24", "-"], capture_output=True, timeout=120)
            fsz = width * h * 3
            for i in range(len(r.stdout) // fsz):
                frames.append(Image.frombytes("RGB", (width, h), r.stdout[i * fsz:(i + 1) * fsz]))
                durs.append(1.0 / fps)
        else:
            im = Image.open(path)
            n = getattr(im, "n_frames", 1)
            step = max(1, math.ceil(n / max_frames))
            for i in range(0, n, step):
                im.seek(i)
                fr = im.convert("RGB")
                if fr.width > width:
                    fr = fr.resize((width, max(1, int(fr.height * width / fr.width))), Image.LANCZOS)
                frames.append(fr.copy())
                durs.append(max(0.02, (im.info.get("duration", 100) or 100) / 1000.0) * step)
        if not frames:
            raise RuntimeError("no frames decoded from " + path)
        rot = int(spec.get("rotate") or 0) % 360
        if rot:
            frames = [f.rotate(-rot, expand=True) for f in frames]
        return cls(frames, durs, spec)

    def idx(self, now: float) -> int:
        if len(self.frames) == 1:
            return 0
        t = now % self.total
        return min(len(self.frames) - 1, bisect.bisect_right(self.cum, t))

    def fit(self, i: int, w: int, h: int, zoom: float = 1.0):
        """frame i as a PIL image exactly (w, h): 'cover' (crop to fill) or 'contain' (letterbox)"""
        key = (i, w, h, round(zoom, 2))
        got = self._fit.get(key)
        if got is None:
            fr = self.frames[i]
            if str(self.spec.get("fit", "cover")) == "contain":
                sc = min(w / fr.width, h / fr.height) / zoom
            else:
                sc = max(w / fr.width, h / fr.height) * zoom
            nw, nh = max(1, int(fr.width * sc)), max(1, int(fr.height * sc))
            rs = fr.resize((nw, nh), Image.BILINEAR)
            got = Image.new("RGB", (w, h), (0, 0, 0))
            got.paste(rs, ((w - nw) // 2, (h - nh) // 2))
            if len(self._fit) > 120:
                self._fit.clear()
            self._fit[key] = got
        return got

    def cells(self, W: int, H: int, i: int, level: int, dim: float) -> list:
        """frame i as half-block cells for the cell renderer; `level` 0-2 = beat brightness steps (cached)"""
        key = (W, H, i, level, round(dim, 2))
        got = self._cells.get(key)
        if got is None:
            if len(self._cells) > 160:
                self._cells.clear()
            f = max(0.0, (1.0 - dim)) * (1.0 + 0.30 * level)
            lut = [min(255, int(v * f)) for v in range(256)] * 3
            px = self.fit(i, W, H * 2).point(lut).tobytes()
            got = []
            for y in range(H):
                for x in range(W):
                    a, b = ((2 * y) * W + x) * 3, ((2 * y + 1) * W + x) * 3
                    got.append(("▀", ((px[a] << 16) | (px[a + 1] << 8) | px[a + 2]) & 0xFCFCFC,
                                ((px[b] << 16) | (px[b + 1] << 8) | px[b + 2]) & 0xFCFCFC, 0))
            self._cells[key] = got
        return got


def load_addons(cfg) -> list:
    """read every *.add file (TOML): [addon] name/author, [[background]] rules. Bad files are skipped and logged."""
    files = []
    for d in [ADDON_DIR, os.path.dirname(CONF)] + [os.path.expanduser(p) for p in (getattr(cfg, "addon", None) or [])]:
        if os.path.isfile(d) and d.endswith(".add"):
            files.append(d)
        elif os.path.isdir(d):
            files += sorted(glob.glob(os.path.join(d, "*.add")))
    entries = []
    if tomllib is None:
        return entries
    for f in dict.fromkeys(files):
        try:
            with open(f, "rb") as fh:
                doc = tomllib.load(fh)
            name = (doc.get("addon") or {}).get("name") or os.path.basename(f)
            for b in doc.get("background", []):
                e = dict(b)
                e["_dir"], e["_addon"], e["_file"] = os.path.dirname(os.path.abspath(f)), name, f
                entries.append(e)
        except Exception as ex:
            log(f"addon {f}: {ex!r}")
    return entries


def _norm_text(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def addon_for(entries: list, track):
    for e in entries:
        m = e.get("match") or {}
        if m == "*" or e.get("any") or (isinstance(m, dict) and m.get("any")):
            return e
        if not isinstance(m, dict) or not m:
            continue
        try:
            ok = True
            for key, val in (("title", track.title), ("artist", track.artist), ("album", track.album)):
                if key in m and not re.search(str(m[key]), _norm_text(val) if key == "title" else (val or ""), re.I):
                    ok = False
            if "id" in m and str(m["id"]) not in str(track.uri or ""):
                ok = False
            if ok:
                return e
        except re.error:
            continue
    return None


def resolve_bg(cfg, track, entries: list):
    """-> spec dict (file, fit, rotate, dim, …) or None. Honours background mode: auto | procedural | off."""
    if not track or str(getattr(cfg, "bg_mode", "auto")) != "auto":
        return None
    base = dict(fit=str(getattr(cfg, "bg_fit", "cover")), dim=float(getattr(cfg, "bg_dim", 0.42)), rotate=int(getattr(cfg, "bg_rotate", 0)),
                fps=float(getattr(cfg, "bg_fps", 10)))
    e = addon_for(entries, track)
    if e:
        f = str(e.get("file", ""))
        if f and not f.startswith(("http", "builtin")) and not os.path.isabs(f):
            f = os.path.join(e["_dir"], os.path.expanduser(f))
        return {**base, **{k: v for k, v in e.items() if not k.startswith("_") and k not in ("match", "any")}, "file": f, "_addon": e["_addon"]}
    if getattr(cfg, "bg_file", None):
        return {**base, "file": os.path.expanduser(str(cfg.bg_file))}
    if os.path.isdir(BG_DIR):
        names = [_norm_text(f"{track.artist} - {track.title}"), _norm_text(track.title), "default"]
        files = {_norm_text(os.path.splitext(f)[0]): f for f in os.listdir(BG_DIR) if os.path.splitext(f)[1].lower() in BG_IMAGE + BG_VIDEO}
        for n in names:
            if n and n in files:
                return {**base, "file": os.path.join(BG_DIR, files[n])}
    return None


def hsv(h: float, sat: float = 0.7, val: float = 1.0):
    import colorsys
    return tuple(int(v * 255) for v in colorsys.hsv_to_rgb(h % 1.0, sat, val))


def spike_star(d, cx, cy, r, spikes=12, fill=(255, 255, 255, 255), inner=0.62):
    """comic starburst polygon (the corner decorations of the lyric video)"""
    pts = []
    for i in range(spikes * 2):
        a = math.pi * i / spikes
        rr = r if i % 2 == 0 else r * inner
        pts.append((cx + math.cos(a) * rr, cy + math.sin(a) * rr))
    d.polygon(pts, fill=fill)


# =========================================================================== immersive lyrics / immersive background / caption
#
# immersive  centred phrase, arced; every word that means something sets off an effect: burn -> flames + embers, water -> waves + drops,
#            drinks -> two wine glasses clink and wine falls, snow -> snowfall, love -> hearts, gold -> sparkles, … (see FX_WORDS; add your own
#            words in an addon with [[word_effect]]).
# slice      the glossy lyric-video typography (stacked / tilted / arced / tiled), used automatically for "got a shotgun in my pocket"
# caption    a caption box (default: bottom centre) — placement, colours and buttons come from your addon file
# background "immersive": a dark purple field with drifting glossy objects (hearts, diamonds, cherries, pineapples, lipsticks) and sparkles
# All of this is original art/lexicon; nothing from the reference videos is bundled.

FX_WORDS = {
    "grow": "you your yours yourself youre u ya loud louder shout scream yell roar huge giant big bigger biggest high higher highest forever "
            "infinite endless".split(),
    "drink": "drink drinks drinking drank drunk wine whiskey whisky beer vodka tequila rum gin champagne cocktail cocktails bottle bottles glass glasses "
             "toast cheers shot shots liquor booze bar pour pouring sip sips sipping chug beverage brandy bourbon martini margarita soda coffee tea juice "
             "thirsty hangover wasted tipsy pint lager cider mezcal sake absinthe henny hennessy bubbly sangria merlot rosé prosecco moonshine whisky "
             "nightcap bartender barman tavern pub brew brewery latte espresso cappuccino smoothie milkshake lemonade punch".split(),
    "fire": "burn burning burned burnt flame flames fire fires blaze blazing ignite inferno hot heat ash ashes ember embers spark sparks torch lava scorch "
            "flare candle bonfire lighter arson cinder furnace volcano phoenix sizzle fuel explode explosion bomb dynamite wildfire flicker scorching boil "
            "melt melting glowing combust campfire matchstick bonfire hellfire firework fireworks pyre kindle singe charcoal coal sear roast".split(),
    "bang": "gun shotgun bullet bullets shoot shooting trigger bang pistol rifle gunshot cannon missile boom blast ammo revolver grenade armed weapon "
            "sniper ricochet gunfire".split(),
    "storm": "storm storms thunder lightning thunderstorm bolt shock electric electricity tornado hurricane thunderbolt tempest cyclone voltage "
             "current lightening stormy thundering".split(),
    "water": "water liquid rain raining ocean sea river wave waves tide flood drown drowned drowning stream lake pool splash tear tears cry crying swim "
             "dive sink sinking wet drip drops mist dew puddle sail shore beach waterfall tsunami deep submerge bathe shower sweat drizzle monsoon "
             "creek pond lagoon bay harbor surf swimming raindrop raindrops soaked soak overflow drench ripple ripples dripping".split(),
    "ice": "ice snow frozen freeze freezing cold winter frost chill blizzard icy snowflake glacier snowing frostbite numb arctic iceberg freezer chilly "
           "snowman snowfall sleet hail polar cool".split(),
    "blood": "blood bleed bleeding wound kill killed dead death die dying grave bury buried ghost devil hell demon dark darkness poison scar knife "
             "murder corpse skull bones bone coffin funeral hunt victim wicked evil sin sinner damn doom cursed haunt haunted reaper grim".split(),
    "heart": "love loved loving heart hearts kiss kisses romance darling baby sweetheart beloved crush desire passion hug lover lovers adore valentine "
             "affection cherish romantic soulmate embrace tender sweetie honeybunch angelic xoxo marry wedding bride".split(),
    "gold": "gold golden diamond diamonds money rich cash dollar dollars crown king queen jewel jewels treasure luxury ring silver platinum cadillac "
            "studebaker bling rolex chain chains wealth millionaire billion fortune pearl pearls gem gems ruby emerald sapphire riches paid expensive "
            "royal throne empire legend".split(),
    "star": "star stars night moon sky galaxy cosmos planet shine shining bright light lights glow sparkle twinkle sun sunshine sunrise sunset dawn shimmer "
            "gleam neon horizon daylight starlight moonlight dusk twilight lantern flashlight spotlight shining radiant dazzle".split(),
    "music": "music song songs sing singing melody beat beats rhythm bass drum drums guitar piano radio headphones lyrics tune dj vinyl chorus verse "
             "concert band singer harmony lullaby anthem choir symphony trumpet saxophone violin microphone mic record playlist remix".split(),
    "wind": "wind breeze air blow blowing whisper leaf leaves autumn gust drift breathe breath windy sail whirlwind draft sigh".split(),
    "nature": "flower flowers rose roses tree trees forest garden grow growing green spring bloom jungle grass petal petals wild mountain valley meadow "
              "river sunflower daisy lily orchid vine branch root roots seed seeds harvest field fields woods earth soil moss fern".split(),
    "dance": "dance dancing shake shaking jump bounce move groove wiggle twist spin party rave swing shimmy twerk disco club boogie hop sway skip "
             "spinning jumping dancer dancefloor".split(),
    "dream": "dream dreams dreaming cloud clouds float floating fly flying wings heaven angel soar fall falling daydream drift paradise utopia fantasy "
             "imagine imagination wonder wander wandering drifting balloon feather".split(),
    "eye": "eye eyes look looking see watch stare gaze blind vision glance peek blink wink seen sight spy watching".split(),
    "shake": "tremble trembling quake earthquake rumble shiver vibrate shatter crash collapse crumble smash break broke crack cracked bumpy shudder "
             "wobble tumble thump stomp slam".split(),
    "glitch": "digital code coding robot machine system error hack hacked glitch virus signal static noise matrix cyber binary data program pixel screen "
              "wire circuit android cyborg algorithm network online internet computer software download upload password connect disconnect offline "
              "buffer loading corrupt corrupted".split(),
    "rainbow": "rainbow color colour colors colours paint painted prism spectrum pride glitter confetti kaleidoscope technicolor vivid colorful hue".split(),
    "smoke": "smoke smoking cigarette cigarettes haze vapor vape mist smoky fog foggy steam incense cigar joint cloudy ash".split(),
    "sleep": "sleep sleeping sleepy tired yawn nap bed pillow insomnia rest lullaby midnight dreamless slumber snore bedroom blanket exhausted awake".split(),
    "laugh": "laugh laughing laughter smile smiling happy joy joyful fun funny haha giggle grin cheer celebrate celebration playful cheerful delight "
             "bliss glad lol amused".split(),
    "sad": "sad lonely alone miss missing pain hurt hurting broken sorrow grief lost lose empty sorry regret gone goodbye leave left cold hollow "
           "ache aching suffer suffering misery despair gloom blue weep mourn fade fading faded".split(),
    "time": "time clock hour hours minute minutes second seconds tick tock late wait waiting year years yesterday tomorrow today never again moment "
            "age ages past future memory memories history watch calendar midnight".split(),
    "speed": "run running ran fast speed race racing drive driving car cars road highway rush escape chase hurry motorcycle ride riding wheels engine "
             "turbo accelerate velocity sprint flee streets street cruise cruising dash".split(),
    "danger": "danger dangerous warning alarm siren police cops caution trouble alert emergency fear scared afraid panic risk threat fugitive "
              "criminal crime arrest prison jail handcuffs wanted outlaw riot chaos".split(),
    "magic": "magic magical spell witch wizard wish wishes miracle fairy enchant mystic mystery crystal potion curse charm sorcery mirage illusion "
             "prophecy genie sparkling enchanted destiny fate fortune".split(),
    "space": "space rocket alien aliens astronaut orbit satellite comet meteor mars saturn jupiter eclipse asteroid supernova universe nebula "
             "spaceship ufo launch lunar solar planet planets blackhole".split(),
    "food": "sweet candy sugar honey cake cherry cherries pineapple slice tasty taste delicious pie cookie chocolate fruit lemon strawberry peach cream "
            "dessert lollipop pizza burger bread butter spice salty sour bitter apple banana mango berry berries donut cupcake icecream".split(),
}
# ---- more words (merged into the lists above) and four more effect families
for _c, _w in {
    "fire": "flaming flamethrower blazed smolder smoldering inferno hellfire kindling sparkler ignition torchlight cremate scald".split(),
    "water": "rainfall rainstorm riverside seaside seashore oceanic aquatic wade paddle sprinkle trickle gush torrent geyser fountain".split(),
    "ice": "frosty frosted icicle icicles freezes snowstorm snowball snowdrift permafrost chilling".split(),
    "heart": "heartbeat heartbreak heartbroken hearts crushing kissing kissed cuddle cuddling flirt flirting romeo juliet cupid".split(),
    "gold": "goldmine goldfish jackpot coins coin vault bank banknotes wallet shiny shimmering lavish".split(),
    "star": "starry starlit starship stardust constellation shooting glittering glimmer flashing beacon".split(),
    "music": "bassline beatbox hiphop rap rapper melodies tunes drummer guitarist amplifier stereo speaker speakers jukebox".split(),
    "nature": "oak pine palm cactus willow blossom blossoms sprout pollen lotus thorn thorns ivy bush bushes".split(),
    "dance": "dancefloor choreography moonwalk tango salsa waltz ballet stomping clap clapping".split(),
    "danger": "bombshell detonate lockdown quarantine sirens hazard hazardous deadly lethal toxic radioactive".split(),
    "magic": "spells wizardry hex voodoo shaman prophet oracle talisman amulet runes alchemy".split(),
    "space": "galactic interstellar cosmic stardust lightyear quasar pulsar spacecraft cosmonaut telescope".split(),
    "glitch": "pixelated bitrate firmware server cloud encrypted hacker hackers decrypt malware bug bugs crash crashed".split(),
}.items():
    FX_WORDS[_c] += _w
FX_WORDS["sun"] = ("sun sunny sunshine sunrise sunset sunlight sunbeam sunbathe summer daylight dawn solar scorching tan tanning beach noon "
                   "morning rays radiant warmth").split()
FX_WORDS["moon"] = ("moon moonlight moonlit moonshine crescent lunar night nights midnight nighttime tonight evening nocturnal eclipse "
                    "starlight twilight dusk bedtime").split()
FX_WORDS["holy"] = ("heaven heavenly angel angels god gods lord pray prayer praying church holy divine halo saint soul souls spirit spiritual "
                    "bless blessed blessing glory worship faith paradise eternal amen hallelujah gospel").split()
FX_WORDS["city"] = ("city cities street streets downtown skyline skyscraper skyscrapers tower towers building buildings neon taxi subway traffic "
                    "metropolis urban avenue boulevard alley rooftop rooftops highway tokyo york paris london vegas hollywood").split()
FX_ORDER = ["grow", "drink", "fire", "bang", "storm", "water", "ice", "blood", "heart", "gold", "sun", "moon", "holy", "city", "star", "music", "wind",
            "nature", "dance", "dream", "eye", "shake", "glitch", "rainbow", "smoke", "sleep", "laugh", "sad", "time", "speed", "danger", "magic",
            "space", "food"]
FX_INDEX = {w: c for c in reversed(FX_ORDER) for w in FX_WORDS[c]}                       # earlier category wins when a word is in two lists
FX_COLOR = {"fire": (255, 110, 30), "water": (70, 180, 255), "drink": (214, 40, 90), "ice": (175, 232, 255), "storm": (190, 210, 255),
            "heart": (255, 90, 150), "gold": (255, 205, 60), "blood": (225, 30, 40), "star": (255, 245, 170), "music": (190, 140, 255),
            "wind": (190, 235, 220), "nature": (110, 220, 110), "dance": (255, 120, 255), "dream": (195, 175, 255), "eye": (255, 255, 255),
            "bang": (255, 220, 60), "grow": (255, 255, 255), "shake": (255, 170, 90), "glitch": (80, 255, 140), "rainbow": (255, 255, 255),
            "smoke": (170, 170, 185), "sleep": (170, 160, 255), "laugh": (255, 230, 90), "sad": (120, 140, 200), "time": (230, 220, 190),
            "speed": (255, 150, 60), "danger": (255, 70, 70), "magic": (200, 120, 255), "space": (120, 220, 255), "food": (255, 140, 190)}


FX_COLOR.update({"sun": (255, 200, 70), "moon": (235, 235, 190), "holy": (255, 240, 190), "city": (200, 150, 255)})


def load_wordfx() -> dict:
    """~/.config/lyricglow/wordfx.txt — your own words, one 'category: word word word' per line (# comments). Categories = the names above."""
    out = {}
    try:
        with open(os.path.join(os.path.dirname(CONF), "wordfx.txt"), encoding="utf-8") as f:
            for ln in f:
                ln = ln.split("#")[0].strip()
                if ":" in ln:
                    cat, _, ws = ln.partition(":")
                    if cat.strip() in FX_WORDS:
                        for w in ws.split():
                            out[w.lower()] = cat.strip()
    except OSError:
        pass
    return out


def fx_category(word: str, extra: dict | None = None):
    """word -> effect category or None. Handles plurals / -ed / -ing (burns, burned, burning → burn)."""
    w = re.sub(r"[^a-zé]", "", (word or "").lower())
    if extra and w in extra:
        return extra[w]
    if w in ("u", "ya"):
        return "grow"
    if len(w) < 2:
        return None
    if len(w) < 3:
        return None
    for s in (w, w[:-1], w[:-2], w[:-3], w[:-3] + "e", w[:-2] + "e", w[:-1] + "y"):
        if len(s) >= 3:
            if extra and s in extra:
                return extra[s]
            if s in FX_INDEX:
                return FX_INDEX[s]
    return None


BIGFONT = {
    "A": ("010", "101", "111", "101", "101"), "B": ("110", "101", "110", "101", "110"), "C": ("011", "100", "100", "100", "011"),
    "D": ("110", "101", "101", "101", "110"), "E": ("111", "100", "110", "100", "111"), "F": ("111", "100", "110", "100", "100"),
    "G": ("011", "100", "101", "101", "011"), "H": ("101", "101", "111", "101", "101"), "I": ("111", "010", "010", "010", "111"),
    "J": ("001", "001", "001", "101", "010"), "K": ("101", "101", "110", "101", "101"), "L": ("100", "100", "100", "100", "111"),
    "M": ("101", "111", "111", "101", "101"), "N": ("110", "101", "101", "101", "101"), "O": ("010", "101", "101", "101", "010"),
    "P": ("110", "101", "110", "100", "100"), "Q": ("010", "101", "101", "110", "011"), "R": ("110", "101", "110", "101", "101"),
    "S": ("011", "100", "010", "001", "110"), "T": ("111", "010", "010", "010", "010"), "U": ("101", "101", "101", "101", "111"),
    "V": ("101", "101", "101", "101", "010"), "W": ("101", "101", "111", "111", "101"), "X": ("101", "101", "010", "101", "101"),
    "Y": ("101", "101", "010", "010", "010"), "Z": ("111", "001", "010", "100", "111"), "'": ("010", "010", "000", "000", "000"),
    " ": ("000", "000", "000", "000", "000"),
}


def big_word_size(text: str, hx: int, s: int | None = None):
    """(cells wide, cell rows) of a word in the 3x5 block font: every pixel is hx cells wide and s pixel-rows tall (hx == s -> square pixels)"""
    s = hx if s is None else s
    n = len(text)
    return n * 3 * hx + (n - 1) * hx, (5 * s + 1) // 2


def draw_big_word(scr, text: str, x0: int, y0: int, hx: int, s: int, col, alpha: float = 1.0):
    """block-letter word drawn with half-block pixels; gradient from `col` (top) to a lighter tone (bottom), blended towards the background by alpha"""
    px = {}
    cx = 0
    for ch in text.upper():
        g = BIGFONT.get(ch, BIGFONT[" "])
        for r in range(5):
            for c in range(3):
                if g[r][c] == "1":
                    for sy in range(s):
                        for sx in range(hx):
                            px[(cx + c * hx + sx, r * s + sy)] = r / 4.0
        cx += 3 * hx + hx
    cells = {}
    for (x, py), f in px.items():
        e = cells.setdefault((x, py // 2), [None, None])
        e[py % 2] = f
    for (x, cy), (a, b) in cells.items():
        f = a if a is not None else b
        c = mix((8, 6, 18), mix(col, (255, 255, 255), 0.35 * f), alpha)
        chh = "█" if (a is not None and b is not None) else ("▀" if a is not None else "▄")
        X, Y = x0 + x, y0 + cy
        if 0 <= X < scr.W and 0 <= Y < scr.H:
            scr.put(X, Y, chh, pk(c), 1)


BUILTIN_RULES = [dict(lyric=r"got a shotgun in my pocket", style="slice", bg="immersive", hold=0.8)]


def _addon_files(cfg) -> list:
    files = []
    for d in [ADDON_DIR, os.path.dirname(CONF)] + [os.path.expanduser(p) for p in (getattr(cfg, "addon", None) or [])]:
        if os.path.isfile(d) and d.endswith(".add"):
            files.append(d)
        elif os.path.isdir(d):
            files += sorted(glob.glob(os.path.join(d, "*.add")))
    return list(dict.fromkeys(files))


def load_addon_ui(cfg) -> dict:
    """caption placement, custom buttons, lyric rules and extra word effects from *.add files"""
    ui = dict(caption={}, buttons=[], rules=list(BUILTIN_RULES), word_fx=load_wordfx(), shell=bool(getattr(cfg, "addon_shell", False)))
    if tomllib is None:
        return ui
    for f in _addon_files(cfg):
        try:
            with open(f, "rb") as fh:
                doc = tomllib.load(fh)
            ui["caption"].update(doc.get("caption") or {})
            ui["buttons"] += [dict(b) for b in doc.get("button", []) if isinstance(b, dict)]
            ui["rules"] += [dict(r) for r in doc.get("rule", []) if isinstance(r, dict)]
            for e in doc.get("word_effect", []):
                for w in e.get("words", []):
                    ui["word_fx"][str(w).lower()] = str(e.get("type", "star"))
        except Exception as ex:
            log(f"addon ui {f}: {ex!r}")
    return ui


def match_rule(rules: list, text: str):
    t = _norm_text(text)
    for r in rules:
        try:
            if r.get("lyric") and re.search(str(r["lyric"]), t, re.I):
                return r
        except re.error:
            continue
    return None


def _hexcol(v, default):
    try:
        v = str(v).lstrip("#")
        return (int(v[0:2], 16), int(v[2:4], 16), int(v[4:6], 16))
    except Exception:
        return default


class Particle:
    __slots__ = ("x", "y", "vx", "vy", "g", "life", "age", "ch", "col", "wob", "ph")

    def __init__(self, x, y, vx, vy, g, life, ch, col, wob=0.0, ph=0.0):
        self.x, self.y, self.vx, self.vy, self.g, self.life, self.age, self.ch, self.col, self.wob, self.ph = x, y, vx, vy, g, life, 0.0, ch, col, wob, ph


class ImmersiveFX:
    """particles + background effects + the wine-glass animation, driven by words as they are sung"""
    MAXP = 140

    def __init__(self):
        self.parts: list = []
        self.seen: set = set()
        self.t_last = None
        self.active: dict = {}                       # category -> until (drives background tints / bands)
        self.drink_t0 = None
        self.bolt = None
        self.rng = random.Random(7)
        self.gscale, self.want_shake, self.glitch_t = 1.0, False, -9.0
        self.mask: set = set()                       # cells under the lyric words: particles flow around them, never through them
        self.born: dict = {}
        self.corner_on, self.corner_strength = True, 1.0

    def reset(self):
        """a rewind / seek: forget what already fired so every effect can play again"""
        self.parts.clear()
        self.seen.clear()
        self.active.clear()
        self.born.clear()
        self.drink_t0, self.bolt = None, None

    def trigger(self, cat: str, x: float, y: float, w: float, now: float, W: int, H: int, guard=None):
        r, P = self.rng, self.parts
        if cat not in self.active:
            self.born[cat] = now
        self.active[cat] = now + (3.0 if cat in ("fire", "water", "ice", "blood", "sad", "danger") else 2.6)
        if cat == "drink":
            if self.drink_t0 is None or now - self.drink_t0 > 6.0:
                self.drink_t0 = now
            return
        if cat == "storm":
            if guard is None or guard.ok(now):
                self.bolt = (now, int(x + w / 2), int(y))
            return
        cx, n = x + w / 2, 1

        def add(pc):
            if len(P) < self.MAXP:
                P.append(pc)
        if cat == "fire":
            for _ in range(22):
                add(Particle(x + r.random() * w, y, r.uniform(-1.6, 1.6), -r.uniform(6, 14), -2.5, r.uniform(0.7, 1.4), r.choice("^'`´▴▲"), (255, 170, 40), r.uniform(0.5, 2.2), r.random() * 6))
            for _ in range(7):
                add(Particle(r.random() * W, H - 2 - r.random() * 6, r.uniform(-2, 2), -r.uniform(1.5, 4), 0, r.uniform(1.5, 2.8), r.choice("·˙.*"), (255, 120, 40), 1.5, r.random() * 6))
        elif cat == "water":
            for _ in range(9):
                add(Particle(x + r.random() * w, y + 1, r.uniform(-.6, .6), r.uniform(3, 7), 16.0, r.uniform(0.9, 1.5), r.choice(".:o°•"), (90, 190, 255)))
        elif cat == "ice":
            for _ in range(14):
                add(Particle(r.random() * W, 0, r.uniform(-.8, .8), r.uniform(2, 5), 0, r.uniform(2.2, 3.8), r.choice("❄❅❆·*"), (200, 238, 255), 2.0, r.random() * 6))
        elif cat == "heart":
            for _ in range(7):
                add(Particle(x + r.random() * w, y, r.uniform(-1, 1), -r.uniform(2.5, 5), 0, r.uniform(1.2, 2.0), r.choice("♥♡❤"), (255, 90, 150), 1.5, r.random() * 6))
        elif cat in ("star", "gold", "bang"):
            chars = {"star": "✦✧★✶·", "gold": "✦◆◇✧", "bang": "✸✹✺*"}[cat]
            col = FX_COLOR[cat]
            for _ in range(10 if cat != "bang" else 12):
                a = r.random() * 6.283
                sp = r.uniform(3, 9 if cat != "bang" else 15)
                add(Particle(cx, y, math.cos(a) * sp * 1.6, math.sin(a) * sp * 0.8, 0, r.uniform(0.5, 1.0), r.choice(chars), col))
        elif cat == "blood":
            for _ in range(6):
                add(Particle(x + r.random() * w, y + 1, 0, r.uniform(1.5, 3.5), 5.0, r.uniform(1.3, 2.2), r.choice("│╎▐●"), (210, 25, 35)))
        elif cat == "music":
            for _ in range(5):
                add(Particle(x + r.random() * w, y, r.uniform(-1.5, 1.5), -r.uniform(2, 4.5), 0, r.uniform(1.3, 2.2), r.choice("♪♫♬"), (190, 140, 255), 2.0, r.random() * 6))
        elif cat == "wind":
            for _ in range(6):
                add(Particle(-3, y + r.randint(-2, 2), r.uniform(28, 46), 0, 0, r.uniform(1.5, 2.2), r.choice("~≈─╌"), (190, 235, 220)))
        elif cat == "nature":
            for _ in range(8):
                add(Particle(r.random() * W, 0, r.uniform(-1, 1), r.uniform(2, 4), 0, r.uniform(2, 3.5), r.choice("✿❀❁*"), r.choice(((110, 220, 110), (255, 150, 190))), 2.2, r.random() * 6))
        elif cat == "eye":
            add(Particle(x + w + 1, y, 0, 0, 0, 0.9, "◉", (255, 255, 255)))
        elif cat == "glitch":
            for _ in range(14):
                add(Particle(x + r.random() * max(w, 4), y - 2 + r.random() * 5, 0, r.uniform(4, 9), 0, r.uniform(0.5, 1.0), r.choice("01"), (70, 255, 130)))
        elif cat == "rainbow":
            for _ in range(10):
                add(Particle(x + r.random() * w, y, r.uniform(-3, 3), -r.uniform(2, 6), 6.0, r.uniform(0.8, 1.4), r.choice("✦✧*+"), hsv(r.random())))
        elif cat == "smoke":
            for _ in range(8):
                add(Particle(x + r.random() * w, y - 1, r.uniform(-.6, .6), -r.uniform(1.5, 3), 0, r.uniform(1.6, 2.6), r.choice("░▒~≈"), (170, 170, 185), 2.5, r.random() * 6))
        elif cat == "sleep":
            for i in range(4):
                add(Particle(x + w + i, y - i, 1.2, -1.6, 0, 1.8 + 0.2 * i, "zZz"[i % 3], (170, 160, 255), 1.0, r.random() * 6))
        elif cat == "laugh":
            for _ in range(8):
                add(Particle(x + r.random() * w, y, r.uniform(-2, 2), -r.uniform(3, 6), 7.0, r.uniform(0.8, 1.3), r.choice("♪✧*"), (255, 230, 90)))
        elif cat == "sad":
            for _ in range(8):
                add(Particle(x + r.random() * w, y + 1, 0, r.uniform(1, 2.5), 2.0, r.uniform(1.5, 2.5), r.choice("·.│"), (110, 130, 190)))
        elif cat == "time":
            for k in range(4):
                add(Particle(cx + math.cos(k * 1.571) * (w / 2 + 2), y - 1 + math.sin(k * 1.571), 0, -0.3, 0, 1.6, "|", (235, 225, 190)))
        elif cat == "speed":
            for _ in range(9):
                add(Particle(-3, y + r.randint(-3, 3), r.uniform(45, 75), 0, 0, r.uniform(0.7, 1.2), r.choice("═─━"), (255, 160, 70)))
        elif cat == "magic":
            for _ in range(12):
                a = r.random() * 6.283
                rad = r.uniform(4, 9)
                add(Particle(cx + math.cos(a) * rad * 1.6, y + math.sin(a) * rad * 0.5, -math.cos(a) * 6 - math.sin(a) * 4, -math.sin(a) * 3 + math.cos(a) * 2,
                             0, r.uniform(0.7, 1.2), r.choice("✦✧*·"), r.choice(((200, 120, 255), (255, 150, 230), (150, 170, 255)))))
        elif cat == "space":
            sx, sy = W * r.uniform(0.6, 1.0), r.uniform(0, H * 0.3)
            for k in range(7):                                                     # a shooting star with a trail
                add(Particle(sx + k * 1.6, sy - k * 0.5, -24, 8, 0, 0.9 - k * 0.07, "★" if k == 0 else r.choice("─·"), (150, 225, 255) if k else (255, 255, 255)))
        elif cat == "food":
            for _ in range(12):
                add(Particle(x + r.random() * w, y, r.uniform(-4, 4), -r.uniform(3, 8), 14.0, r.uniform(0.9, 1.5), r.choice("●◍◉○"), r.choice(((255, 140, 190), (255, 225, 90), (120, 230, 255)))))
        elif cat == "shake":
            self.want_shake = True

    def step(self, now: float):
        dt = 0.0 if self.t_last is None else min(0.1, now - self.t_last)
        self.t_last = now
        keep = []
        for p in self.parts:
            p.age += dt
            if p.age >= p.life:
                continue
            p.vy += p.g * dt
            p.x += p.vx * dt + (math.sin(p.age * 3 + p.ph) * p.wob * dt if p.wob else 0.0)
            p.y += p.vy * dt
            keep.append(p)
        self.parts = keep
        for c in [c for c, u in self.active.items() if u < now]:
            del self.active[c]

    # ---- corner effects: the four corners of the screen react to what is being sung ----------------------------------------------------
    def _cput(self, scr, W, H, x, y, ch, col):
        if 0 <= x < W and 0 <= y < H:
            c = scr.cur[y * W + x]
            if c[0] in (" ", "▀"):                                   # never over lyrics
                scr.cur[y * W + x] = (ch, pk(col), c[2], 1)

    @staticmethod
    def _each(W, H, sel=("tl", "tr", "bl", "br")):
        pts = (("tl", 0, 0, 1, 1), ("tr", W - 1, 0, -1, 1), ("bl", 0, H - 3, 1, -1), ("br", W - 1, H - 3, -1, -1))
        return [(ox, oy, sx, sy) for nm, ox, oy, sx, sy in pts if nm in sel]

    def corner_fx(self, scr, now: float, W: int, H: int, strength: float = 1.0):
        for cat in list(self.active):
            fn = getattr(self, "_c_" + cat, None)
            if fn is None:
                continue
            f = min(clamp((now - self.born.get(cat, now)) / 0.25), clamp((self.active[cat] - now) / 0.9)) * strength
            if f > 0.03:
                fn(scr, now, W, H, f)

    def _c_fire(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("bl", "br")):
            for dx in range(12):
                h = int(f * (3 + 5 * max(0.0, math.sin(now * 8 + dx * 1.7 + ox))) * (1 - dx / 13))
                for dy in range(h):
                    t = dy / max(1, h)
                    self._cput(scr, W, H, ox + sx * dx, oy + sy * dy, "▲" if dy == h - 1 else "█▓▒"[min(2, int(t * 3))], mix((255, 220, 70), (200, 30, 10), t))

    def _c_water(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("tl", "tr")):
            for dx in range(13):
                self._cput(scr, W, H, ox + sx * dx, oy + int(1.2 + math.sin(now * 4 + dx * 0.7)), "≈", (90, 190, 255))
            for i in range(3):
                self._cput(scr, W, H, ox + sx * (2 + i * 4), oy + 2 + int(((now * 6 + i * 3) % 8) * f), ".o°"[i], (140, 210, 255))
        for ox, oy, sx, sy in self._each(W, H, ("bl", "br")):
            for dx in range(9):
                self._cput(scr, W, H, ox + sx * dx, oy - int(0.6 + math.sin(now * 3 + dx) * 0.6), "~", (60, 140, 220))

    def _c_ice(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H):
            L = int(2 + f * 5)
            for k in range(L):
                self._cput(scr, W, H, ox + sx * k, oy, "─", (170, 230, 255))
                self._cput(scr, W, H, ox, oy + sy * k, "│", (170, 230, 255))
                self._cput(scr, W, H, ox + sx * k, oy + sy * (k // 2 + 1), "·", (210, 240, 255))
            self._cput(scr, W, H, ox + sx * L, oy, "❄", (230, 248, 255))
            self._cput(scr, W, H, ox, oy + sy * L, "❄", (230, 248, 255))

    def _c_storm(self, scr, now, W, H, f):
        if int(now * 10) % 3 == 0:                                           # the bolt flickers (small shape, no screen flash)
            return
        for ox, oy, sx, sy in self._each(W, H, ("tl", "tr")):
            x = 0
            for k in range(int(4 + f * 8)):
                x += (1 if (k * 7 + ox) % 3 else 0)
                self._cput(scr, W, H, ox + sx * x, oy + k, "╲" if sx > 0 else "╱", (235, 240, 255))
                if k % 3 == 2:
                    self._cput(scr, W, H, ox + sx * (x + 1), oy + k, "─", (170, 200, 255))

    def _c_heart(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("bl", "br")):
            for i in range(4):
                ph = (now * 0.6 + i * 0.27) % 1.0
                self._cput(scr, W, H, ox + sx * (2 + i * 3 + int(math.sin(now * 3 + i) * 1.5)), oy - int(ph * 9 * f), "♥♡"[i % 2], mix((255, 90, 150), (60, 20, 40), ph))

    def _c_gold(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("tl", "tr")):
            for i, (dx, dy) in enumerate(((1, 1), (3, 0), (4, 2), (2, 3), (6, 1), (5, 3))):
                if math.sin(now * 6 + i * 1.7) > -0.2:
                    self._cput(scr, W, H, ox + sx * dx, oy + dy, "✦◆◇✧"[i % 4], (255, 205, 60) if i % 2 else (255, 240, 150))

    def _c_star(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H):
            for i, (dx, dy) in enumerate(((1, 1), (3, 0), (0, 3), (4, 3), (2, 2))):
                if math.sin(now * 5 + i * 2.1 + ox) > -0.3:
                    self._cput(scr, W, H, ox + sx * dx, oy + sy * dy, "✦✧·"[i % 3], (255, 245, 190))

    def _c_blood(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("tl", "tr")):
            for dx in range(0, 10, 2):
                ln = int(f * (2 + (dx * 7) % 5))
                for k in range(ln):
                    self._cput(scr, W, H, ox + sx * dx, oy + k, "●" if k == ln - 1 else "│", (205, 25, 35))

    def _c_nature(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("bl", "br")):
            for dx in range(int(4 + f * 10)):
                self._cput(scr, W, H, ox + sx * dx, oy - int(1.2 + math.sin(dx * 0.9 + now)), "✿" if dx % 5 == 4 else "~", (255, 150, 190) if dx % 5 == 4 else (90, 200, 100))

    def _c_smoke(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("bl", "br")):
            for i in range(4):
                ph = (now * 0.5 + i * 0.25) % 1.0
                self._cput(scr, W, H, ox + sx * (2 + i * 2 + int(math.sin(now * 2 + i) * 1.5)), oy - int(ph * 8 * f), "░▒"[i % 2], mix((170, 170, 185), (30, 30, 40), ph))

    def _c_sleep(self, scr, now, W, H, f):
        for i in range(3):
            ph = (now * 0.4 + i * 0.33) % 1.0
            self._cput(scr, W, H, W - 4 - int(ph * 6) - i * 2, 2 + int((1 - ph) * 4), "zZz"[i], mix((170, 160, 255), (30, 25, 60), ph))

    def _c_danger(self, scr, now, W, H, f):
        col = (230, 40, 50) if int(now * 2) % 2 else (50, 90, 235)       # slow 2 Hz alternation, small corner blocks only
        for ox, oy, sx, sy in self._each(W, H):
            for dx in range(3):
                for dy in range(2):
                    self._cput(scr, W, H, ox + sx * dx, oy + sy * dy, "█", mix((8, 6, 18), col, 0.35 + 0.4 * f))

    def _c_glitch(self, scr, now, W, H, f):
        r = random.Random(int(now * 8))
        for ox, oy, sx, sy in self._each(W, H):
            for _ in range(int(4 + f * 8)):
                self._cput(scr, W, H, ox + sx * r.randint(0, 6), oy + sy * r.randint(0, 3), r.choice("01▌▐"), (80, 255, 140) if r.random() < 0.7 else (255, 60, 90))

    def _c_magic(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H):
            for i in range(5):
                a = now * 3 + i * 1.256
                rad = 3 + f * 2
                self._cput(scr, W, H, ox + sx * int(abs(math.cos(a)) * rad * 1.6), oy + sy * int(abs(math.sin(a)) * rad * 0.8), "✦✧*"[i % 3], (200, 130, 255) if i % 2 else (255, 160, 230))

    def _c_space(self, scr, now, W, H, f):
        for dx, dy, ch in ((3, 2, "◉"), (2, 2, "("), (4, 2, ")"), (7, 1, "·"), (1, 4, "✦")):
            self._cput(scr, W, H, dx, dy, ch, (120, 220, 255) if ch == "◉" else (200, 210, 255))
        for ox, oy, sx, sy in self._each(W, H, ("tr", "br")):
            for i in range(3):
                if math.sin(now * 4 + i) > 0:
                    self._cput(scr, W, H, ox + sx * (2 + i * 2), oy + sy * (1 + i), "✦", (255, 255, 255))

    def _c_sun(self, scr, now, W, H, f):
        ox, oy = W - 3, 1
        self._cput(scr, W, H, ox, oy, "O", (255, 220, 90))
        for k in range(1, int(2 + f * 6)):
            c = mix((255, 220, 90), (255, 140, 40), k / 8)
            self._cput(scr, W, H, ox - k * 2, oy, "─", c)
            self._cput(scr, W, H, ox, oy + k, "│", c)
            self._cput(scr, W, H, ox - k, oy + k, "╲", c)

    def _c_moon(self, scr, now, W, H, f):
        for dy in range(-2, 3):
            for dx in range(-3, 4):
                if (dx / 1.8) ** 2 + dy ** 2 <= 4.2 and not (((dx - 1.3) / 1.8) ** 2 + dy ** 2 <= 3.4):
                    self._cput(scr, W, H, 4 + dx, 3 + dy, "█", mix((8, 6, 18), (235, 235, 190), min(1.0, 0.3 + f)))
        for i, (x, y) in enumerate(((9, 1), (11, 4), (7, 6), (13, 2))):
            if math.sin(now * 4 + i) > -0.2:
                self._cput(scr, W, H, x, y, "✦✧"[i % 2], (255, 250, 210))

    def _c_holy(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("tl", "tr")):
            self._cput(scr, W, H, ox + sx * 4, oy + 1, "○", (255, 240, 190))
            for k in range(int(2 + f * 7)):
                self._cput(scr, W, H, ox + sx * (5 + k // 2), oy + 2 + k, "│", mix((255, 240, 190), (40, 35, 50), k / 9))
                self._cput(scr, W, H, ox + sx * (3 - k // 3), oy + 2 + k, "╱" if sx > 0 else "╲", mix((255, 240, 190), (40, 35, 50), k / 9))

    def _c_city(self, scr, now, W, H, f):
        heights = (3, 5, 2, 4, 6, 3, 4)
        for ox, oy, sx, sy in self._each(W, H, ("bl", "br")):
            for i, h in enumerate(heights):
                for dx in range(2):
                    for dy in range(int(h * f)):
                        win = dy % 2 == 1 and dx == 0 and math.sin(now * 2 + i * 3 + dy) > -0.5
                        self._cput(scr, W, H, ox + sx * (i * 2 + dx), oy - dy, "▪" if win else "█", (255, 215, 110) if win else (40, 28, 78))

    def _c_music(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("tl", "tr")):
            for i in range(3):
                self._cput(scr, W, H, ox + sx * (3 + i * 3), 1 + int(abs(math.sin(now * 5 + i)) * 2), "♪♫♬"[i], (190, 140, 255))

    def _c_dance(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("bl", "br")):
            for i in range(3):
                self._cput(scr, W, H, ox + sx * (3 + i * 3), oy - 1 - int(abs(math.sin(now * 7 + i)) * 3), "♪✧♫"[i], (255, 120, 255))

    def _c_laugh(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("tl", "tr")):
            for i in range(2):
                for k_, g_ in enumerate("^_^"):                      # a little face, ASCII so every font has it
                    self._cput(scr, W, H, ox + sx * (3 + i * 5) + k_, 1 + int(abs(math.sin(now * 6 + i)) * 2), g_, (255, 230, 90))

    def _c_sad(self, scr, now, W, H, f):
        for dx in range(5):
            self._cput(scr, W, H, 2 + dx, 1, "░▒▒▒░"[dx], (110, 120, 160))
        for i in range(3):
            self._cput(scr, W, H, 3 + i * 2, 2 + int(((now * 3 + i) % 4)), "·", (110, 140, 220))

    def _c_time(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H):
            self._cput(scr, W, H, ox + sx * 2, oy + sy * 1, "|/-\\"[int(now * 4) % 4], (235, 225, 190))

    def _c_speed(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("bl", "br")):
            for i in range(4):
                for k in range(5):
                    self._cput(scr, W, H, ox + sx * (int((now * 30 + i * 7) % 14) + k), oy - i, "═", mix((255, 160, 70), (40, 20, 10), k / 5))

    def _c_food(self, scr, now, W, H, f):
        r = random.Random(int(now * 5))
        for ox, oy, sx, sy in self._each(W, H):
            for _ in range(int(3 + f * 4)):
                self._cput(scr, W, H, ox + sx * r.randint(0, 6), oy + sy * r.randint(0, 3), r.choice("●◍◉○"), r.choice(((255, 140, 190), (255, 225, 90), (120, 230, 255))))

    def _c_eye(self, scr, now, W, H, f):
        ch = "◉" if int(now * 2) % 5 else "─"
        for ox, oy, sx, sy in self._each(W, H):
            self._cput(scr, W, H, ox + sx * 3, oy + sy * 1, ch, (255, 255, 255))
            self._cput(scr, W, H, ox + sx * 5, oy + sy * 1, ch, (255, 255, 255))

    def _c_drink(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("bl", "br")):
            for i in range(4):
                ph = (now * 0.7 + i * 0.25) % 1.0
                self._cput(scr, W, H, ox + sx * (2 + i * 2 + int(math.sin(now * 3 + i))), oy - int(ph * 8 * f), "o.°o"[i], mix((230, 120, 150), (40, 15, 30), ph))

    def _c_bang(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H):
            self._cput(scr, W, H, ox + sx * 2, oy + sy * 1, "✸", (255, 220, 60))
            self._cput(scr, W, H, ox + sx * 4, oy + sy * 2, "✹", (255, 140, 40))

    def _c_wind(self, scr, now, W, H, f):
        for i in range(4):
            for ox, sx in ((0, 1), (W - 1, -1)):
                for k in range(4):
                    self._cput(scr, W, H, ox + sx * (int((now * 14 + i * 9) % 14) + k), 3 + i * 3, "─", (190, 235, 220))

    def _c_dream(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("tl", "tr")):
            for i in range(5):
                self._cput(scr, W, H, ox + sx * (2 + i + int(now * 2) % 3), 1 + (i % 2), "░▒░"[i % 3], (200, 190, 245))

    def _c_rainbow(self, scr, now, W, H, f):
        for ox, oy, sx, sy in self._each(W, H, ("bl", "br")):
            for rr in range(3, 9):
                for a in range(0, 16):
                    ang = a / 15 * (math.pi / 2)
                    self._cput(scr, W, H, ox + sx * int(math.cos(ang) * rr * 1.8), oy - int(math.sin(ang) * rr), "▓", hsv((rr - 3) / 8 + 0.0))

    def apply_bg(self, scr, now: float, W: int, H: int):
        """tints + bands on the BACKGROUND (before text): fire glow, water wave, frost, wine"""
        def tint_rows(y0, y1, col, amt):
            for y in range(max(0, y0), min(H, y1)):
                k = amt * (1 - abs((y - y0) / max(1, y1 - y0)) * 0.0)
                for x in range(W):
                    c = scr.cur[y * W + x]
                    b = c[2] if c[2] >= 0 else 0
                    nb = ((int(((b >> 16) & 255) * (1 - k) + col[0] * k) & 252) << 16) | ((int(((b >> 8) & 255) * (1 - k) + col[1] * k) & 252) << 8) | (int((b & 255) * (1 - k) + col[2] * k) & 252)
                    scr.cur[y * W + x] = (c[0], c[1], nb, c[3])
        if "fire" in self.active:
            f = clamp((self.active["fire"] - now) / 1.2)
            for i in range(5):                                   # glow rising from the bottom
                tint_rows(H - 2 - i, H - 1 - i, (255, 70, 15), 0.30 * f * (1 - i / 5))
        if "water" in self.active:
            f = clamp((self.active["water"] - now) / 1.2)
            for x in range(W):                                   # an animated wave band
                yy = H - 5 + int(round(math.sin(now * 4 + x * 0.35) * 0.9))
                if 0 <= yy < H:
                    c = scr.cur[yy * W + x]
                    scr.cur[yy * W + x] = (random.Random(x).choice("≈~∽"), pk((120, 205, 255)) if f > 0.3 else pk((60, 120, 170)), c[2], 0)
            tint_rows(H - 4, H - 1, (20, 90, 170), 0.35 * f)
        if "ice" in self.active:
            f = clamp((self.active["ice"] - now) / 1.2)
            tint_rows(0, 2, (150, 220, 255), 0.25 * f)
            tint_rows(H - 3, H, (150, 220, 255), 0.25 * f)
        if "blood" in self.active:
            tint_rows(H - 3, H, (140, 10, 20), 0.35 * clamp((self.active["blood"] - now) / 1.2))
        if "sad" in self.active:
            tint_rows(0, H, (15, 25, 60), 0.22 * clamp((self.active["sad"] - now) / 1.2))
        if "danger" in self.active:                                                  # slow red / blue edge bars (2 Hz, no strobing)
            col = (210, 30, 40) if int(now * 2) % 2 else (40, 70, 220)
            tint_rows(0, 1, col, 0.45)
            tint_rows(H - 1, H, col, 0.45)
        if self.corner_on:
            self.corner_fx(scr, now, W, H, self.corner_strength)
        if self.drink_t0 is not None:
            self.draw_drinks(scr, now, W, H)

    def draw_drinks(self, scr, now: float, W: int, H: int):
        """two wine glasses clink, the wine spills and falls, everything fades back into the background (art sits in the upper third, clear of the lyrics)"""
        a = now - self.drink_t0
        TOTAL = 4.2
        if a > TOTAL:
            self.drink_t0 = None
            return
        fade = 1.0 - clamp((a - 3.3) / 0.9)
        ease = lambda x: x * x * (3 - 2 * x)
        cx, top = W // 2, 2
        far = max(9, min(W // 2 - 8, 20))
        if a < 1.0:
            p = ease(a / 1.0)
            gap, lean = int(round(far - (far - 6) * p)), int(round(3 * p))
        elif a < 1.3:
            gap, lean = 6, 3                                                    # the clink
        else:
            gap, lean = 6 + min(3, int((a - 1.3) * 3)), max(0, 3 - int((a - 1.3) * 2))
        level = 3 if a < 1.3 else max(1, 3 - int((a - 1.3) / 0.9))
        wcol = (170, 22, 62)

        def col(base, ch="x"):
            if fade >= 1.0:
                return pk(base)
            return pk(mix((8, 6, 18), base, fade if random.random() < fade + 0.2 else 0.0))

        def glass(gx, lean_):
            fills = [1, 1, 1, 1, 1]                                             # which bowl rows hold wine
            lo = {3: 0, 2: 1, 1: 3}[level]
            rows = []
            for r in range(5):
                w_ = 9 - 2 * r
                body = "▒" * w_ if r >= lo else " " * w_
                rows.append(" " * r + "╲" + body + "╱")
            rows += ["     ║     ", "     ║     ", "     ║     ", "   ══╩══   "]
            for ri, ln in enumerate(rows):
                shift = int(round(lean_ * (8 - ri) / 8.0))
                x0 = gx - 5 + shift
                for ci, ch in enumerate(ln):
                    if ch != " ":
                        isw = ch == "▒"
                        scr.put(x0 + ci, top + ri, ch, col(wcol if isw else (205, 232, 255)), 0 if isw else 1)
        glass(cx - gap, +lean)
        glass(cx + gap, -lean)
        if 0.95 <= a < 1.5:                                                     # the clink: a spark with rays
            for dx, dy, ch in ((0, 0, "✦"), (-2, -1, "✧"), (2, -1, "✧"), (0, -2, "✦"), (-4, 0, "·"), (4, 0, "·"), (-1, -1, "╲"), (1, -1, "╱"), (-3, -2, "·"), (3, -2, "·")):
                scr.put(cx + dx, top + dy, ch, pk((255, 250, 220)), 1)
        floor = min(H - 7, top + 20)
        if 1.2 < a < 3.2 and fade > 0:                                          # wine spills over both rims and falls
            for side in (-1, 1):
                if random.random() < 0.7:
                    self.parts.append(Particle(cx + side * (gap + 5), top + 1, side * random.uniform(0.3, 1.6), random.uniform(1, 4), 24.0,
                                               random.uniform(0.9, 1.6), random.choice("●•·"), (190, 28, 70)))
                sx = cx + side * (gap + 6)
                for yy in range(top + 1, min(floor, top + 1 + int((a - 1.2) * 10))):
                    scr.put(sx, yy, "╎", col(wcol), 0)
            for x in range(cx - gap - 9, cx + gap + 10):                        # pool + ripples where it lands
                if 0 <= x < W and 0 <= floor < H:
                    scr.put(x, floor, random.choice("~≈∽"), col((150, 25, 65)), 0)

    def draw(self, scr, now: float, W: int, H: int):
        """particles + lightning, drawn ON TOP of the text"""
        for p in self.parts:
            f = p.age / p.life
            col = p.col
            ch_ = "|/-\\"[int(p.age * 8) % 4] if p.ch in "|/-\\" else p.ch
            if ch_ != p.ch:
                p.ch = ch_
            if p.ch in "^'`´▴▲˄·˙.":                                              # flames cool from yellow to red as they rise
                col = mix((255, 215, 70), (190, 25, 10), f)
            col = mix(col, (6, 6, 14), clamp(f * f * 0.9))
            x, y = int(round(p.x)), int(round(p.y))
            if 0 <= x < W and 0 <= y < H and (x, y) not in self.mask:
                c = scr.cur[y * W + x]
                scr.cur[y * W + x] = (p.ch, pk(col), c[2], 1 if f < 0.5 else 0)
        if self.bolt:
            t0, bx, by = self.bolt
            if now - t0 > 0.28:
                self.bolt = None
            else:
                x, r = bx, random.Random(int(t0 * 100))
                for y in range(0, max(1, by)):
                    x += r.choice((-1, 0, 0, 1))
                    if (x, y) not in self.mask:
                        scr.put(x, y, r.choice("/|\\"), pk((235, 240, 255)), 1)


class CandyBG:
    """the immersive BACKGROUND: dark purple field, glossy objects drifting and 'spinning', twinkling sparkles. Pixel sprites drawn as half-blocks."""
    SPR = {
        "heart": ([" .# #. ", "#######", "#######", "#######", " ##### ", "  ###  ", "   #   "], ((255, 85, 95), (190, 25, 50)), (255, 235, 235)),
        "diamond": ([" ##### ", "#######", " ##### ", "  ###  ", "   #   "], ((120, 235, 255), (60, 150, 255)), (255, 255, 255)),
        "cherry": ["  . ##", " ## #  ", "##### ", "#####  ", " ###   "],
        "pine": ["  # #  ", " ##### ", "  ###  ", " ##### ", "#######", "#######", "#######", " ##### "],
        "lip": ["##", "##", "##", "##", "##", "##"],
    }

    def __init__(self, W=80, H=24):
        r = random.Random(3)
        kinds = ["heart", "heart", "diamond", "diamond", "cherry", "pine", "pine", "lip", "heart", "diamond"]
        self.obj = [dict(k=k, x=r.random(), y=r.random(), vx=r.uniform(-.012, .012), vy=r.uniform(-.016, .016), ph=r.random() * 6.28,
                         sp=r.uniform(.6, 1.6), s=r.choice((1, 1, 2))) for k in kinds]
        self.spark = [(r.random(), r.random(), r.random() * 6.28, r.choice("✦✦✧+")) for _ in range(18)]

    def sprite_pixels(self, o, t, pulse):
        k, sq = o["k"], abs(math.cos(o["ph"] + t * o["sp"]))
        sq = max(0.22, sq) if k in ("heart", "diamond") else 1.0
        spr = self.SPR[k]
        base = (1.0 + 0.5 * pulse)
        pix = []
        if k in ("heart", "diamond"):
            rows, (c1, c2), hl = spr
            n = len(rows)
            for ry, row in enumerate(rows):
                w = len(row)
                cw = max(2, int(w * sq))
                for cx in range(cw):
                    sx = int(cx / cw * w)
                    ch = row[sx]
                    if ch == " ":
                        continue
                    f = ry / max(1, n - 1)
                    col = mix(c1, c2, f)
                    if ch == "." or (k == "diamond" and (sx + ry) % 3 == 0):
                        col = hl if ch == "." else mix(col, (255, 255, 255), 0.45)
                    pix.append((cx - cw // 2, ry, tuple(min(255, int(v * base)) for v in col)))
        elif k == "cherry":
            for ry, row in enumerate(spr):
                for cx, ch in enumerate(row):
                    if ch == "#":
                        pix.append((cx, ry, tuple(min(255, int(v * base)) for v in ((240, 40, 60) if ry >= 2 else (90, 200, 70)))))
                    elif ch == ".":
                        pix.append((cx, ry, (90, 200, 70)))
        elif k == "pine":
            for ry, row in enumerate(spr):
                for cx, ch in enumerate(row):
                    if ch == "#":
                        col = (80, 200, 70) if ry < 2 else (((255, 200, 40) if (cx + ry) % 2 else (255, 130, 30)))
                        pix.append((cx - 3, ry, tuple(min(255, int(v * base)) for v in col)))
        else:
            for ry, row in enumerate(spr):
                for cx in range(2):
                    pix.append((cx, ry, tuple(min(255, int(v * base)) for v in ((255, 40, 70) if ry < 3 else (240, 190, 60)))))
        return pix

    def compose(self, scr, W: int, H: int, now: float, pulse: float, alpha: float = 1.0):
        deep0, deep1 = (28, 8, 40), (8, 3, 18)
        base = []
        for y in range(H):
            c = mix(deep0, deep1, y / max(1, H - 1))
            c = tuple(int(v * (1 + 0.35 * pulse)) for v in c)
            v = pk(c) & 0xFCFCFC
            base.append(("▀", v, v, 0))
        cells = [base[y] for y in range(H) for _ in range(W)]
        layer: dict = {}
        for o in self.obj:
            o["x"] = (o["x"] + o["vx"] * 0.033) % 1.15
            o["y"] = (o["y"] + o["vy"] * 0.033) % 1.15
            px, py = int((o["x"] - 0.07) * W), int((o["y"] - 0.07) * H * 2)
            sc = o["s"]
            for dx, dy, col in self.sprite_pixels(o, now, pulse):
                for ax in range(sc):
                    for ay in range(sc):
                        X, Y = px + dx * sc + ax, py + dy * sc + ay
                        if 0 <= X < W and 0 <= Y < H * 2:
                            layer[(X, Y)] = col
                            for gx, gy in ((X - 1, Y), (X + 1, Y), (X, Y - 1), (X, Y + 1)):          # soft glow
                                if (gx, gy) not in layer and 0 <= gx < W and 0 <= gy < H * 2:
                                    layer.setdefault(("g", gx, gy), col)
        for key, col in layer.items():
            if key[0] == "g":
                _, gx, gy = key
                if (gx, gy) in layer:
                    continue
                cy, half = gy // 2, gy % 2
                c = cells[cy * W + gx]
                g = tuple(int(v * 0.22) for v in col)
                tb = list(((c[1] >> 16) & 255, (c[1] >> 8) & 255, c[1] & 255)) if half == 0 else list(((c[2] >> 16) & 255, (c[2] >> 8) & 255, c[2] & 255))
                nc = (min(255, tb[0] + g[0]) << 16) | (min(255, tb[1] + g[1]) << 8) | min(255, tb[2] + g[2])
                cells[cy * W + gx] = (c[0], nc, c[2], 0) if half == 0 else (c[0], c[1], nc, 0)
        for (X, Y), col in ((k, v) for k, v in layer.items() if k[0] != "g"):
            cy, half = Y // 2, Y % 2
            c = cells[cy * W + X]
            v = pk(col) & 0xFCFCFC
            cells[cy * W + X] = (c[0], v, c[2], 0) if half == 0 else (c[0], c[1], v, 0)
        scr.cur = cells
        for sx, sy, ph, ch in self.spark:                                                           # twinkling sparkles
            if math.sin(now * 3 + ph) > 0.2:
                x, y = int(sx * W), int(sy * H)
                if 0 <= x < W and 0 <= y < H:
                    c = scr.cur[y * W + x]
                    scr.cur[y * W + x] = (ch, pk((235, 255, 200) if int(ph * 10) % 2 else (255, 255, 255)), c[2], 1)


def now_hud_ok(now: float) -> bool:
    """the warning blinks slowly (~1.2 Hz, mostly on) — deliberately nowhere near strobe territory"""
    return int(now * 1.6) % 4 != 3


class ThumbCache:
    """Small album covers for the list rows. get() returns a PIL image or None, and fetches it in the background."""

    def __init__(self):
        self.mem: dict = {}
        self.pending: set = set()
        self.pool = ThreadPoolExecutor(4)

    @staticmethod
    def small(url: str) -> str:
        if url and ("googleusercontent" in url or "ggpht" in url):
            return re.sub(r"=w\d+-h\d+.*$", "=w160-h160-l90-rj", url)
        return url

    def get(self, url: str, px: int = 96):
        if not url or Image is None:
            return None
        key = (url, px)
        im = self.mem.get(key)
        if im is not None:
            return im or None                           # False = failed before
        if key not in self.pending:
            self.pending.add(key)
            self.pool.submit(self._load, key)
        return None

    def _load(self, key):
        url, px = key
        try:
            im = load_art(self.small(url))
            if im is None:
                self.mem[key] = False
            else:
                if len(self.mem) > 600:
                    for k in list(self.mem)[:150]:
                        self.mem.pop(k, None)
                self.mem[key] = im.resize((px, px), Image.LANCZOS)
        except Exception as e:
            log(f"thumb {url[:60]}: {e!r}")
            self.mem[key] = False
        self.pending.discard(key)


def ph_color(seed: str) -> tuple:
    """a stable, pleasant placeholder colour for a cover that hasn't loaded yet"""
    h = int(hashlib.sha1(seed.encode("utf-8", "ignore")).hexdigest()[:6], 16) % 360 / 360.0
    return hsl(h, 0.5, 0.30), hsl(h + 0.07, 0.55, 0.20)


class Base:
    def __init__(self, cfg, state: State, fx: Fetcher):
        self.cfg, self.state, self.fx = cfg, state, fx
        self.offset, self.glow = cfg.offset, cfg.glow
        self.level = {"off": 0, "low": 1, "high": 2}[cfg.shader]
        self.art_on = cfg.art
        self.preset = next((i for i, p in enumerate(PRESETS) if p[0] == cfg.before and p[1] == cfg.after), 0)
        self.toast, self.toast_until = "", 0.0
        self.hint_until = time.monotonic() + 12
        self.running = True
        self.cur_key = None
        self.pal = DEFAULT_PALETTE
        self.debug = cfg.debug
        self.stats = (0.0, 0)
        self.gstyle = cfg.glow_style if cfg.glow_style in GLOW_STYLES else "soft"
        self.gcolor = cfg.glow_color or "album"
        self.gsize = clamp(float(cfg.glow_size), 0.4, 3.0)
        self.gfollow = cfg.glow_follow or None
        self.size_dirty, self._size_t, self._size = True, -9.0, (80, 24, 0, 0)
        # ---- beat-reactive background + cyberpsychosis (works in both renderers, with or without numpy)
        self.beat = Beat(cfg)
        self.cyber_mode = str(getattr(cfg, "cyber_mode", "auto")).lower()       # off | auto (tribute song only) | on (every song)
        self.cyber_int = clamp(float(getattr(cfg, "cyber_intensity", 0.7)), 0.0, 1.0)
        self.cyber_shake = clamp(float(getattr(cfg, "cyber_shake", 0.6)), 0.0, 1.0)
        self.guard = FlashGuard()
        self.pulse = self.energy = self.k = self.shake_amp = 0.0
        self.cyber_on = self.moon_on = False
        self.gseed, self.gseed_t, self.burst_n, self.shake_t, self.shake_dir = 0, 0.0, 0, -9.0, (1, 0)
        self.stutter = False
        self.addons = load_addons(cfg)                                                # *.add background packs
        self.bg_mode = str(getattr(cfg, "bg_mode", "auto")).lower()                   # auto | procedural | off
        self.bgm, self.bg_spec, self.bg_key, self.bg_gen, self.bg_err = None, None, None, 0, ""
        self.lyric_style = str(getattr(cfg, "lyric_style", "classic")).lower()      # classic | kinetic
        self.figures = bool(getattr(cfg, "cyber_figures", True))                      # David & Lucy silhouettes in the built-in scene
        self.ui = load_addon_ui(cfg)                                                  # caption placement, buttons, lyric rules, word effects
        self.imm, self.candy = ImmersiveFX(), CandyBG()
        self.rule, self.imm_bg_a, self._imm_t = None, 0.0, None
        self.btn_rects: list = []
        self.wants_mouse = bool(self.ui["buttons"])
        self.thumbs = ThumbCache()
        self.art_slots: list = []                       # filled by draw_browser: (art url, x, y, cols, rows, kind, title)
        self.list_style = str(getattr(cfg, "list_style", None) or "classic").lower()
        self.item_rows, self.art_cols = 2, 4            # row height of a song in the modern list / cover width in cells
        self.jam = None
        self.prompt = None
        self.ytm: "YtmPlayer | None" = None
        self.view = "lyrics"
        _f = str(getattr(cfg, "ytm_search_filter", "all")).lower()
        self.br = types.SimpleNamespace(tab="quick", input=False, query="", data={}, stack=[], last_text="",
                                        filter=_f if _f in ("all", "songs", "albums", "artists") else "all")
        self.chip_rects: list = []
        self.rpc: "DiscordRPC | None" = None
        mode = str(getattr(cfg, "low_end", "auto")).lower()
        self.low_mode = mode
        self.low = mode in ("on", "true", "1") or (mode == "auto" and auto_low_end())
        self.slow_since = None

    def target_fps(self) -> float:
        return min(self.cfg.fps, 15.0) if self.low else self.cfg.fps

    def set_low(self, on: bool, why: str = ""):
        if on == self.low:
            return
        self.low = on
        self.on_low()
        self.say(("low-end mode ON" + (f" ({why})" if why else "") + " — L to undo") if on else "low-end mode off", 4.0)

    def on_low(self):
        pass

    def watch(self, ms: float, budget_ms: float, now: float):
        """Auto-degrade: if frames keep costing more than the frame budget, switch low-end mode on."""
        if self.low or self.low_mode == "off":
            self.slow_since = None
            return
        if ms > budget_ms * 1.5:
            self.slow_since = self.slow_since or now
            if now - self.slow_since > 4.0:
                self.set_low(True, "auto: frames are too slow")
        else:
            self.slow_since = None

    def setup(self) -> bytes:
        return b""

    def teardown(self) -> bytes:
        return b""

    def fx_update(self, track, t: float, now: float):
        """once per frame: sample the beat, decide whether cyberpsychosis is active, update glitch / shake state"""
        ly = self.fx.lyrics
        self.update_rules(t, now)
        self.bg_update(track)
        self.beat.bind(track, ly)
        self.pulse, self.energy = self.beat.sample(t, now)
        if self.bg_spec and str(self.bg_spec.get("beat", "all")).lower() in ("none", "off", "false"):
            self.pulse = 0.0
        trib = is_tribute(track)
        ov = str((self.bg_spec or {}).get("cyber", "inherit")).lower()                # an addon can force cyberpsychosis on/off for its song
        self.cyber_on = bool(track) and ov != "off" and (ov == "on" or self.cyber_mode == "on" or (self.cyber_mode == "auto" and trib))
        scene_ok = str(getattr(self.cfg, "cyber_scene", "auto")).lower() != "off" and bool(getattr(self.cfg, "cyber_moon", True))
        self.moon_on = (self.cyber_on and scene_ok and self.bgm is None and not (self.bg_spec and self.bg_spec.get("file"))
                        and (trib or bool(getattr(self.cfg, "cyber_moon_all", False)))) or str((self.bg_spec or {}).get("file", "")) == "builtin:earth"
        if not self.cyber_on:
            self.k = self.shake_amp = 0.0
            self.stutter = False
            return
        dur = (track.duration if track and track.duration else None) or (ly.end + 2 if ly else 0) or 200.0
        prog = clamp(t / max(dur, 1.0))
        base = (0.14 + 0.56 * prog ** 1.4) if trib else (0.22 + 0.28 * prog)        # the tribute song slowly loses itself
        self.k = min(0.9, (base + 0.45 * self.pulse) * self.cyber_int * 1.25)
        if now - self.gseed_t > 0.09:                                              # glitch pattern changes ~11x/s, never faster
            self.gseed_t = now
            self.gseed += 1
        if self.pulse > 0.72 and self.guard.ok(now):                               # a beat -> one rate-limited burst (<= 3/s)
            self.burst_n += 1
            self.shake_t = now
            r = random.Random(self.burst_n * 31 + int(now))
            self.shake_dir = (r.choice((-1, 1)), r.choice((-1, 0, 1)))
        self.shake_amp = self.cyber_shake * math.exp(-(now - self.shake_t) / 0.13)
        self.stutter = bool(getattr(self.cfg, "cyber_stutter", True)) and self.k > 0.18 and (now - self.shake_t) < 0.26 and (self.gseed & 1) == 1

    def bg_update(self, track):
        """pick + (re)load the background media for this song: addon rule > config file > backgrounds/ folder"""
        key = (track.key if track else None, self.bg_mode, self.low)
        if key == self.bg_key:
            return
        self.bg_key, self.bg_gen = key, self.bg_gen + 1
        self.bgm, self.bg_spec, self.bg_err = None, None, ""
        spec = resolve_bg(self.cfg, track, self.addons) if (track and self.bg_mode == "auto") else None
        self.bg_spec = spec
        if not spec or not spec.get("file") or str(spec["file"]).startswith("builtin"):
            return
        gen = self.bg_gen

        def work():
            try:
                m = BgMedia.load(spec, width=320 if self.low else 480, max_frames=32 if self.low else 80)
                if gen == self.bg_gen:
                    self.bgm = m
            except Exception as e:
                self.bg_err = str(e)[:90]
                log(f"background {spec.get('file')}: {e!r}")

        threading.Thread(target=work, daemon=True).start()

    def eff_style(self) -> str:
        if self.rule and self.rule.get("style"):                                     # a lyric rule ("got a shotgun in my pocket") wins
            return str(self.rule["style"]).lower()
        return str((self.bg_spec or {}).get("lyric_style") or self.lyric_style).lower()

    def update_rules(self, t: float, now: float):
        ly = self.fx.lyrics
        self.rule = None
        if ly is not None:
            ln = ly.lines[max(ly.current(t), 0)]
            if ln.kind == "line":
                r = match_rule(self.ui["rules"], "".join(c.ch for c in ln.cells))
                if r is not None and ln.b - 0.05 <= t <= ln.e + float(r.get("hold", 0.6)):
                    self.rule = r
        want = 1.0 if (self.bg_mode == "immersive" or (self.rule and str(self.rule.get("bg", "")) == "immersive")) else 0.0
        dt = 0.033 if self._imm_t is None else min(0.2, now - self._imm_t)
        self._imm_t = now
        self.imm_bg_a += (want - self.imm_bg_a) * (1 - math.exp(-dt * 5))

    def run_action(self, act: str):
        """actions for addon buttons: next prev pause seek:+10 style:NAME bg:MODE cyber:MODE toggle:beat|figures effect:CAT toast:TEXT open:URL shell:CMD"""
        a, _, arg = str(act).partition(":")
        Y = self.ytm
        if a == "next":
            self.key("n")
        elif a == "prev":
            self.key("p")
        elif a == "pause":
            self.key(" ")
        elif a == "seek" and Y:
            try:
                Y.seek(float(arg))
            except ValueError:
                pass
        elif a == "style" and arg:
            self.lyric_style = arg
            self.say("lyric style: " + arg)
        elif a == "bg" and arg:
            self.bg_mode = arg
            self.say("background: " + arg)
        elif a == "cyber" and arg in ("off", "auto", "on"):
            self.cyber_mode = arg
            self.say("cyberpsychosis: " + arg)
        elif a == "toggle" and arg == "beat":
            self.key("B")
        elif a == "toggle" and arg == "figures":
            self.key("F")
        elif a == "effect" and arg in FX_WORDS:
            W, H, _, _ = self.sizes(time.monotonic())
            self.imm.trigger(arg, W // 2 - 3, H // 2, 6, time.monotonic(), W, H, self.guard)
        elif a == "toast":
            self.say(arg, 3.0)
        elif a == "open" and arg.startswith("http"):
            open_url(arg)
        elif a == "shell" and self.ui.get("shell") and arg:
            subprocess.Popen(shlex.split(arg), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif a == "shell":
            self.say("shell actions are off — set [addons] shell = true", 4.0)

    def draw_buttons(self, scr, W: int, H: int, pal):
        """custom addon buttons: ' label ' pills at an anchor (top-left … bottom-right) or at x,y. Tap / click / press their key."""
        self.btn_rects = []
        groups: dict = {}
        for b in self.ui["buttons"]:
            groups.setdefault(str(b.get("position", "top-right")), []).append(b)
        for pos, bs in groups.items():
            vert = pos.split("-")[0]
            row = {"top": 2, "middle": H // 2, "bottom": H - 4}.get(vert, 2)
            widths = [strw(str(b.get("label", "?"))) + 2 for b in bs]
            tot = sum(widths) + len(bs) - 1
            side = pos.split("-")[1] if "-" in pos else "right"
            x = {"left": 1, "center": (W - tot) // 2, "right": W - tot - 1}.get(side, W - tot - 1)
            for b, wd in zip(bs, widths):
                bx = int(b["x"]) if "x" in b else x
                by = int(b["y"]) if "y" in b else row
                fg = _hexcol(b.get("fg", "#ffffff"), (255, 255, 255))
                bgc = _hexcol(b.get("bg", "#2a2a40"), (42, 42, 64))
                for i in range(wd):
                    scr.put(bx + i, by, " ", pk(fg), 0, pk(bgc) & 0xFCFCFC)
                scr.text(bx + 1, by, str(b.get("label", "?")), pk(fg), 1)
                self.btn_rects.append((bx, by, wd, b))
                x += wd + 1

    def handle_click(self, x: int, y: int):
        if self.view == "pick":
            for cx, cy, wd, key in self.chip_rects:
                if cy == y and cx <= x < cx + wd:
                    self.set_filter(key)
                    return True
        for bx, by, wd, b in self.btn_rects:
            if by == y and bx <= x < bx + wd:
                self.run_action(b.get("action", ""))
                return True
        return False


    def tint_color(self):
        """colour the beat flashes with: the cover's accent, or red/cyan while cyberpsychosis is on"""
        if self.cyber_on:
            return (255.0, 40.0, 70.0) if (self.burst_n & 1) else (40.0, 225.0, 255.0)
        return self.pal.a

    def sizes(self, now: float):
        """terminal size in cells + pixels, re-queried on SIGWINCH (or once a second) instead of every frame"""
        if self.size_dirty or now - self._size_t > 1.0:
            W, H = term_size()
            _, _, xp, yp = win_px()
            self._size, self._size_t, self.size_dirty = (W, H, xp, yp), now, False
        return self._size

    def say(self, msg, secs=1.6):
        self.toast, self.toast_until = msg, time.monotonic() + secs

    def ctl(self, *args):
        _, _, player = self.state.snapshot()
        if not player or player == "demo" or player.startswith("android") or not shutil.which("playerctl"):
            return
        subprocess.Popen(["playerctl", "-p", player, *args], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def on_level(self):
        pass

    # ---- views (TAB): lyrics -> album cover -> song picker -------------------------------------------------
    VIEW_NAMES = {"lyrics": "lyrics", "cover": "album cover", "pick": "pick songs"}

    def views(self) -> list[str]:
        return ["lyrics", "cover"] + (["pick"] if self.ytm else [])

    def set_view(self, v: str):
        if v not in self.views():
            v = "lyrics"
        self.view = v
        if v == "pick":
            self.enter_tab(self.br.tab)
        self.say(self.VIEW_NAMES[v], 1.0)

    def cycle_view(self, d: int = 1):
        vs = self.views()
        i = vs.index(self.view) if self.view in vs else 0
        self.set_view(vs[(i + d) % len(vs)])

    # ---- browser (search / quick picks / albums / radios / playlists / queue)
    BR_TABS = [("search", "Search"), ("quick", "Quick picks"), ("albums", "Albums"), ("radios", "Radios"),
               ("playlists", "Playlists"), ("queue", "Queue")]
    ICONS = {"song": "♪", "album": "◉", "playlist": "☰", "radio": "◈"}

    def tab(self, name: str):
        d = self.br.data
        if name not in d:
            d[name] = types.SimpleNamespace(items=[], sel=0, busy=False, msg="", t=0.0)
        return d[name]

    def cur_ns(self):
        return self.br.stack[-1] if self.br.stack else self.tab(self.br.tab)

    def cur_items(self) -> list:
        if not self.br.stack and self.br.tab == "queue" and self.ytm:
            return self.ytm.queue
        return self.cur_ns().items

    def _bg(self, ns, fn, *a):
        ns.busy, ns.msg = True, ""

        def work():
            try:
                items = fn(*a)
                ns.items, ns.msg = items, ("" if items else "nothing here")
                ns.sel = min(ns.sel, max(len(items) - 1, 0))
            except Exception as e:
                ns.items, ns.msg = [], str(e)[:160]
                if not isinstance(e, PermissionError):
                    log(f"browser: {e!r}")
            ns.busy, ns.t = False, time.time()

        threading.Thread(target=work, daemon=True).start()

    def _radios(self) -> list[dict]:
        out, Y = [], self.ytm
        if Y and 0 <= Y.idx < len(Y.queue):
            cur = Y.queue[Y.idx]
            out.append(dict(kind="radio", id="SEED", seed=cur["id"], title="Radio from the current song",
                            artist=f"{cur['title']} — {cur['artist']}", album="", dur=None, art=cur.get("art", ""), url=""))
        try:
            out += load_home_kind("radio")
        except Exception as e:
            if not out:
                raise
            log(f"radios: {e!r}")
        return out

    def load_tab(self, tab: str, force: bool = False):
        ns = self.tab(tab)
        if ns.busy or (not force and ns.items and time.time() - ns.t < 300):
            return
        if tab == "quick":
            self._bg(ns, load_quick_picks)
        elif tab == "albums":
            self._bg(ns, load_library, "albums") if ACCOUNT.signed_in else self._bg(ns, load_home_kind, "album")
        elif tab == "radios":
            self._bg(ns, self._radios)
        elif tab == "playlists":
            self._bg(ns, load_library, "playlists")

    def enter_tab(self, tab: str):
        self.br.tab, self.br.stack = tab, []
        self.load_tab(tab)
        if tab == "queue" and self.ytm and self.ytm.idx >= 0:
            self.tab("queue").sel = self.ytm.idx

    FILTERS = ("all", "songs", "albums", "artists")

    def set_filter(self, key=None):
        """the search filter chips (All / Songs / Albums / Artists): re-runs the last search with the new filter"""
        B = self.br
        if key is None:
            key = self.FILTERS[(self.FILTERS.index(B.filter) + 1) % len(self.FILTERS)] if B.filter in self.FILTERS else "all"
        B.filter = key
        if B.last_text:
            self.start_search(B.last_text)
        else:
            self.say("search filter: " + key, 1.5)

    def start_search(self, q: str, autoplay: bool = False):
        kind, text = parse_search(q, self.br.filter)
        if kind in self.FILTERS:
            self.br.filter = kind                                  # a prefix (album: …) also sets the chip
        self.br.last_text = text
        ns = self.tab("search")
        self.br.tab, self.br.stack = "search", []
        ns.busy, ns.msg, ns.sel = True, "", 0

        def work():
            try:
                res = expand_url(text) if text.startswith("http") else search_ytm(text, 25, kind)
                ns.items, ns.msg = res, ("" if res else "no results")
                if autoplay and res and self.ytm:
                    songs = [r for r in res if r.get("kind", "song") == "song"]
                    if songs:
                        self.ytm.play_items(songs, 0)
                        self.view = "lyrics"
                    else:
                        self.open_collection(res[0], play=True)
            except Exception as e:
                ns.items, ns.msg = [], f"search failed: {e}"[:160]
            ns.busy = False

        threading.Thread(target=work, daemon=True).start()

    def open_collection(self, e: dict, play: bool = False, add: bool = False, next_up: bool = False):
        Y = self.ytm
        if play or add:
            def work():
                try:
                    items = open_entry(e)
                    if not items:
                        return self.say("nothing to play", 3)
                    cn = len(items) if e.get("kind") == "album" else 30           # an album is cached whole
                    tail = " — caching…" if Y.cache.enabled else ""
                    if play:
                        Y.play_items(items, 0, cache_n=cn)
                        self.view = "lyrics"
                        self.say(f"playing {len(items)} songs" + tail, 3)
                    else:
                        k = Y.enqueue(items, next_up=next_up, cache_n=cn)
                        self.say(f"{'next up: ' if next_up else 'queued '}{k} songs" + tail, 3)
                except Exception as ex:
                    self.say(str(ex)[:90], 5)

            threading.Thread(target=work, daemon=True).start()
            return
        ns = types.SimpleNamespace(title=e["title"], items=[], sel=0, busy=True, msg="", t=0.0, entry=e)
        self.br.stack.append(ns)
        self._bg(ns, open_entry, e)

    def login_async(self):
        if getattr(self, "login_busy", False):
            return
        self.login_busy = True
        self.say("looking for your YouTube login in your browsers…", 4)

        def work():
            try:
                name, browser = bind_account(self.cfg)
                self.say(f"signed in as {name} (using your {browser} login) ✔", 6)
                for t in ("albums", "playlists"):
                    self.tab(t).items, self.tab(t).t = [], 0
                if self.view == "pick":
                    self.load_tab(self.br.tab, force=True)
            except LoginError as e:
                self.say(str(e)[:160], 9)
            except Exception as e:
                log(f"login: {e!r}")
                self.say(f"sign-in failed: {e}"[:160], 9)
            self.login_busy = False

        threading.Thread(target=work, daemon=True).start()

    def radio_from(self, e: dict):
        def work():
            try:
                items = [e] + [x for x in related_ytm(e["id"]) if x["id"] != e["id"]]
                self.ytm.play_items(items, 0)
                self.view = "lyrics"
            except Exception as ex:
                self.say(str(ex)[:90], 5)

        self.say("starting radio…", 2)
        threading.Thread(target=work, daemon=True).start()

    def browser_key(self, k: str) -> bool:
        """True = consumed. Anything not handled here falls through to the global keys (space, n, +/-, s, g, y, c, L, q …)."""
        B, Y = self.br, self.ytm
        if B.input:
            if k == "\x03":
                return False
            if k == "ESC":
                B.input = False
            elif k == "ENTER":
                if B.query.strip():
                    B.input = False
                    self.start_search(B.query.strip())
            elif k == "BACKSPACE":
                B.query = B.query[:-1]
            elif len(k) == 1 and k.isprintable():
                B.query += k
            return True
        ns, items = self.cur_ns(), self.cur_items()
        n, sel = len(items), ns.sel
        tabs = [t for t, _ in self.BR_TABS]
        if k in ("UP", "k"):
            ns.sel = max(0, sel - 1)
        elif k in ("DOWN", "j"):
            ns.sel = min(max(n - 1, 0), sel + 1)
        elif k == "PGUP":
            ns.sel = max(0, sel - 8)
        elif k == "PGDN":
            ns.sel = min(max(n - 1, 0), sel + 8)
        elif k == "HOME":
            ns.sel = 0
        elif k == "END":
            ns.sel = max(n - 1, 0)
        elif k in ("LEFT", "RIGHT"):
            self.enter_tab(tabs[(tabs.index(B.tab) + (1 if k == "RIGHT" else -1)) % len(tabs)])
        elif len(k) == 1 and k in "123456":
            self.enter_tab(tabs[int(k) - 1])
        elif k == "/":
            B.input, B.query, B.tab, B.stack = True, "", "search", []
        elif k == "ENTER" and n:
            e = items[sel]
            if B.tab == "queue" and not B.stack:
                Y.play_index(sel)
                self.set_view("lyrics")
            elif e.get("kind", "song") == "song":
                songs = [x for x in items if x.get("kind", "song") == "song"]
                Y.play_items(songs, songs.index(e))
                self.set_view("lyrics")
            elif e.get("kind") in ("album", "artist") and str(getattr(self.cfg, "ytm_album_enter", "play")).lower() == "play":
                self.open_collection(e, play=True)             # an album / artist is queued whole and cached (o opens it as a list instead)
            else:
                self.open_collection(e)
        elif k == "p" and n:
            e = items[sel]
            if e.get("kind", "song") == "song":
                songs = [x for x in items if x.get("kind", "song") == "song"]
                Y.play_items(songs, songs.index(e))
                self.set_view("lyrics")
            else:
                self.open_collection(e, play=True)
        elif k == "a" and n:
            e = items[sel]
            if e.get("kind", "song") == "song":
                Y.enqueue([e])
                self.say("added: " + e["title"][:40], 2)
            else:
                self.open_collection(e, add=True)
        elif k == "o" and n and items[sel].get("kind", "song") != "song":
            self.open_collection(items[sel])                   # browse an album / artist / playlist as a list
        elif k == "A" and n:                                   # play next
            e = items[sel]
            if e.get("kind", "song") == "song":
                self.say(f"plays next: {e['title'][:34]}" if Y.enqueue([e], next_up=True) else "already in the queue", 2)
            else:
                self.open_collection(e, add=True, next_up=True)
        elif k == "f" and B.tab == "search" and not B.stack:
            self.set_filter()
        elif k in ("K", "J") and B.tab == "queue" and not B.stack and n:
            ns.sel = Y.move(sel, -1 if k == "K" else 1)
        elif k == "C" and B.tab == "queue" and not B.stack:
            self.say(f"cleared {Y.clear_upcoming()} upcoming songs", 2.5)
        elif k == "r" and n:
            e = items[sel]
            self.radio_from(e) if e.get("kind", "song") == "song" else self.open_collection(e, play=True)
        elif k in ("d", "DEL") and B.tab == "queue" and not B.stack and n:
            Y.remove(sel)
            ns.sel = min(sel, max(len(Y.queue) - 1, 0))
        elif k == "ESC":
            if B.stack:
                B.stack.pop()
            else:
                self.set_view("lyrics")
        elif k == "BACKSPACE" and B.stack:
            B.stack.pop()
        else:
            return False
        return True

    def draw_browser(self, scr, x: int, y: int, w: int, h: int, pal):
        B, Y = self.br, self.ytm
        self.art_slots = []
        if h < 5 or w < 14:
            return
        dim = pk(mix(pal.deep, WHITE, 0.55))
        faint = pk(mix(pal.deep, WHITE, 0.38))
        acc = pk(mix(pal.a, WHITE, 0.2))
        cx = x
        for i, (key, label) in enumerate(self.BR_TABS):
            txt = f"{i + 1} {label}"
            if cx + len(txt) + 1 > x + w:
                break
            if key == B.tab:
                scr.text(cx, y, "▸" + txt, acc, 1)
                cx += len(txt) + 3
            else:
                scr.text(cx, y, txt, dim, 0)
                cx += len(txt) + 2
        if B.input:
            scr.text(x, y + 1, trunc("search ›  " + B.query, w - 1) + "▏", pk(WHITE), 1)
        else:
            crumb = "  ›  ".join([dict(self.BR_TABS)[B.tab]] + [s.title for s in B.stack])
            scr.text(x, y + 1, trunc(crumb, w), faint, 2)
        self.chip_rects = []
        if B.tab == "search" and not B.stack and h > 6:           # filter chips: All · Songs · Albums · Artists (classic and modern lists)
            cx2 = x
            for key, label in (("all", "All"), ("songs", "Songs"), ("albums", "Albums"), ("artists", "Artists")):
                txt = f" {label} "
                if cx2 + len(txt) > x + w:
                    break
                if B.filter == key:
                    for i, chh in enumerate(txt):
                        scr.put(cx2 + i, y + 2, chh, pk(pal.deep), 1, pk(mix(pal.a, WHITE, 0.3)) & 0xFCFCFC)
                else:
                    scr.text(cx2, y + 2, txt, dim, 0)
                self.chip_rects.append((cx2, y + 2, len(txt), key))
                cx2 += len(txt) + 1
        ns, items = self.cur_ns(), self.cur_items()
        top, rows = y + 3, h - 5
        if ns.busy and not items:
            scr.text(x, top, "loading" + "." * (1 + int(time.monotonic() * 3) % 3), dim, 2)
        elif not items:
            msg = ns.msg or {"search": "press /  to search  (prefix with  album:  or  playlist:  to search those)",
                             "queue": "the queue is empty — pick something with TAB"}.get(B.tab, "nothing here yet")
            for j, part in enumerate(msg.split(" — ")):
                scr.text(x, top + j * 2, trunc(part, w), dim, 2)
        modern = self.list_style == "modern" and Image is not None and w >= 30
        ih, aw = (self.item_rows, self.art_cols) if modern else (1, 0)
        vis = max(1, rows // ih)
        first = max(0, min(ns.sel - vis // 2, max(0, len(items) - vis)))
        for r in range(vis):
            i = first + r
            if i >= len(items):
                break
            it = items[i]
            kind = it.get("kind", "song")
            cur = B.tab == "queue" and not B.stack and Y and i == Y.idx
            sel = i == ns.sel
            right = fmt_time(it["dur"]) if (kind == "song" and it.get("dur")) else ("" if kind == "song" else kind)
            if kind == "song" and Y and Y.cache.enabled:                  # ● on disk (instant, gapless)  ◐ downloading  ◌ waiting
                cm = {"cached": "●", "loading": "◐", "queued": "◌"}.get(Y.cache.status(it["id"]), "")
                if cm:
                    right = (cm + " " + right).strip()
            col = pk(WHITE) if sel else (pk(pal.a) if cur else pk(mix(pal.deep, WHITE, 0.74)))
            if not modern:
                icon = "▶" if cur else ("›" if sel else " ")
                label = f"{icon} {self.ICONS.get(kind, '♪')}  {it['title']}" + (f" — {it['artist']}" if it.get("artist") else "")
                scr.text(x, top + r, trunc(label, w - len(right) - 2), col, 1 if (sel or cur) else 0)
                scr.text(x + w - len(right), top + r, right, dim, 0)
                continue
            y0 = top + r * ih
            bar = pk(pal.a) if (sel or cur) else 0
            for k in range(ih if ih < 3 else 2):          # selection / now-playing marker beside the cover
                if bar:
                    scr.put(x, y0 + k, "▎", bar, 1)
            ax = x + 2
            c1, c2 = ph_color(it.get("art") or it.get("title", ""))
            for rr in range(ih if ih < 3 else 3):         # placeholder cover (replaced by the real one once it loads)
                for cc in range(aw):
                    scr.put(ax + cc, y0 + rr, "▀", pk(mix(c1, c2, (rr * 2) / max(2 * ih - 1, 1))), 0, pk(mix(c1, c2, (rr * 2 + 1) / max(2 * ih - 1, 1))))
            self.art_slots.append((it.get("art") or "", ax, y0, aw, ih if ih < 3 else 3, kind, it.get("title", "")))
            tx = ax + aw + 1
            tw = max(4, w - (tx - x) - len(right) - 2)
            mark = "▶ " if cur else ""
            scr.text(tx, y0, trunc(mark + it["title"], tw), col, 1 if (sel or cur) else 0)
            sub = it.get("artist", "") if kind != "song" else " · ".join(v for v in (it.get("artist", ""), it.get("album", "")) if v)
            scr.text(tx, y0 + 1, trunc(self.ICONS.get(kind, "♪") + "  " + sub, tw), faint, 0)
            scr.text(x + w - len(right), y0, right, dim, 0)
        if len(items) > vis:
            scr.text(x + w - 6, y + 1, f"{ns.sel + 1}/{len(items)}", faint, 0)
        if B.tab == "queue" and not B.stack and Y and Y.queue and Y.cache.enabled:
            d_, t_ = Y.cache.counts(Y.queue)
            scr.text(x + max(0, w - 22), y + 1, f"cached {d_}/{t_}", faint, 0)
        if B.tab == "playlists" and not ACCOUNT.signed_in and not items:
            scr.text(x, top + 5, "▸ press  l  — lyricglow reuses the YouTube login from your browser", acc, 1)
        if B.input:
            hint = "⏎ search   esc cancel     prefix: song: / album: / artist: / playlist:"
        elif B.tab == "queue" and not B.stack:
            hint = "⏎ play  d remove  K/J move up/down  A next  C clear upcoming  z shuffle  ←→ tabs"
        else:
            hint = ("↑↓ move  ⏎ play (albums & artists queue whole)  o open  a queue  A next  r radio  f filter  / search  ←→ tabs  esc back"
                    + ("" if ACCOUNT.signed_in else "  l sign in"))
        scr.text(x, y + h - 1, trunc(hint, w), faint, 2)

    def key(self, k: str):
        if k.startswith("CLICK:"):
            _, cx, cy = k.split(":")
            self.handle_click(int(cx), int(cy))
            return
        for b in self.ui["buttons"]:
            if b.get("key") and k == str(b["key"]):
                return self.run_action(b.get("action", ""))
        if k in ("TAB", "BTAB"):
            return self.cycle_view(1 if k == "TAB" else -1)
        if self.view == "pick" and self.ytm and self.browser_key(k):
            return
        Y = self.ytm
        if k in ("q", "\x03"):
            self.running = False
        elif Y and k == "/":
            self.set_view("pick")
            self.br.input, self.br.query, self.br.tab, self.br.stack = True, "", "search", []
        elif Y and k == "Q":
            self.set_view("pick")
            self.enter_tab("queue")
        elif Y and k == "l":
            self.login_async()
        elif Y and k == "LEFT":
            Y.seek(-5); self.say("⏪ 5s")
        elif Y and k == "RIGHT":
            Y.seek(5); self.say("⏩ 5s")
        elif Y and k in ("+", "="):
            self.say(f"volume {Y.change_volume(5)}")
        elif Y and k in ("-", "_"):
            self.say(f"volume {Y.change_volume(-5)}")
        elif Y and k == "z":
            Y.shuffle_upcoming(); self.say("shuffled the upcoming queue")
        elif Y and k == "R":
            self.say("repeat: " + Y.cycle_repeat())
        elif k == " ":
            if Y:
                Y.toggle_pause()
            else:
                self.ctl("play-pause")
            self.say("play / pause")
        elif k == "n":
            if Y:
                Y.next()
            else:
                self.ctl("next")
            self.say("next ⏭")
        elif k == "p":
            if Y:
                Y.prev()
            else:
                self.ctl("previous")
            self.say("previous ⏮")
        elif k == "s":
            self.preset = (self.preset + 1) % len(PRESETS)
            self.say("style: " + PRESETS[self.preset][2])
        elif k in ("g", "G"):
            self.glow = clamp(self.glow + (0.15 if k == "G" else -0.15), 0.0, 2.0)
            self.say(f"glow {self.glow:.2f}")
        elif k == "v":
            self.level = (self.level + 1) % 3
            self.on_level()
            self.say("effects: " + ["off", "low", "high"][self.level])
        elif k == "L":
            self.set_low(not self.low)
        elif k == "b":
            order = ["auto", "procedural", "immersive", "off"]
            self.bg_mode = order[(order.index(self.bg_mode) + 1) % 4] if self.bg_mode in order else "auto"
            self.say({"auto": "background: images / GIFs / addons when available", "procedural": "background: animated colours only",
                      "immersive": "background: immersive (glossy objects + sparkles)", "off": "background: plain"}[self.bg_mode], 3.0)
        elif k == "F":
            self.figures = not self.figures
            self.say("David & Lucy silhouettes " + ("ON" if self.figures else "off"))
        elif k == "T":
            order = ["classic", "kinetic", "word", "immersive", "slice", "caption", "vintage"]
            self.lyric_style = order[(order.index(self.lyric_style) + 1) % len(order)] if self.lyric_style in order else "classic"
            self.say("lyric style: " + self.lyric_style)
        elif k == "B":
            self.beat.enabled = not self.beat.enabled
            self.say("beat-reactive background " + ("ON" if self.beat.enabled else "off"))
        elif k == "X":
            order = ["off", "auto", "on"]
            self.cyber_mode = order[(order.index(self.cyber_mode) + 1) % 3] if self.cyber_mode in order else "auto"
            self.say({"off": "cyberpsychosis OFF", "auto": "cyberpsychosis: only on the tribute song",
                      "on": "CYBERPSYCHOSIS: every song"}[self.cyber_mode], 3.0)
        elif k == "y":
            self.gstyle = GLOW_ORDER[(GLOW_ORDER.index(self.gstyle) + 1) % len(GLOW_ORDER)]
            self.say("glow style: " + self.gstyle)
        elif k == "c":
            i = GLOW_COLORS.index(self.gcolor) if self.gcolor in GLOW_COLORS else -1
            self.gcolor = GLOW_COLORS[(i + 1) % len(GLOW_COLORS)]
            self.say("glow colour: " + self.gcolor)
        elif k == "i":
            self.art_on = not self.art_on
            self.say("cover art " + ("on" if self.art_on else "off"))
        elif k == "]":
            self.offset += 0.1; self.say(f"sync {self.offset:+.1f}s (lyrics earlier)")
        elif k == "[":
            self.offset -= 0.1; self.say(f"sync {self.offset:+.1f}s (lyrics later)")
        elif k == "0":
            self.offset = 0.0; self.say("sync reset")
        elif k == "r":
            tr, _, _ = self.state.snapshot()
            self.fx.request(tr, force=True); self.say("refetching lyrics…")
        elif k == "d":
            self.debug = not self.debug
        elif k == "h":
            self.hint_until = 0.0 if time.monotonic() < self.hint_until else time.monotonic() + 30

    def on_track(self, track):
        self.cur_key = track.key if track else None
        self.fx.request(track)

    def overlay(self, scr: "Screen", W, H, pal, track, playing):
        """toast / hints / errors / debug on the bottom row + pause badge — shared by both renderers"""
        now = time.monotonic()
        if now < self.toast_until:
            msg, col = self.toast, mix(pal.deep, WHITE, 0.85)
        elif now < self.hint_until:
            msg = "tab views  space pause  n/p track  s style  y/c glow  g/G  [ ] sync  v fx  L low-end  q quit" + ("  / search" if self.ytm else "")
            col = mix(pal.deep, pal.b, 0.55)
        elif self.state.error:
            msg, col = self.state.error, mix(pal.deep, (255, 140, 120), 0.8)
        else:
            msg, col = "", None
        if msg:
            scr.text(2, H - 1, trunc(msg, W - 4), pk(col), 2)
        if self.debug:
            d = f"{self.stats[0]:.1f}ms {self.stats[1] / 1024:.0f}KB" + (f"  discord: {self.rpc.status}" if self.rpc else "")
            scr.text(W - 2 - len(d), H - 1, d, pk(mix(pal.deep, WHITE, 0.5)), 0)
        if self.cyber_on and bool(getattr(self.cfg, "cyber_hud", True)) and now_hud_ok(time.monotonic()):
            pct = int(self.k * 100)
            txt = f"⚠ CYBERPSYCHOSIS {'▮' * min(5, pct // 18)}{'▯' * (5 - min(5, pct // 18))} {pct}%"
            scr.text(max(0, (W - strw(txt)) // 2), 1, txt, pk((255, 60, 85) if (self.burst_n & 1) else (40, 235, 255)), 1)
        if track and not playing:
            scr.text(W - 9, 0, "⏸ paused", pk(mix(pal.deep, WHITE, 0.55)), 0)


# =========================================================================== cell renderer

_sgr_cache: dict = {}
BLANK = (" ", 0, -1, 0)


def sgr(fg: int, bg: int, at: int) -> str:
    k = (fg, bg, at)
    s = _sgr_cache.get(k)
    if s is None:
        bgs = ";49" if bg < 0 else f";48;2;{bg >> 16};{(bg >> 8) & 255};{bg & 255}"
        s = ("\x1b[0" + (";1" if at & 1 else "") + (";3" if at & 2 else "") +
             f";38;2;{fg >> 16};{(fg >> 8) & 255};{fg & 255}" + bgs + "m")
        if len(_sgr_cache) > 60000:
            _sgr_cache.clear()
        _sgr_cache[k] = s
    return s


class Screen:
    def __init__(self):
        self.W = self.H = 0
        self.cur: list = []
        self.prv = None

    def resize(self, W, H):
        self.W, self.H = W, H
        self.prv = None
        self.cur = [BLANK] * (W * H)

    def clear(self):
        self.cur = [BLANK] * (self.W * self.H)

    def put(self, x, y, ch, fg, at=0, bg=None):
        if 0 <= x < self.W and 0 <= y < self.H:
            i = y * self.W + x
            self.cur[i] = (ch, fg, self.cur[i][2] if bg is None else bg, at)

    def text(self, x, y, s, fg, at=0):
        for ch in clusters(s):
            w = cw(ch)
            self.put(x, y, ch, fg, at)
            if w == 2:
                self.put(x + 1, y, "", fg, at)
            x += w
        return x

    def flush(self) -> str:
        W, H, cur, prv = self.W, self.H, self.cur, self.prv
        out = []
        ap = out.append
        last = None
        px = py = -1
        for y in range(H):
            row = y * W
            x = 0
            while x < W:
                c = cur[row + x]
                if prv is not None and prv[row + x] == c:
                    x += 1
                    continue
                ch, fg, bg, at = c
                if ch == "":
                    x += 1
                    continue
                if py != y or px != x:
                    ap(f"\x1b[{y + 1};{x + 1}H")
                st = (fg, bg, at)
                if st != last:
                    ap(sgr(fg, bg, at))
                    last = st
                ap(ch)
                w = 2 if (x + 1 < W and cur[row + x + 1][0] == "") else 1
                px, py = x + w, y
                x += 1
        self.prv = cur[:]
        return "".join(out)


class Shader:
    """Animated plasma + vignette (pure python, table-driven sines) for the cell renderer."""

    def resize(self, W, H):
        self.W, self.H = W, H
        self.s11 = [math.sin(x * 0.11) for x in range(W)]
        self.c11 = [math.cos(x * 0.11) for x in range(W)]
        self.s07 = [math.sin(x * 0.07) for x in range(W)]
        self.c07 = [math.cos(x * 0.07) for x in range(W)]
        self.s23 = [math.sin(y * 0.23) for y in range(H)]
        self.c23 = [math.cos(y * 0.23) for y in range(H)]
        self.topg = [0.06 * math.exp(-y / max(H * 0.22, 1.0)) for y in range(H)]
        self.sr, self.cr, self.vig = [], [], []
        for y in range(H):
            for x in range(W):
                r = math.hypot(x - W * 0.5, (y - H * 0.5) * 2.0)
                self.sr.append(math.sin(r * 0.09))
                self.cr.append(math.cos(r * 0.09))
                dx = (x - W * 0.5) / (W * 0.5)
                dy = (y - H * 0.5) / (H * 0.5)
                self.vig.append(clamp(1.0 - 0.55 * (dx * dx * 0.75 + dy * dy * 0.9), 0.22, 1.0))

    def paint(self, t, pal: Palette, strength: float):
        W, H = self.W, self.H
        n = W * H
        d, a, b = pal.deep, pal.a, pal.b
        if strength <= 0:
            return [d[0]] * n, [d[1]] * n, [d[2]] * n
        R, G, B = [0.0] * n, [0.0] * n, [0.0] * n
        c3, s3 = math.cos(0.30 * t), math.sin(0.30 * t)
        ca, sa = math.cos(0.22 * t), math.sin(0.22 * t)
        c4, s4 = math.cos(0.40 * t), math.sin(0.40 * t)
        t1 = [self.s11[x] * c3 + self.c11[x] * s3 for x in range(W)]
        s07, c07, sr, cr, vig = self.s07, self.c07, self.sr, self.cr, self.vig
        d0, d1, d2 = d
        ar, ag, ab = a
        dr, dg, db = b[0] - ar, b[1] - ag, b[2] - ab
        for y in range(H):
            t2 = self.s23[y] * ca - self.c23[y] * sa
            q = y * 0.15 + 0.17 * t
            cq, sq = math.cos(q), math.sin(q)
            tg = self.topg[y]
            base = y * W
            for x in range(W):
                i = base + x
                v = (t1[x] + t2 + s07[x] * cq + c07[x] * sq + sr[i] * c4 - cr[i] * s4) * 0.125 + 0.5
                m = strength * (0.2 + 0.8 * v * v) * vig[i] + tg
                R[i] = d0 + (ar + dr * v - d0) * m
                G[i] = d1 + (ag + dg * v - d1) * m
                B[i] = d2 + (ab + db * v - d2) * m
        return R, G, B


def splat(R, G, B, W, H, cx, cy, rx, ry, col, k):
    """Additive soft light blob — the glow/bloom of the cell renderer."""
    if k <= 0.002:
        return
    x0, x1 = max(0, int(cx - rx * 2)), min(W - 1, int(cx + rx * 2))
    y0, y1 = max(0, int(cy - ry * 2)), min(H - 1, int(cy + ry * 2))
    irx, iry = 1.0 / (rx * rx), 1.0 / (ry * ry)
    cr_, cg_, cb_ = col[0] * k, col[1] * k, col[2] * k
    for y in range(y0, y1 + 1):
        dy2 = (y + 0.5 - cy) ** 2 * iry
        if dy2 >= 4:
            continue
        base = y * W
        for x in range(x0, x1 + 1):
            d = (x + 0.5 - cx) ** 2 * irx + dy2
            if d >= 4:
                continue
            g = 1.0 - d * 0.25
            g *= g
            i = base + x
            R[i] = min(255.0, R[i] + cr_ * g)
            G[i] = min(255.0, G[i] + cg_ * g)
            B[i] = min(255.0, B[i] + cb_ * g)


def row_state(row: Row, t: float):
    """-> (glow-head x within row, activity 0..1)"""
    if t < row.b:
        return 0.0, clamp(1.0 - (row.b - t) / 0.5) * 0.2
    if t >= row.e:
        return float(row.w), math.exp(-(t - row.e) / 0.35)
    head = float(row.w)
    for c, x in zip(row.cells, row.xs):
        if t < c.e:
            f = clamp((t - c.b) / (c.e - c.b)) if c.e > c.b else 0.0
            head = x + c.w * f
            break
    return head, 1.0


class CellApp(Base):
    def __init__(self, cfg, state, fx):
        super().__init__(cfg, state, fx)
        self.scr, self.shader = Screen(), Shader()
        self.focus: dict = {}
        self.scroll, self.scroll_ready = 0.0, False
        self.base = None
        self.base_t = -9.0
        self.art_grid, self.art_key = None, None
        self.flat_key, self.flat_cells = None, None
        self.item_rows, self.art_cols = 3, 6             # 6x3 cells = 6x6 half-block pixels per cover

    def on_level(self):
        self.base = None

    def on_low(self):
        self.base = None
        self.flat_key = None
        self.art_key = None

    def on_track(self, track):
        super().on_track(track)
        self.focus.clear()
        self.scroll_ready = False

    def col_before(self, pal, foc):
        if PRESETS[self.preset][0] == "desat":
            base = mix(desat(pal.a, 0.80), WHITE, 0.22)
            return mix(pal.deep, base, 0.40 + 0.52 * foc)
        return mix(pal.deep, pal.a, 0.38 + 0.50 * foc)

    def col_after(self, pal, foc, xf):
        tint = mix(pal.a, pal.b, clamp(xf) * 0.75)
        if PRESETS[self.preset][1] == "desat":
            return mix(pal.deep, desat(tint, 0.78), 0.42 + 0.50 * foc)
        return mix(mix(pal.deep, tint, 0.38 + 0.62 * foc), WHITE, 0.10 * foc)

    def frame(self, dt: float, now: float) -> bytes:
        W, H, _, _ = self.sizes(now)
        if (W, H) != (self.scr.W, self.scr.H):
            self.scr.resize(W, H)
            self.shader.resize(W, H)
            self.base = None
            self.art_key = None
        scr = self.scr
        track, playing, player = self.state.snapshot()
        key = track.key if track else None
        if key != self.cur_key:
            self.on_track(track)
        t_pos = self.state.position()
        t = t_pos + self.offset
        self.pal = self.pal.lerp(self.fx.palette, 1.0 - math.exp(-dt * 2.2))
        pal, glow = self.pal, self.glow
        self.fx_update(track, t, now)
        pulse = self.pulse

        low = self.low
        lvl = 0 if low else self.level
        tintc = self.tint_color()
        if lvl == 0:      # flat background: rebuilt only when the beat level (0-3) or the palette changes
            lev = min(3, int(pulse * 3.4))
            fk = (W, H, tuple(int(v) >> 2 for v in pal.deep), lev, self.burst_n & 1 if self.cyber_on else -1)
            if fk != self.flat_key:
                self.flat_key = fk
                self.flat_cells = [(" ", 0, pk(mix(pal.deep, tintc, 0.07 * lev)) & 0xFCFCFC, 0)] * (W * H)
            R = G = B = None
        else:
            hz = (0.0, 6.0, 10.0)[lvl]
            if self.base is None or now - self.base_t >= (1.0 / hz if hz else 0.0):
                self.base = self.shader.paint(now, pal, (0.0, 0.10, 0.18)[lvl])
                self.base_t = now
            R, G, B = self.base[0][:], self.base[1][:], self.base[2][:]
            if pulse > 0.04:                              # beat: wash the whole background with the accent / red / cyan
                kx = 0.17 * pulse
                R = [v + tintc[0] * kx for v in R]
                G = [v + tintc[1] * kx for v in G]
                B = [v + tintc[2] * kx for v in B]

        wide = (not low) and self.art_on and self.fx.art is not None and Image is not None and W >= 96 and H >= 20
        if wide:
            AW = int(clamp(W // 4, 22, 34)) // 2 * 2
            AH = AW // 2
            art_x = 5
            art_y = max(2, (H - AH - 6) // 2)
            lx0 = art_x + AW + 7
            lw_avail = W - lx0 - 4
        else:
            lx0, lw_avail = 3, W - 6
        lw = max(10, min(lw_avail, self.cfg.max_width))
        if not wide and lw < lw_avail:
            lx0 += (lw_avail - lw) // 2
        top, bottom = (1 if wide else 2), H - 3
        stage_h = max(1, bottom - top)
        cy = top + stage_h // 2

        items = []
        ly = self.fx.lyrics
        if ly is not None and self.view == "lyrics" and self.eff_style() not in ("kinetic", "word", "immersive", "slice", "caption", "vintage"):
            gap = 1 if stage_h >= 12 else 0
            rows_per, ys = ly.layout(lw, gap)
            cur = ly.current(t)
            ci = max(cur, 0)
            target = ys[ci] + (len(rows_per[ci]) - 1) / 2.0
            if not self.scroll_ready:
                self.scroll, self.scroll_ready = target, True
            self.scroll += (target - self.scroll) * (1.0 - math.exp(-dt * 9.0))
            base_row = int(round(cy - self.scroll))   # ONE rounding for the whole block -> lines move rigidly
            kf = 1.0 - math.exp(-dt * 9.0)
            for i in range(max(0, ci - 14), min(len(ly.lines), ci + 15)):
                ln, rows = ly.lines[i], rows_per[i]
                ry0 = base_row + ys[i]
                if ry0 + len(rows) <= top or ry0 >= bottom:
                    continue
                active = ln.b - 0.1 <= t < ln.e + 0.10
                tgt = 1.0 if active else max(0.14, math.exp(-0.55 * abs(i - cur)) * (0.8 if i < cur else 1.0))
                f = self.focus.get(i, tgt)
                f += (tgt - f) * kf
                self.focus[i] = f
                align = ly.align(ln, self.cfg.align)
                for ri, row in enumerate(rows):
                    y = ry0 + ri
                    if y < top or y >= bottom or not row.cells:
                        continue
                    dist = abs(y - cy) / (stage_h / 2.0)
                    edge = 1.0 - 0.85 * clamp((dist - 0.35) / 0.65) ** 1.5
                    if align == "right":
                        x0 = lx0 + lw - row.w
                    elif align == "center":
                        x0 = lx0 + (lw - row.w) // 2
                    else:
                        x0 = lx0
                    head, act = row_state(row, t)
                    items.append((y, x0, row, f * edge, head, act))

        # light: bloom on the sung syllable + a faint strip behind the part already sung (style / colour / size are options)
        gs = GLOW_STYLES[self.gstyle]
        if R is not None and gs["gain"] > 0:
            ga, gb2 = glow_colors(pal, self.gcolor)
            rx, ry, k_bloom, k_core, k_strip = gs["cell"]
            pulse = 1.0 + gs["pulse"] * math.sin(now * 5.0)
            sz = self.gsize
            for (y, x0, row, foc, head, act) in items:
                if act < 0.03 or foc < 0.3:
                    continue
                a_ = act * foc * glow * gs["gain"] * pulse * (1.0 + 0.9 * self.pulse)
                hx, cyy = x0 + head, y + 0.5
                splat(R, G, B, W, H, hx - 1.0, cyy, rx * sz, ry * max(1.0, sz * 0.8), mix(ga, gb2, 0.5 if gs["aurora"] else 0.0), k_bloom * a_)
                splat(R, G, B, W, H, hx - 1.0, cyy, 4.0 * sz, 1.1, WHITE, k_core * a_)
                if head > 3 and k_strip > 0:
                    splat(R, G, B, W, H, x0 + head * 0.5, cyy, head * 0.5 + 5.0, 1.5, gb2 if gs["aurora"] else ga, k_strip * a_)
        cgeo = self.cover_geom(W, H) if self.view == "cover" else None
        if cgeo and R is not None:                       # big-cover view: halo behind the centred cover
            splat(R, G, B, W, H, cgeo[2] + cgeo[0] / 2.0, cgeo[3] + cgeo[1] / 2.0, cgeo[0] * 0.8, cgeo[1] * 0.9,
                  mix(pal.a, pal.b, 0.35), 0.20 * glow * (0.88 + 0.12 * math.sin(now * 1.1)))
        if wide and R is not None and self.view != "cover":
            pulse = 0.88 + 0.12 * math.sin(now * 1.1)
            splat(R, G, B, W, H, art_x + AW / 2.0, art_y + AH / 2.0, AW * 0.9, AH * 0.9,
                  mix(pal.a, pal.b, 0.35), 0.16 * glow * pulse)

        style = self.eff_style()
        kin = style in ("kinetic", "word", "immersive", "slice", "caption", "vintage") and self.view == "lyrics"
        if style == "vintage" and kin:
            scr.cur = self.vintage_base(W, H)[:]
        elif self.imm_bg_a > 0.5:                              # immersive background: glossy objects + sparkles (any lyric style)
            self.candy.compose(scr, W, H, now, pulse)
        elif self.moon_on:
            scr.cur = self.moon_bg(W, H, int(round(self.pulse * 5)))[:]
        elif self.bgm is not None:                          # image / GIF / video background (normal AND low-end mode)
            lev = min(2, int(self.pulse * 2.6)) if bool(getattr(self.cfg, "bg_beat", True)) else 0
            scr.cur = self.bgm.cells(W, H, self.bgm.idx(now), lev, float((self.bg_spec or {}).get("dim", 0.42)))[:]
            for (y, x0, row, foc, head, act) in items:      # keep the line being read legible on busy pictures
                for xx in range(max(0, x0 - 1), min(W, x0 + row.w + 1)):
                    c = scr.cur[y * W + xx]
                    scr.cur[y * W + xx] = (c[0], c[1], ((c[2] >> 1) & 0x7F7F7F), c[3])
        elif R is None:
            scr.cur = self.flat_cells[:]
            if low:       # cheapest possible "glow": tint the background of the line being sung
                tint = pk(mix(pal.deep, pal.a, 0.16)) & 0xFCFCFC
                for (y, x0, row, foc, head, act) in items:
                    if act > 0.05 and foc > 0.6:
                        for xx in range(max(0, x0 - 1), min(W, x0 + row.w + 1)):
                            c = scr.cur[y * W + xx]
                            scr.cur[y * W + xx] = (c[0], c[1], tint, c[3])
        else:
            scr.cur = [(" ", 0, ((int(r) & 252) << 16) | ((int(g) & 252) << 8) | (int(b) & 252), 0)
                       for r, g, b in zip(R, G, B)]

        for (y, x0, row, foc, head, act) in items:
            self.draw_row(row, x0, y, foc, head, act, t, pal, glow)

        if self.view == "cover":
            self.draw_cover_view(W, H, track, pal, cgeo)
        elif wide:
            self.draw_art(art_x, art_y, AW, AH)
            self.draw_info(track, art_x, art_y + AH + 2, AW, pal)
        else:
            self.draw_header(track, W, pal)
        if ly is None and self.view == "lyrics":
            self.draw_status(track, W, cy, lx0, lw, pal, now)
        if self.view == "pick":
            self.draw_browser(scr, lx0, top, lw, stage_h, pal)
            self.draw_thumbs_cells()
        if kin and ly is not None:
            {"immersive": self.draw_immersive, "slice": self.draw_slice, "caption": self.draw_caption, "vintage": self.draw_vintage}.get(
                style, self.draw_kinetic)(W, H, ly, t, pal, now)
        self.apply_shake(W, H)
        self.draw_buttons(scr, W, H, pal)
        self.draw_footer(track, t_pos, ly, W, H, pal)
        self.overlay(scr, W, H, pal, track, playing)
        return ("\x1b[?2026h" + scr.flush() + "\x1b[0m\x1b[?2026l").encode("utf-8", "replace")

    # ---- the four new lyric styles (cell renderer) ------------------------------------------------------------------------------------
    PASTEL = ((255, 140, 200), (110, 228, 205), (145, 172, 255), (250, 215, 80), (250, 105, 105), (185, 145, 255))

    def _words_of(self, ln):
        words, cur = [], []
        for c in ln.cells:
            if c.ch == " ":
                if cur:
                    words.append(cur)
                cur = []
            else:
                cur.append(c)
        if cur:
            words.append(cur)
        return words

    def _text_of(self, ln) -> str:
        return "".join(c.ch for c in ln.cells)

    def _wrap_words(self, words, maxw, sp):
        lines, row, rw = [], [], 0
        for wd in words:
            ww = sum(c.w for c in wd) * sp
            if row and rw + ww + 2 * sp > maxw:
                lines.append(row)
                row, rw = [], 0
            row.append(wd)
            rw += ww + 2 * sp
        if row:
            lines.append(row)
        return lines

    def _grow(self, W, H, pal, te, grow, y0, nlines, behind: bool):
        """the big 'you' (and other dynamic words): block letters BEHIND the lyrics (default), above them, or off. As big as the screen allows,
        no loudness scaling unless grow_db_scale is on; grow_size / grow_opacity / grow_anim / grow_db_label are options."""
        cfg, scr, fx = self.cfg, self.scr, self.imm
        mode = str(getattr(cfg, "grow_mode", "behind")).lower()
        if grow is None or mode == "off" or (mode == "behind") != behind:
            return
        wd, x, y, wl = grow
        age, end = te - wd[0].b, wd[-1].e
        rem = max(end, wd[0].b + 1.2) + 0.4 - te
        if age < 0 or rem <= 0:
            return
        text = "".join(c.ch for c in wd).upper().replace("’", "'")
        n = max(1, len(text))
        room = (H - 6) if behind else max(1, y0 - 4)
        auto = max(1, min((W - 2) // (4 * n - 1), (room * 2) // 5))
        opt = str(getattr(cfg, "grow_size", "auto")).lower()
        try:
            size = auto if opt == "auto" else max(1, min(int(float(opt)), auto))
        except ValueError:
            size = auto
        db = None
        if bool(getattr(cfg, "grow_db_scale", False)):                           # optional: the loudness decides how much of the room it takes
            en = self.energy if (self.beat.enabled and self.energy > 0.005) else 0.12
            db = 20.0 * math.log10(max(en, 1e-3))
            floor = float(getattr(cfg, "grow_db_floor", -30.0))
            fx.gscale += (clamp(1.0 + (db - floor) / 10.0, 1.0, 3.0) - fx.gscale) * 0.3
            size = max(1, int(round(auto * clamp(fx.gscale / 3.0, 0.34, 1.0))))
        if bool(getattr(cfg, "grow_anim", True)):                                 # "you" grows into YOU
            k = clamp(age / 0.4)
            size = max(1, int(round(size * (0.2 + 0.8 * k * k * (3 - 2 * k)))))
        bw_, bh_ = big_word_size(text, size)
        if bw_ > W - 2 or bh_ > room:
            return
        opacity = clamp(float(getattr(cfg, "grow_opacity", 0.5)), 0.05, 1.0) * clamp(rem / 0.3) * clamp(age / 0.1 + 0.3)
        bx = max(1, (W - bw_) // 2)
        if behind:
            by = max(1, min(H - bh_ - 3, y0 + (nlines * 3) // 2 - 1 - bh_ // 2))   # centred on the lyric block
        else:
            by = max(2, y0 - 2 - bh_)
        col = mix(mix(pal.a, WHITE, 0.55), self.tint_color(), 0.5 * self.pulse)
        draw_big_word(scr, text, bx, by, size, size, col, opacity)
        if db is not None and bool(getattr(cfg, "grow_db_label", False)):
            lab = f"{db:+.0f} dB  x{fx.gscale:.1f}"
            scr.text(bx + max(0, (bw_ - len(lab)) // 2), max(1, by - 1), lab, pk((150, 140, 185)), 0)

    def draw_immersive(self, W, H, ly, t, pal, now):
        """centred phrase; every meaningful word sets off an effect when it is SUNG (rewind and it fires again). 'you' grows into a block-letter
        YOU scaled by the loudness (dB). Layout is per WORD (never per letter), so words always stay intact on one row."""
        scr, fx = self.scr, self.imm
        fx.mask = set()
        fx.corner_on, fx.corner_strength = bool(getattr(self.cfg, "corners", True)), float(getattr(self.cfg, "corner_strength", 1.0))
        cur = ly.current(t)
        ln = ly.lines[max(cur, 0)]
        te = t - 0.15 if self.stutter else t
        prev = getattr(self, "imm_prev_t", None)
        self.imm_prev_t = te
        if prev is not None and (te < prev - 0.25 or te > prev + 1.5):          # rewound / seeked: everything is armed again
            fx.reset()
        fx.step(now)
        fx.apply_bg(scr, now, W, H)
        if ln.kind != "line":
            n = int(clamp((t - ln.b) / max(ln.e - ln.b, 0.1)) * 3.99)
            txt = "   ".join("●" if i <= n else "○" for i in range(3))
            scr.text((W - strw(txt)) // 2, H // 2 - 1, txt, pk(pal.a), 1)
            fx.draw(scr, now, W, H)
            return
        words = self._words_of(ln)
        maxw = max(10, W - 10)
        sp = 2 if sum(sum(c.w for c in w) * 2 + 4 for w in words) <= maxw * 2 else 1
        lines = self._wrap_words(words, maxw, sp)
        y0 = max(3, (H - len(lines) * 3) // 2)
        tick = int(now * 11)
        extra = self.ui.get("word_fx", {})
        rule_fx = (self.rule or {}).get("effect")
        wid = lambda wd: sum(c.w for c in wd) * sp
        place, wi = [], 0
        for li, ws in enumerate(lines):
            shown = [wd for wd in ws if te >= wd[0].b - 0.03]
            if shown:
                tot = sum(wid(wd) for wd in shown) + 2 * sp * (len(shown) - 1)
                lx = x = max(1, (W - tot) // 2)
                for wd in shown:
                    place.append((wd, x, y0 + li * 3, wid(wd), wi + ws.index(wd), tot, lx, len(ws)))
                    x += wid(wd) + 2 * sp
            wi += len(ws)
        grow = None
        for wd, x, y, wl, idx, tot, lx, nw in place:                              # 1) trigger effects (armed per word; replays after a rewind)
            cat = rule_fx or fx_category("".join(c.ch for c in wd), extra)
            key = (ln.b, idx)
            if key not in fx.seen:
                fx.seen.add(key)
                if len(fx.seen) > 400:
                    fx.seen.clear()
                if cat and cat != "grow" and te - wd[0].b < 0.7:
                    fx.trigger(cat, x, y, wl, now, W, H, self.guard)
                    if fx.want_shake:
                        fx.want_shake, self.fxshake_t, self.shake_dir = False, now, (random.choice((-1, 1)), random.choice((-1, 0, 1)))
            if cat == "grow":
                grow = (wd, x, y, wl)
        self._grow(W, H, pal, te, grow, y0, len(lines), True)                       # the big YOU sits BEHIND the lyrics
        for wd, x, y, wl, idx, tot, lx, nw in place:                              # 2) the words (position offsets are per WORD)
            txt = "".join(c.ch for c in wd)
            cat = fx_category(txt, extra)
            base = FX_COLOR.get(cat) if cat else None
            hw = ((idx * 7 + tick * 13) * 2654435761) & 0xFFFF
            frac = (x + wl / 2 - lx) / max(1, tot)
            arc = -int(round(1.0 * (1 - (2 * frac - 1) ** 2))) if nw >= 3 else 0
            wdy = wdx = 0
            if cat == "fire":
                wdy = -1 if hw % 3 == 0 else 0
            elif cat == "water":
                wdy = int(round(math.sin(now * 3 + idx)))
            elif cat in ("dance", "laugh"):
                wdy = -int(abs(math.sin(now * 8 + idx)) * 2)
            elif cat == "dream":
                wdy = int(round(math.sin(now * 1.5 + idx)))
            elif cat == "sad":
                wdy = 1
            elif cat == "shake":
                wdx = 1 if tick % 2 else -1
            elif cat == "ice":
                wdx = 1 if (tick + idx) % 9 == 0 else 0
            yy, xx = y + arc + wdy, x + wdx
            age = te - wd[0].b
            for k in range(-1, wl + 1):                                           # clean strip under the word (art shows around it, never between letters)
                gx = xx + k
                if 0 <= gx < W and 0 <= yy < H:
                    c0 = scr.cur[yy * W + gx]
                    scr.cur[yy * W + gx] = (" ", 0, (c0[1] & 0xFCFCFC) if c0[0] == "█" else c0[2], 0)    # on top of block letters: dim block as the bg
                    fx.mask.add((gx, yy))
            for i, c in enumerate(wd):
                f = fill_of(c, te)
                col = (255, 255, 255) if f >= 1 else mix(pal.a, WHITE, 0.6 + 0.4 * f)
                if base:
                    col = base if f >= 1 else mix(base, WHITE, 0.5)
                    if cat == "fire":
                        col = mix((255, 60, 20), (255, 215, 70), (((i * 31 + hw) & 0xFF) / 255.0))
                    elif cat == "water":
                        col = mix((60, 150, 255), (170, 235, 255), (math.sin(now * 3 + i) + 1) / 2)
                    elif cat == "gold":
                        col = mix((255, 190, 40), (255, 245, 170), (math.sin(now * 4 + i * 0.6) + 1) / 2)
                    elif cat == "rainbow":
                        col = hsv((now * 0.5 + i * 0.12) % 1.0)
                    elif cat == "danger":
                        col = (255, 70, 70) if int(now * 4) % 2 else (255, 230, 230)
                    elif cat == "food":
                        col = (255, 140, 190) if i % 2 else (255, 225, 90)
                    elif cat == "magic":
                        col = mix((200, 120, 255), (255, 170, 240), (math.sin(now * 5 + i) + 1) / 2)
                    elif cat == "sad":
                        col = mix(col, (50, 55, 90), 0.35)
                    elif cat == "glitch":
                        col = (80, 255, 140) if (tick + i) % 4 else (255, 255, 255)
                dxl = 1 if (cat == "water" and math.sin(now * 5 + i * 0.9) > 0.3) else 0
                chh = c.ch if (cat == "grow" and age < 0.15) else c.ch.upper()       # "you" … then YOU
                scr.put(xx + dxl, yy, chh, pk(col), 1)
                xx += c.w * sp
            if cat == "glitch" and "glitch" in fx.active:                         # duplicated red / cyan echo of the word
                for dy, gc in ((-1, (255, 50, 80)), (1, (40, 235, 255))):
                    for i, c in enumerate(wd):
                        gx, gy = x + i * sp * c.w, yy + dy
                        if 0 <= gx < W and 0 <= gy < H and scr.cur[gy * W + gx][0] in (" ", "▀"):
                            scr.put(gx, gy, c.ch.upper(), pk(mix(gc, (8, 6, 18), 0.4)), 0)
        self._grow(W, H, pal, te, grow, y0, len(lines), False)                      # (grow = above: over the phrase instead of behind it)
        fx.draw(scr, now, W, H)

    def draw_slice(self, W, H, ly, t, pal, now):
        """glossy lyric-video typography: stacked / tilted / arced / tiled, gold-to-orange letters, sparkles"""
        scr = self.scr
        cur = ly.current(t)
        ln = ly.lines[max(cur, 0)]
        if ln.kind != "line":
            return
        te = t - 0.15 if self.stutter else t
        words = [w for w in self._words_of(ln) if te >= w[0].b - 0.03]
        if not words:
            return
        text = self._text_of(ln)
        v = 1 if "shotgun" in text.lower() else int(hashlib.md5(text.encode()).hexdigest(), 16) % 4
        if len(self._words_of(ln)) <= 2 and v != 1:
            v = 3
        up = lambda wd: "".join(c.ch for c in wd).upper()
        if v == 3:                                                           # tiled pattern: the word repeated, alternate rows mirrored
            w0 = up(words[-1])
            y0 = max(1, H // 2 - 3)
            for r in range(5):
                txt, hot = (w0 if r % 2 == 0 else w0[::-1]), r == 2
                tot = len(txt) * 2 + 3
                for k in range(-1, 2):
                    x = W // 2 + k * (tot + 4) - tot // 2
                    for i, chh in enumerate(txt):
                        g = mix((255, 235, 90), (255, 130, 40), r / 4.0) if hot else (70, 55, 95)
                        scr.put(x + i * 2, y0 + r, chh, pk(g), 1 if hot else 0)
        else:
            groups = [words[i:i + 2] for i in range(0, len(words), 2)]
            y0 = max(1, (H - len(groups) * 2) // 2 - 1)
            for gi, grp in enumerate(groups):
                parts = [" ".join(ch for ch in up(wd)) for wd in grp]
                txt = "   ".join(parts)
                ofs, pos = [0] * len(txt), 0
                for part in parts:                                                  # arc = one offset per WORD, so words never split across rows
                    frac = (pos + len(part) / 2) / max(1, len(txt))
                    off = -int(round(1.0 * (1 - (2 * frac - 1) ** 2))) if (v == 2 and len(parts) > 1) else 0
                    for j in range(len(part)):
                        ofs[pos + j] = off
                    pos += len(part) + 3
                x = max(1, (W - strw(txt)) // 2 - (6 if v == 1 else 0) + (gi * 7 if v == 1 else 0))     # tilted: each row steps right
                for i, chh in enumerate(txt):
                    if chh == " ":
                        continue
                    yy = y0 + gi * 2 + ofs[i]
                    g = mix((255, 240, 110), (255, 140, 40), (i % 9) / 8.0) if gi % 2 == 0 else (255, 255, 255)
                    scr.put(x + i, yy, chh, pk(g), 1)
        r = random.Random(int(now * 4))
        for _ in range(5):                                                    # sparkles
            sx, sy = r.randrange(2, W - 2), r.randrange(1, H - 2)
            if scr.cur[sy * W + sx][0] in (" ", "▀"):
                scr.put(sx, sy, r.choice("✦✧+"), pk((255, 255, 255)), 1)

    def draw_caption(self, W, H, ly, t, pal, now):
        """a caption box (default: bottom centre). Placement / colours / width come from [caption] in an addon; reveal = line | word"""
        scr = self.scr
        cfg = self.ui.get("caption", {})
        cur = ly.current(t)
        ln = ly.lines[max(cur, 0)]
        if ln.kind != "line" or not (ln.b - 0.05 <= t <= ln.e + 0.6):
            return
        words = self._words_of(ln)
        if str(cfg.get("reveal", "line")) == "word":
            words = [w for w in words if t >= w[0].b - 0.03]
        if not words:
            return
        text = " ".join("".join(c.ch for c in w) for w in words)
        text = text.upper() if cfg.get("uppercase", False) else text
        pct = lambda v, tot, d: int(float(str(v).rstrip("%")) / 100.0 * tot) if str(v).endswith("%") else (int(v) if v is not None else d)
        maxw = max(8, min(W - 4, pct(cfg.get("max_width", "62%"), W, int(W * 0.62))))
        lines, cur_l = [], ""
        for wd in text.split(" "):
            if cur_l and strw(cur_l) + 1 + strw(wd) > maxw:
                lines.append(cur_l)
                cur_l = wd
            else:
                cur_l = (cur_l + " " + wd).strip()
        if cur_l:
            lines.append(cur_l)
        pad = int(cfg.get("padding", 1))
        box = bool(cfg.get("box", True))
        bw = max(strw(l) for l in lines) + 2 * pad + 2
        bh = len(lines) + (2 if box else 0)
        pos = str(cfg.get("position", "bottom"))
        if "x" in cfg or "y" in cfg:
            x0, y0 = pct(cfg.get("x", "50%"), W, W // 2) - bw // 2, pct(cfg.get("y", "85%"), H, H - 6)
        else:
            y0 = {"top": 3, "middle": (H - bh) // 2, "center": (H - bh) // 2}.get(pos, H - bh - 4)
            x0 = {"left": 2, "right": W - bw - 2}.get(str(cfg.get("align", "center")), (W - bw) // 2)
        fg = _hexcol(cfg.get("fg", "#ffffff"), (255, 255, 255))
        bgc = _hexcol(cfg.get("bg", "#000000"), (0, 0, 0))
        if box:
            for yy in range(y0, y0 + bh):
                for xx in range(x0, x0 + bw):
                    if 0 <= xx < W and 0 <= yy < H:
                        scr.put(xx, yy, " ", pk(fg), 0, pk(bgc) & 0xFCFCFC)
        for i, l in enumerate(lines):
            scr.text(x0 + (bw - strw(l)) // 2, y0 + (1 if box else 0) + i, l, pk(fg), 1)

    # ---- vintage: pastel Y2K collage (scattered words on white / pixel speech bubbles over a pastel sky scene)
    def vintage_base(self, W: int, H: int) -> list:
        cache = self.__dict__.setdefault("_vint", {})
        got = cache.get((W, H))
        if got is not None:
            return got
        PH2 = H * 2
        px = [[None] * W for _ in range(PH2)]
        r = random.Random(5)
        for y in range(PH2):
            f = y / max(1, PH2 - 1)
            for x in range(W):
                px[y][x] = mix((105, 160, 255), (175, 210, 255), f)
        for _ in range(9):                                                     # clouds
            cx, cy = r.uniform(0, W), r.uniform(0, PH2 * 0.5)
            for _b in range(5):
                bx, by, br = cx + r.uniform(-W * 0.07, W * 0.07), cy + r.uniform(-2, 2), r.uniform(W * 0.03, W * 0.06)
                for y in range(int(by - br), int(by + br) + 1):
                    for x in range(int(bx - br * 1.7), int(bx + br * 1.7) + 1):
                        if 0 <= x < W and 0 <= y < PH2 and ((x - bx) / (br * 1.7)) ** 2 + ((y - by) / br) ** 2 <= 1.0:
                            px[y][x] = mix(px[y][x], (255, 255, 255), 0.92)
        ground = int(PH2 * 0.84)
        x = 0
        while x < W * 0.55:                                                    # pink skyline
            bw = r.randint(2, 5)
            bh = r.randint(int(PH2 * 0.12), int(PH2 * 0.34))
            for xx in range(x, min(W, x + bw)):
                for y in range(ground - bh, ground):
                    px[y][xx] = (255, 120, 195) if (xx + y) % 5 else (255, 180, 225)
            x += bw + r.randint(0, 1)
        for y in range(ground, PH2):
            for x in range(W):
                px[y][x] = (255, 228, 70) if (x + y) % 7 else (255, 205, 60)
        fx0, fy0, fr = int(W * 0.8), int(PH2 * 0.42), max(4, int(W * 0.075))                 # a generic hooded silhouette, purple duotone
        for y in range(PH2):
            for x in range(W):
                if ((x - fx0) / (fr * 1.45)) ** 2 + ((y - fy0) / (fr * 1.6)) ** 2 <= 1.0:
                    px[y][x] = (150, 110, 255)
                if ((x - fx0) / (fr * 0.95)) ** 2 + ((y - fy0 - fr * 0.1) / (fr * 1.15)) ** 2 <= 1.0:
                    px[y][x] = (205, 180, 255)
                if y > fy0 + fr * 1.3 and ((x - fx0) / (fr * 3.0)) ** 2 + ((y - fy0 - fr * 3.8) / (fr * 2.6)) ** 2 <= 1.0:
                    px[y][x] = (165, 125, 255)
        got = []
        for y in range(H):
            for x in range(W):
                got.append(("▀", pk(px[2 * y][x]) & 0xFCFCFC, pk(px[2 * y + 1][x]) & 0xFCFCFC, 0))
        if len(cache) > 6:
            cache.clear()
        cache[(W, H)] = got
        return got

    def draw_vintage(self, W, H, ly, t, pal, now):
        scr = self.scr
        cur = ly.current(t)
        ln = ly.lines[max(cur, 0)]
        te = t - 0.1
        if ln.kind != "line":
            return
        words = self._words_of(ln)
        if len(words) >= 4:                                                      # speech-bubble caption over the pastel scene
            scr.cur = self.vintage_base(W, H)[:]
            for i, (bx, by) in enumerate(((0.12, 0.18), (0.45, 0.10), (0.62, 0.28))):          # drifting hot-air balloons
                x = int(((bx + now * 0.012 * (i + 1)) % 1.1) * W)
                y = int(by * H + math.sin(now * 0.8 + i) * 1.2)
                for dx, dy, chh, c in ((0, 0, "●", (250, 90, 90) if i % 2 == 0 else (255, 255, 255)), (0, 1, "▼", (250, 90, 90)), (0, 2, "▯", (150, 110, 70))):
                    if 0 <= x + dx < W and 0 <= y + dy < H:
                        scr.put(x + dx, y + dy, chh, pk(c), 1)
            txt = " ".join("".join(c.ch for c in w) for w in words if te >= w[0].b - 0.03).upper()
            if not txt:
                return
            maxw = max(14, min(W // 2, 38))
            rows, cur_l = [], ""
            for wd in txt.split(" "):
                if cur_l and len(cur_l) + 1 + len(wd) > maxw:
                    rows.append(cur_l)
                    cur_l = wd
                else:
                    cur_l = (cur_l + " " + wd).strip()
            if cur_l:
                rows.append(cur_l)
            bw, bh = max(len(r_) for r_ in rows) + 4, len(rows) + 2
            x0, y0 = max(1, int(W * 0.52) - bw // 2), max(2, H - bh - 5)
            for yy in range(y0, y0 + bh):                                       # white bubble, black pixel border, clipped corners
                for xx in range(x0, x0 + bw):
                    edge = yy in (y0, y0 + bh - 1) or xx in (x0, x0 + bw - 1)
                    if edge and yy in (y0, y0 + bh - 1) and xx in (x0, x0 + bw - 1):
                        continue
                    cc = (0, 0, 0) if edge else (255, 255, 255)
                    scr.put(xx, yy, " ", pk(cc), 0, pk(cc) & 0xFCFCFC)
            for i, r_ in enumerate(rows):
                scr.text(x0 + 2, y0 + 1 + i, r_, pk((0, 0, 0)), 1)
            for k, chh in enumerate("◥█"):                                       # the little tail
                scr.put(x0 + bw - 4 + k, y0 + bh, chh, pk((0, 0, 0)), 0)
            return
        cream = pk((252, 249, 255)) & 0xFCFCFC                                  # scattered pastel words on white
        scr.cur = [(" ", 0, cream, 0)] * (W * H)
        rng = random.Random(int(hashlib.md5(self._text_of(ln).encode()).hexdigest()[:8], 16))
        slots = []
        for wi, wd in enumerate([w for w in words if te >= w[0].b - 0.03]):
            txt = "".join(c.ch for c in wd)
            big = len(txt) <= 5                                                 # short words get big, spaced, bold letters
            if big and rng.random() < 0.6:
                txt = txt.upper()
            step = 2 if big else 1
            wlen = len(txt) * step
            for _try in range(12):                                              # find a free spot so words never overlap
                x = rng.randint(2, max(3, W - wlen - 3))
                y = rng.randint(3, max(4, H - 7))
                if all(abs(y - sy) > 1 or x + wlen + 1 < sx or sx + sl + 1 < x for sx, sy, sl in slots):
                    break
            slots.append((x, y, wlen))
            slope = rng.choice((-0.25, 0.0, 0.0, 0.25))
            col = tuple(int(v * 0.86) for v in self.PASTEL[(wi + rng.randint(0, 5)) % len(self.PASTEL)])
            age = clamp((te - wd[0].b) / 0.18)                                  # pops in
            for i, ch in enumerate(txt):
                cx, cy = x + i * step, y + int(round(i * slope))
                if big:
                    scr.put(cx + 1, cy + 1, "▀" if ch != " " else " ", pk(mix((252, 249, 255), mix(col, (215, 205, 235), 0.6), age)), 0)   # soft drop shadow
                scr.put(cx, cy, ch, pk(mix((252, 249, 255), col, age)), 1)

    # ---- kinetic lyric style: ONE phrase at a time, huge spaced capitals, words pop in as they are sung, comic starbursts in the corners
    def draw_kinetic(self, W, H, ly, t, pal, now):
        scr = self.scr
        cur = ly.current(t)
        ln = ly.lines[max(cur, 0)]
        if ln.kind != "line":                                      # instrumental gap: three beating dots
            n = int(clamp((t - ln.b) / max(ln.e - ln.b, 0.1)) * 3.99)
            txt = "   ".join("●" if i <= n else "○" for i in range(3))
            scr.text((W - strw(txt)) // 2, H // 2 - 1, txt, pk(pal.a), 1)
            return
        gk = self.k if (self.cyber_on and bool(getattr(self.cfg, "cyber_echo", True))) else 0.0
        te = t - 0.15 if self.stutter else t
        words, curw = [], []
        for c in ln.cells:
            if c.ch == " ":
                if curw:
                    words.append(curw)
                curw = []
            else:
                curw.append(c)
        if curw:
            words.append(curw)
        if self.eff_style() == "word":                             # ONE word at a time: just the word being sung
            started = [w for w in words if te >= w[0].b - 0.03]
            words = [started[-1]] if started else []
        maxw = max(10, W - 8)
        sp = 3 if gk > 0.04 else 2                                 # letter spacing (wider when echoing, so copies never touch)
        wlen = lambda wd: sum(c.w for c in wd) * sp
        spaced = sum(wlen(w) + 4 for w in words) <= maxw * 2
        sp = sp if spaced else 1
        lines, row, rw = [], [], 0
        for wd in words:
            ww = wlen(wd) if spaced else sum(c.w for c in wd)
            if row and rw + ww + 4 > maxw:
                lines.append(row)
                row, rw = [], 0
            row.append(wd)
            rw += ww + 4
        if row:
            lines.append(row)
        y0 = max(1, (H - len(lines) * 3) // 2 - 1)
        for li, ws in enumerate(lines):
            shown = [wd for wd in ws if te >= wd[0].b - 0.03]                      # typewriter: a word exists once it starts
            if not shown:
                continue
            wid = lambda wd: (wlen(wd) if spaced else sum(c.w for c in wd))
            tot = sum(wid(wd) for wd in shown) + 4 * (len(shown) - 1)
            x = max(0, (W - tot) // 2) + (1 if (self.stutter and self.gseed & 2) else 0)
            y = y0 + li * 3
            for yy in range(y - 1, y + 2):                                        # dark band so the text reads on any picture
                for xx in range(max(0, x - 3), min(W, x + tot + 3)):
                    if 0 <= yy < scr.H:
                        c0 = scr.cur[yy * W + xx]
                        scr.cur[yy * W + xx] = (c0[0], c0[1], (c0[2] >> 2) & 0x3F3F3F, c0[3])
            for wd in shown:
                for c in wd:
                    f = fill_of(c, te)
                    ch = c.ch.upper()
                    col = (255, 255, 255) if f >= 1 else mix(pal.a, WHITE, 0.55 + 0.4 * f)
                    if 0 < f < 1:
                        col = mix(col, (255, 60, 150), 0.5)
                    if gk > 0.04:                                                  # whole-line echo above (red) / below (cyan)
                        scr.put(x, y - 1, ch, pk((150, 30, 55)), 0)
                        if gk > 0.5:
                            scr.put(x, y + 1, ch, pk((20, 120, 140)), 0)
                    scr.put(x, y, ch, pk(col), 1)
                    x += c.w * sp if spaced else c.w
                x += 4
        big = self.pulse > 0.45                                                    # comic starbursts pop on the beat
        for gx, gy, glyph, col in ((1, 0, "✸", (255, 60, 150)), (W - 3, 0, "✺", (40, 230, 255)), (1, H - 3, "✹", (40, 230, 255)), (W - 3, H - 3, "✷", (255, 60, 150))):
            scr.text(gx, gy, glyph, pk(col), 1)
            if big:
                scr.text(gx + (1 if gx < W // 2 else -1), gy, "✦", pk(col), 0)
                scr.text(gx, gy + (1 if gy < H // 2 else -1), "✦", pk(col), 0)

    # ---- cyberpsychosis helpers
    def moon_bg(self, W: int, H: int, level: int) -> list:
        """the moon + David & Lucy scene as half-block cells (6 beat levels, built lazily, cached)"""
        cache = self.__dict__.setdefault("_moon", {})
        key = (W, H, level, self.figures)
        got = cache.get(key)
        if got is None:
            if len(cache) > 30:
                cache.clear()
            art = moon_art(W * 2, H * 4, level, self.figures)
            base = Image.new("RGBA", art.size, (5, 6, 16, 255))
            fade = Image.new("L", (64, 1))
            fade.putdata([int(215 - 175 * x / 63) for x in range(64)])             # darker on the left, where the lyrics are
            dark = Image.new("RGBA", art.size, (0, 0, 0, 255))
            dark.putalpha(fade.resize(art.size))
            comp = Image.alpha_composite(Image.alpha_composite(base, art), dark).convert("RGB").resize((W, H * 2), Image.LANCZOS)
            px = comp.tobytes()
            got = []
            for y in range(H):
                for x in range(W):
                    i, j = ((2 * y) * W + x) * 3, ((2 * y + 1) * W + x) * 3
                    got.append(("▀", ((px[i] << 16) | (px[i + 1] << 8) | px[i + 2]) & 0xFCFCFC,
                                ((px[j] << 16) | (px[j + 1] << 8) | px[j + 2]) & 0xFCFCFC, 0))
            cache[key] = got
        return got

    def apply_shake(self, W: int, H: int):
        """screen shake on the beat: the whole picture jumps 1-2 cells and settles (rate-limited, never a strobe)"""
        a = self.shake_amp if self.cyber_on else 0.0
        a = max(a, 0.7 * math.exp(-(time.monotonic() - getattr(self, "fxshake_t", -9.0)) / 0.16))      # word effects (earthquake, crash…) shake too
        if a < 0.18:
            return
        mag = 2 if a > 0.55 else 1
        dx, dy = self.shake_dir[0] * mag, self.shake_dir[1]
        cur = self.scr.cur
        if dy:
            n = (dy % H) * W
            cur = cur[-n:] + cur[:-n] if n else cur
        if dx:
            d = dx % W
            cur = [c for y in range(H) for c in (cur[y * W:(y + 1) * W][-d:] + cur[y * W:(y + 1) * W][:-d])]
        self.scr.cur = cur

    def draw_thumbs_cells(self):
        """modern list in the cell renderer: real covers as half-block pixels (each cell = 1x2 pixels)"""
        cache = getattr(self, "_blocks", None)
        if cache is None or len(cache) > 400:
            cache = self._blocks = {}
        for url, x, y, cols, rows, kind, title in self.art_slots:
            im = self.thumbs.get(url, 24) if url else None
            if im is None:
                continue
            key = (id(im), cols, rows)
            px = cache.get(key)
            if px is None:
                px = cache[key] = im.convert("RGB").resize((cols, rows * 2), Image.LANCZOS).tobytes()
            for r in range(rows):
                for c in range(cols):
                    i, j = ((2 * r) * cols + c) * 3, ((2 * r + 1) * cols + c) * 3
                    self.scr.put(x + c, y + r, "▀", (px[i] << 16) | (px[i + 1] << 8) | px[i + 2], 0,
                                 (px[j] << 16) | (px[j + 1] << 8) | px[j + 2])

    def cover_geom(self, W, H):
        if self.fx.art is None or Image is None:
            return None
        aw = int(max(8, min(W - 8, (H - 9) * 2))) // 2 * 2
        return aw, aw // 2, (W - aw) // 2, max(1, (H - aw // 2 - 6) // 2)

    def draw_cover_view(self, W, H, track, pal, geo):
        ty = max(2, H // 2 - 3)
        if geo:
            aw, ah, ax, ay = geo
            self.draw_art(ax, ay, aw, ah)
            ty = ay + ah + 1
        if track:
            for i, (txt, col, at) in enumerate([(track.title, pk(WHITE), 1), (track.artist, pk(pal.a), 0),
                                                (track.album, pk(mix(pal.deep, pal.b, 0.6)), 2)]):
                if txt:
                    t2 = trunc(txt, W - 6)
                    self.scr.text(max(0, (W - strw(t2)) // 2), ty + i, t2, col, at)

    def draw_row(self, row, x0, y, foc, head, act, t, pal, glow):
        scr, deep = self.scr, pal.deep
        w = max(row.w, 1)
        gk = self.k if (self.cyber_on and bool(getattr(self.cfg, "cyber_echo", True))) else 0.0
        te = t - 0.15 if self.stutter else t                                        # stutter: the sweep jumps back a beat
        jit = (1 if (self.gseed & 2) else -1) if self.stutter else 0                # …and the line shudders sideways
        cb = self.col_before(pal, foc)
        ca0, ca1 = self.col_after(pal, foc, 0.0), self.col_after(pal, foc, 1.0)
        for c, x in zip(row.cells, row.xs):
            if c.ch == " ":
                continue
            f = fill_of(c, t)
            col = mix(cb, mix(ca0, ca1, x / w), f)
            dist = (x + c.w * 0.5) - head
            h = math.exp(-(dist / (3.0 if dist < 0 else 1.6)) ** 2) * act
            if h > 0.02:
                col = mix(col, WHITE, clamp(h * 0.9 * glow))
            at = 0
            if c.bg:
                col = mix(col, deep, 0.3)
                at |= 2
            if 0.0 < f < 1.0 or h > 0.6:
                at |= 1
            ch = c.ch
            xx = x0 + x + jit
            if gk > 0.04 and c.w == 1:                                              # echo: the line is DUPLICATED above (red) and below (cyan)
                for dy, thr, gc in ((-1, 0.04, (255, 50, 80)), (1, 0.5, (40, 235, 255))):
                    gy = y + dy
                    if gk > thr and 0 <= gy < scr.H and scr.cur[gy * scr.W + xx][0] in (" ", "▀") if 0 <= xx < scr.W else False:
                        scr.put(xx, gy, ch, pk(mix(gc, deep, 0.45 if dy < 0 else 0.55)), 0)
            scr.put(xx, y, ch, pk(col), at)
            if c.w == 2:
                scr.put(xx + 1, y, "", pk(col), at)

    def draw_art(self, x0, y0, aw, ah):
        img = self.fx.art
        key = (id(img), aw, ah)
        if key != self.art_key:
            self.art_grid, self.art_key = img.convert("RGB").resize((aw, ah * 2), Image.LANCZOS).tobytes(), key
        px = self.art_grid
        gk = self.k if self.cyber_on else 0.0
        shifts, blocks = {}, []
        if gk > 0.05:                                          # cyberpsychosis: slices slide sideways, colour channels split
            rng = random.Random(self.gseed * 104729)
            for r in range(2 * ah):
                if rng.random() < gk * 0.38:
                    m = max(1, int(aw * 0.2))
                    shifts[r] = rng.randint(-m, m)
        split = 1 if gk > 0.2 else 0

        def pix(c, pr):
            cc = (c - shifts.get(pr, 0)) % aw
            base = (pr * aw + cc) * 3
            rr = px[(pr * aw + (cc + split) % aw) * 3]
            bb = px[(pr * aw + (cc - split) % aw) * 3 + 2]
            v = (rr, px[base + 1], bb)
            for bx, by, bw, bc in blocks:
                if by == pr and bx <= c < bx + bw:
                    v = bc
            return (v[0] << 16) | (v[1] << 8) | v[2]

        for r in range(ah):
            for c in range(aw):
                self.scr.put(x0 + c, y0 + r, "▀", pix(c, 2 * r), 0, pix(c, 2 * r + 1))

    def draw_info(self, track, x, y, w, pal):
        if not track:
            return
        self.scr.text(x, y, trunc(track.title, w), pk(WHITE), 1)
        self.scr.text(x, y + 1, trunc(track.artist, w), pk(pal.a), 0)
        if track.album:
            self.scr.text(x, y + 2, trunc(track.album, w), pk(mix(pal.deep, pal.b, 0.55)), 2)

    def draw_header(self, track, W, pal):
        if not track:
            return
        x = self.scr.text(2, 0, "♪ ", pk(pal.b), 1)
        x = self.scr.text(x, 0, trunc(track.title, max(4, (W - 6) * 6 // 10)), pk(WHITE), 1)
        rest = W - 2 - x
        if track.artist and rest > 6:
            self.scr.text(x, 0, trunc("  " + track.artist, rest), pk(pal.a), 0)

    def draw_status(self, track, W, cy, lx0, lw, pal, now):
        if track is None:
            msg, sub = "waiting for music", self.fx.err or self.state.error or "play something in Spotify, Firefox, mpv…"
        elif self.fx.status == "loading":
            msg, sub = "fetching lyrics" + "." * (1 + int(now * 3) % 3), ""
        else:
            msg, sub = "no synced lyrics for this track", self.fx.err
        col = mix(pal.deep, mix(pal.a, WHITE, 0.4), 0.55 + 0.35 * math.sin(now * 2.2))
        self.scr.text(lx0 + max(0, (lw - strw(msg)) // 2), cy, msg, pk(col), 1)
        if sub:
            sub = trunc(sub, lw)
            self.scr.text(lx0 + max(0, (lw - strw(sub)) // 2), cy + 2, sub, pk(mix(pal.deep, pal.b, 0.5)), 2)

    def draw_footer(self, track, t_pos, ly, W, H, pal):
        if not track:
            return
        scr = self.scr
        total = track.duration or (ly.end + 2 if ly else None)
        y = H - 2
        tl = fmt_time(t_pos)
        scr.text(2, y, tl, pk(mix(pal.deep, pal.a, 0.8)), 0)
        if total:
            tr_ = fmt_time(total)
            scr.text(W - 2 - len(tr_), y, tr_, pk(mix(pal.deep, pal.a, 0.5)), 0)
            bx0, bx1 = 2 + len(tl) + 2, W - 2 - len(tr_) - 2
            n = bx1 - bx0
            if n > 6:
                hp = clamp(t_pos / total) * (n - 1)
                for i in range(n):
                    if i < hp:
                        scr.put(bx0 + i, y, "━", pk(mix(pal.a, pal.b, i / max(n - 1, 1))), 0)
                    elif abs(i - hp) < 1.0:
                        scr.put(bx0 + i, y, "●", pk(WHITE), 1)
                    else:
                        scr.put(bx0 + i, y, "─", pk(mix(pal.deep, pal.a, 0.22)), 0)


# =========================================================================== kitty renderer
#
# Everything the eye sees except the tiny hint/status line is a real image sent through the kitty graphics
# protocol (the same thing `kitten icat` speaks):
#   backdrop  animated blurred-cover + colour blobs, low-res, stretched smoothly by the GPU
#   cover     rounded artwork + shadow + glow, spring "pop" on play/pause, gentle float
#   lyrics    every wrapped line is its own anti-aliased RGBA image: per-syllable sweep, soft word glow,
#             depth blur, staggered spring scrolling (placement offsets only -> no re-upload while scrolling)
#   UI        title/artist and a progress bar
# Not available on Termux (no graphics protocol) -> the cell renderer above is used there.

CJK_RE = re.compile(r"[\u3040-\u30ff\u3400-\u9fff\uac00-\ud7af]")


def smooth(x: float) -> float:
    x = clamp(x)
    return x * x * (3.0 - 2.0 * x)


def win_px():
    try:
        r, c, xp, yp = struct.unpack("HHHH", fcntl.ioctl(sys.stdout.fileno(), termios.TIOCGWINSZ, b"\0" * 8))
        return r, c, xp, yp
    except Exception:
        return 0, 0, 0, 0


class Gfx:
    """Minimal kitty graphics protocol client. Image ids: 1 backdrop, 2 cover, 3 info, 4 progress, 1000+ lyric rows."""
    Z_BG, Z_COVER, Z_ANIM, Z_TEXT, Z_UI = -400, -300, -250, -200, -100

    def __init__(self):
        self.cw, self.ch = 9, 18
        self.placed: dict = {}
        self.off = (0, 0)                              # screen shake: added to every placement made with shake=True

    @staticmethod
    def _chunks(keys: str, payload: bytes) -> str:
        b64 = base64.standard_b64encode(payload).decode("ascii")
        out, i, n, first = [], 0, len(b64), True
        while True:
            chunk = b64[i:i + 4096]
            i += 4096
            more = 1 if i < n else 0
            k = f"{keys},m={more}" if first else f"m={more}"
            out.append(f"\x1b_G{k},q=2;{chunk}\x1b\\")
            first = False
            if not more:
                break
        return "".join(out)

    @staticmethod
    def _pk(iid: int, pid: int):
        return iid if pid == 1 else (iid, pid)

    def send(self, iid: int, arr, fmt: int, level: int = 1) -> str:
        """arr: uint8 (h, w, 3|4). fmt 24 = RGB, 32 = RGBA. Replaces any image with the same id."""
        h, w = arr.shape[:2]
        for k in [k for k in self.placed if k == iid or (isinstance(k, tuple) and k[0] == iid)]:
            self.placed.pop(k, None)
        return self._chunks(f"a=t,f={fmt},s={w},v={h},o=z,i={iid}", zlib.compress(arr.tobytes(), level))

    def place(self, iid: int, x: int, y: int, z: int, cols: int = 0, rows: int = 0, pid: int = 1, shake: bool = True) -> str:
        """pid lets ONE uploaded image be shown in several places (e.g. songs of one album share their cover)"""
        if shake:
            x, y = max(0, x + self.off[0]), max(0, y + self.off[1])
        col, X = divmod(int(x), self.cw)
        row, Y = divmod(int(y), self.ch)
        key = (col, X, row, Y, z, cols, rows)
        pk_ = self._pk(iid, pid)
        if self.placed.get(pk_) == key:
            return ""
        self.placed[pk_] = key
        extra = f",c={cols},r={rows}" if cols else ""
        return f"\x1b[{row + 1};{col + 1}H\x1b_Ga=p,i={iid},p={pid},X={X},Y={Y},z={z},C=1{extra},q=2\x1b\\"

    def unplace(self, iid: int, pid: int = 1) -> str:
        pk_ = self._pk(iid, pid)
        if pk_ in self.placed:
            del self.placed[pk_]
            return f"\x1b_Ga=d,d=i,i={iid},p={pid},q=2\x1b\\" if pid != 1 else f"\x1b_Ga=d,d=i,i={iid},q=2\x1b\\"
        return ""

    def delete(self, iid: int) -> str:
        for k in [k for k in self.placed if k == iid or (isinstance(k, tuple) and k[0] == iid)]:
            self.placed.pop(k, None)
        return f"\x1b_Ga=d,d=I,i={iid},q=2\x1b\\"

    def delete_all(self) -> str:
        self.placed.clear()
        return "\x1b_Ga=d,d=A,q=2\x1b\\"


# --------------------------------------------------------------------------- fonts

def _fc(query: str):
    try:
        r = subprocess.run(["fc-match", "-f", "%{family}|%{file}", query], capture_output=True, text=True, timeout=3)
        fam, _, path = r.stdout.partition("|")
        return fam.strip(), path.strip()
    except Exception:
        return "", ""


FALLBACK_FONTS = [
    "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/noto/NotoSans-Bold.ttf", "/usr/share/fonts/liberation/LiberationSans-Bold.ttf",
    "/data/data/com.termux/files/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
]


class Fonts:
    def __init__(self, pref: str | None = None):
        self.bold = self.regular = self.cjk = None
        fam0 = ""
        if pref and os.path.exists(pref):
            self.bold = pref
        else:
            cands = ([pref + ":bold"] if pref else []) + ["Inter:bold", "SF Pro Display:bold", "Noto Sans:bold",
                                                         "Cantarell:bold", "Roboto:bold", "sans-serif:bold"]
            for q in cands:
                fam, path = _fc(q)
                if path and os.path.exists(path) and (q.startswith("sans") or q.split(":")[0].lower() in fam.lower()):
                    self.bold, fam0 = path, fam
                    break
        if not self.bold:
            self.bold = next((p for p in FALLBACK_FONTS if os.path.exists(p)), None)
        if not self.bold:
            raise RuntimeError("no usable TrueType font found (install ttf-dejavu / noto-fonts / inter-font)")
        _, reg = _fc((fam0 or "sans-serif") + ":regular")
        self.regular = reg if reg and os.path.exists(reg) else self.bold
        _, cj = _fc("sans-serif:bold:lang=ja")
        self.cjk = cj if cj and os.path.exists(cj) else None
        self._cache: dict = {}

    def get(self, path: str, px: int):
        k = (path, px)
        f = self._cache.get(k)
        if f is None:
            f = self._cache[k] = ImageFont.truetype(path, px)
        return f

    def pick(self, text: str, px: int):
        return self.get(self.cjk if (self.cjk and CJK_RE.search(text)) else self.bold, px)


def fit_text(text: str, font, width: int) -> str:
    if font.getlength(text) <= width:
        return text
    while text and font.getlength(text + "…") > width:
        text = text[:-1]
    return text.rstrip() + "…"


# --------------------------------------------------------------------------- pixel rows

class PRow:
    pass


def make_prow(cells, fonts: Fonts, px: int, kind="text") -> PRow:
    r = PRow()
    r.cells, r.kind, r.cache, r.sig, r.iid = cells, kind, {}, None, None
    r.text = "".join(c.ch for c in cells)
    r.font = fonts.pick(r.text, px)
    r.asc, r.desc = r.font.getmetrics()
    if kind == "dots":
        r.rad = px * 0.15
        sp = px * 0.55
        r.centers = [r.rad, r.rad + sp, r.rad + 2 * sp]
        r.cidx = [0, 2, 4]
        r.w = 2 * sp + 2 * r.rad
        r.xs = []
    else:
        xs, acc = [0.0], ""
        for c in cells:
            acc += c.ch
            xs.append(r.font.getlength(acc))
        r.xs, r.w = xs, xs[-1]
        r.cidx = [k for k, c in enumerate(cells) if c.ch.strip()]
        r.centers = [(xs[k] + xs[k + 1]) / 2.0 for k in r.cidx]
    r.b = min((c.b for c in cells), default=0.0)
    r.e = max((c.e for c in cells), default=0.0)
    return r


def wrap_px(cells, fonts: Fonts, px: int, maxw: int):
    base = _wrap_px(cells, fonts, px, maxw)
    n = len(base)
    best = base
    for f in (0.92, 0.84, 0.76, 0.68):
        if n < 2 or _rowwidth(best[-1], fonts, px) >= 0.30 * maxw:
            break
        trial = _wrap_px(cells, fonts, px, int(maxw * f))
        if len(trial) != n:
            break
        best = trial
    return best


def _rowwidth(row, fonts: Fonts, px: int) -> float:
    txt = "".join(c.ch for c in row)
    return fonts.pick(txt, px).getlength(txt) if txt else 0.0


def _wrap_px(cells, fonts: Fonts, px: int, maxw: int):
    words, cur = [], []
    for c in cells:
        cur.append(c)
        if c.ch == " ":
            words.append(cur)
            cur = []
    if cur:
        words.append(cur)
    rows, row = [], []
    for w in words:
        trial = row + w
        txt = "".join(c.ch for c in trial).rstrip()
        if row and fonts.pick(txt, px).getlength(txt) > maxw:
            rows.append(row)
            row = list(w)
        else:
            row = trial
    if row:
        rows.append(row)
    out = []
    for r in rows:
        while r and r[-1].ch == " ":
            r = r[:-1]
        if r:
            out.append(r)
    return out or [[]]


def row_canvas(row: PRow, pad: int):
    return int(math.ceil(row.w)) + 2 * pad, row.asc + row.desc + 2 * pad


def row_mask(row: PRow, pad: int, lifts=None, breath: float = 1.0):
    """float32 (H, W) coverage of the row's glyphs (or dots)."""
    W, H = row_canvas(row, pad)
    if row.kind == "dots":
        ss = 3
        im = Image.new("L", (W * ss, H * ss), 0)
        d = ImageDraw.Draw(im)
        cyy = pad + (row.asc + row.desc) / 2.0
        rr = row.rad * breath
        for cx in row.centers:
            x, y = (cx + pad) * ss, cyy * ss
            d.ellipse([x - rr * ss, y - rr * ss, x + rr * ss, y + rr * ss], fill=255)
        im = im.resize((W, H), Image.LANCZOS)
    else:
        im = Image.new("L", (W, H), 0)
        d = ImageDraw.Draw(im)
        if lifts is None:
            d.text((pad, pad), row.text, font=row.font, fill=255)
        else:
            for k, c in enumerate(row.cells):
                if c.ch.strip():
                    d.text((pad + row.xs[k], pad + lifts.get(k, 0)), c.ch, font=row.font, fill=255)
    return np.asarray(im, dtype=np.float32) / 255.0


def blurred(m, sigma: float):
    if sigma <= 0.05:
        return m
    im = Image.fromarray((m * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(sigma))
    return np.asarray(im, dtype=np.float32) / 255.0


def render_static(row: PRow, pad: int, sigma: float, alpha: float, rgb):
    base = row.cache.get("m0")
    if base is None:
        base = row.cache["m0"] = row_mask(row, pad)
    if sigma > 0.05:
        k = ("b", sigma)
        m = row.cache.get(k)
        if m is None:
            if len([x for x in row.cache if x != "m0"]) > 5:
                row.cache = {"m0": base}
            m = row.cache[k] = blurred(base, sigma)
    else:
        m = base
    out = np.empty(m.shape + (4,), np.uint8)
    out[..., 0], out[..., 1], out[..., 2] = rgb
    out[..., 3] = np.clip(m * alpha * 255.0, 0, 255)
    out[out[..., 3] < 2] = 0
    return out


def render_active(row: PRow, t: float, pad: int, dim_alpha: float, lit_gain: float, dim_rgb, lit_rgb, gcols,
                  glow: float, lift: float, gsig: float, breath: float = 1.0, gstyle=None, now: float = 0.0, echo=None):
    """The Apple-Music moment: syllable sweep from dim to lit, soft glow on lit text, sung syllables float up."""
    fills = [fill_of(row.cells[k], t) for k in row.cidx]
    lifts = {}
    if row.kind != "dots":
        for k, f in zip(row.cidx, fills):
            if 0.0 < f < 1.0:
                lifts[k] = -lift * math.sin(math.pi * f)
    mask = row_mask(row, pad, lifts or None, breath)
    H, W = mask.shape
    cx = np.asarray(row.centers, np.float32) + pad
    fv = np.asarray(fills, np.float32) * lit_gain
    cov = np.interp(np.arange(W, dtype=np.float32), cx, fv).astype(np.float32) if len(cx) else np.zeros(W, np.float32)
    cov1 = cov[None, :]
    At = mask * (dim_alpha + (1.0 - dim_alpha) * cov1)
    gs = gstyle or GLOW_STYLES["soft"]
    gain = glow * gs["gain"] * (1.0 + gs["pulse"] * math.sin(now * 5.0))
    gb = 0.0
    if gain > 0.01:
        src = mask * cov1
        if gs["follow"] == "head":                         # only the syllable being sung glows
            lit = np.nonzero(cov > 0.5)[0]
            hx = float(lit[-1]) if len(lit) else 0.0
            src = src * np.exp(-((np.arange(W, dtype=np.float32) - hx) / (gsig * 3.2)) ** 2)[None, :]
        gb = blurred(src, max(0.6, gsig * gs["sigma"]))
        if gs["tight"] > 0:                                # neon: a hot tight core on top of the wide glow
            gb = gb * (1.0 - 0.5 * gs["tight"]) + blurred(src, max(0.8, gsig * 0.28)) * gs["tight"]
    Ag = np.clip(gb * gain * 1.25, 0.0, 0.85)
    Ct = dim_rgb[None, None, :] * (1.0 - cov[None, :, None]) + lit_rgb[None, None, :] * cov[None, :, None]
    if gs["aurora"]:                                       # glow colour drifts A -> B along the line
        xr = (np.arange(W, dtype=np.float32) / max(W - 1, 1))[None, :, None]
        Cg = gcols[0][None, None, :] + (gcols[1] - gcols[0])[None, None, :] * xr
    else:
        Cg = gcols[0][None, None, :]
    Wg = Ag * (1.0 - At)
    A = At + Wg
    C = (Ct * At[..., None] + Cg * Wg[..., None]) / np.maximum(A, 1e-4)[..., None]
    out = np.empty((H, W, 4), np.uint8)
    out[..., :3] = np.clip(C, 0, 255)
    out[..., 3] = np.clip(A * 255.0, 0, 255)
    out[out[..., 3] < 2] = 0          # transparent pixels: all zero -> compresses ~5x better
    if echo and echo[0] > 0.04:                                          # cyberpsychosis: duplicated red/cyan echo copies (+ double-strike on a stutter)
        out = echo_rgba(out, echo[0], echo[1])
    out = (out & 0xF8) | (out >> 5)   # 5-bit precision (255 stays 255): invisible on text/glow, much smaller on the wire
    return out


# --------------------------------------------------------------------------- backdrop (animated cover effect)

def render_kinetic(words: list, te: float, W: int, H: int, fpx: int, mode: str, pulse: float, k: float, stutter: bool, font_path: str):
    """Kinetic lyric card (the lyric-video look): huge capitals, words pop in as they are sung, OUTLINED until sung then FILLED,
    red/cyan echo on the active word, comic starbursts in the corners that pop on the beat. mode 'kinetic' = the phrase, 'word' = one word only.
    Returns an RGBA uint8 array (H, W, 4) or None when nothing has started yet."""
    from PIL import ImageChops
    started = [w for w in words if te >= w[0].b - 0.03]
    if not started:
        return None
    shown = [started[-1]] if mode == "word" else started
    font = ImageFont.truetype(font_path, fpx)
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gap = fpx * 0.32
    maxw = W * 0.88
    txt = lambda w: "".join(c.ch for c in w).upper()
    wl = lambda w: font.getlength(txt(w))
    lines, row, rw = [], [], 0.0
    for w in shown:
        ww = wl(w)
        if row and rw + gap + ww > maxw:
            lines.append(row)
            row, rw = [], 0.0
        row.append(w)
        rw += (gap if len(row) > 1 else 0) + ww
    if row:
        lines.append(row)
    lh = fpx * 1.04
    y = (H - len(lines) * lh) / 2 - fpx * 0.12
    sw = max(2, fpx // 26)
    for ln in lines:
        tw = sum(wl(w) for w in ln) + gap * (len(ln) - 1)
        x = (W - tw) / 2 + (fpx * 0.05 if stutter else 0)
        for w in ln:
            t0, t1 = w[0].b, max(w[-1].e, w[0].b + 0.05)
            frac = max(0.0, min(1.0, (te - t0) / (t1 - t0)))
            frac = frac * frac * (3 - 2 * frac)
            word = txt(w)
            full = Image.new("L", (W, H), 0)
            ImageDraw.Draw(full).text((x, y), word, font=font, fill=255)
            stroke = Image.new("L", (W, H), 0)
            ImageDraw.Draw(stroke).text((x, y), word, font=font, fill=255, stroke_width=sw, stroke_fill=255)
            ring = ImageChops.subtract(stroke, full)
            lit = full.copy()
            if frac < 1.0:                                           # fill sweeps across the word as it is sung
                clip = Image.new("L", (W, H), 0)
                ImageDraw.Draw(clip).rectangle([0, 0, int(x + wl(w) * frac), H], fill=255)
                lit = ImageChops.multiply(full, clip)
            active = frac < 1.0 or w is started[-1]
            if active and (k > 0.04 or mode == "word" or True):      # chromatic echo behind the active word
                dx = int(fpx * (0.035 + 0.05 * pulse) * (1 + 2 * k))
                for sgn, col in ((-1, (255, 45, 150)), (1, (40, 230, 255))):
                    g = ImageChops.offset(stroke, sgn * dx, 0)
                    layer = Image.new("RGBA", (W, H), col + (255,))
                    layer.putalpha(g.point(lambda v: int(v * (0.55 if k > 0.04 else 0.35))))
                    im = Image.alpha_composite(im, layer)
                    if k > 0.35:                                     # echo: a second, fainter duplicate
                        g2 = ImageChops.offset(stroke, sgn * dx * 2, int(fpx * 0.03 * sgn))
                        l2 = Image.new("RGBA", (W, H), col + (255,))
                        l2.putalpha(g2.point(lambda v: int(v * 0.22)))
                        im = Image.alpha_composite(im, l2)
            unlit = ImageChops.subtract(full, lit)
            parts = ((ring, (255, 255, 255), 235), (unlit, (255, 255, 255), 34), (lit, (255, 255, 255), 255))
            for m, col, al in parts:
                layer = Image.new("RGBA", (W, H), col + (255,))
                layer.putalpha(m.point(lambda v, al=al: int(v * al / 255)))
                im = Image.alpha_composite(im, layer)
            x += wl(w) + gap
        y += lh
    d = ImageDraw.Draw(im)                                           # comic starbursts, popping on the beat
    R = min(W, H) * (0.085 + 0.075 * pulse)
    for cx, cy, col in ((R * 0.9, R * 0.9, (255, 50, 150, 255)), (W - R * 0.9, R * 0.9, (40, 230, 255, 255)),
                        (R * 0.9, H - R * 0.9, (40, 230, 255, 255)), (W - R * 0.9, H - R * 0.9, (255, 50, 150, 255))):
        spike_star(d, cx, cy, R, 12, col)
        spike_star(d, cx, cy, R * 0.5, 12, (6, 6, 10, 255), 0.6)
    return np.asarray(im)


class Backdrop:
    def __init__(self):
        self.src = None
        self.shape = None

    def set_art(self, img):
        self.src = None
        if img is None or Image is None:
            return
        s = img.convert("RGB").resize((64, 64), Image.BILINEAR).filter(ImageFilter.GaussianBlur(3.5))
        try:
            from PIL import ImageEnhance
            s = ImageEnhance.Color(s).enhance(1.45)
        except Exception:
            pass
        self.src = s

    def _grid(self, bw, bh):
        if self.shape == (bw, bh):
            return
        self.shape = (bw, bh)
        u = (np.arange(bw, dtype=np.float32) + 0.5) / bw
        v = (np.arange(bh, dtype=np.float32) + 0.5) / bh
        self.U, self.V = np.meshgrid(u, v)
        self.asp = bw / bh
        dx, dy = (self.U - 0.5) * 2.0, (self.V - 0.5) * 2.0
        self.vig = np.clip(1.0 - 0.38 * (dx * dx * 0.8 + dy * dy), 0.35, 1.0).astype(np.float32)[..., None]

    def render(self, t, bw, bh, pal: Palette, level: int, fade: float, src=None, pulse: float = 0.0, media=None, midx: int = 0,
               dim: float = 0.42, cyber: float = 0.0, tint=None, zoom_on: bool = True):
        self._grid(bw, bh)
        tint = np.asarray(tint if tint is not None else pal.a, np.float32)
        if media is not None:                                      # image / GIF / video background
            fr = media.fit(midx, bw, bh, 1.0 + (0.045 * pulse if zoom_on else 0.0))
            out = np.asarray(fr, np.float32) * ((1.0 - dim) * (1.0 + 0.35 * pulse))
            if cyber > 0.04:                                       # cyberpsychosis: the picture splits into red / cyan copies
                d = max(1, int(1 + cyber * bw * 0.018))
                out[..., 0], out[..., 2] = np.roll(out[..., 0], d, 1), np.roll(out[..., 2], -d, 1)
            out += tint * (0.10 * pulse)
            out *= (0.65 + 0.35 * self.vig) * fade
            return np.clip(out, 0, 255).astype(np.uint8)
        src = src or self.src
        out = np.empty((bh, bw, 3), np.float32)
        out[:] = np.asarray(pal.deep, np.float32)
        acc = np.zeros((bh, bw, 3), np.float32)
        tt = t if level >= 1 else 0.0
        for i in range(4):
            cxx = 0.5 + 0.42 * math.sin(0.13 * tt * (1 + 0.25 * i) + 1.7 * i)
            cyy = 0.5 + 0.38 * math.cos(0.10 * tt * (1 + 0.2 * i) + 2.3 * i)
            r = 0.30 + 0.07 * math.sin(0.17 * tt + i) + 0.06 * pulse            # blobs swell on the beat
            g = np.exp(-(((self.U - cxx) * self.asp) ** 2 + (self.V - cyy) ** 2) / (r * r))
            col = tint if (cyber > 0.04 and i % 2 == 0) else (pal.a if i % 2 == 0 else pal.b)
            acc += g[..., None] * np.asarray(col, np.float32)
        out += acc * (0.20 * (1.0 + 0.9 * pulse))
        if level >= 2 and src is not None:
            S = 64
            zoom = 1.65 + 0.18 * math.sin(0.11 * t)
            sc = (S / zoom) / bw
            th = 0.05 * t
            A, B, C, D = math.cos(th) * sc, -math.sin(th) * sc, math.sin(th) * sc, math.cos(th) * sc
            px, py = 5.0 * math.sin(0.07 * t), 4.0 * math.cos(0.05 * t)
            im = src.transform((bw, bh), Image.AFFINE,
                                    (A, B, S / 2 + px - A * bw / 2 - B * bh / 2,
                                     C, D, S / 2 + py - C * bw / 2 - D * bh / 2), resample=Image.BILINEAR)
            out += np.asarray(im, np.float32) * (0.46 * (1.0 + 0.5 * pulse))
        out += tint * (0.08 * pulse)
        out *= self.vig * fade
        return np.clip(out, 0, 255).astype(np.uint8)


# --------------------------------------------------------------------------- cover / info / progress images

def build_cover(img, size: int, scale: float, pal: Palette, echo=None):
    pad = int(size * 0.18)
    C = size + 2 * pad
    S = max(16, int(size * scale))
    off = (C - S) // 2
    glow = Image.new("L", (C, C), 0)
    sh = Image.new("L", (C, C), 0)
    rad = int(S * 0.055)
    ImageDraw.Draw(glow).rounded_rectangle([off, off + int(S * 0.02), off + S, off + S + int(S * 0.02)], radius=rad, fill=255)
    ImageDraw.Draw(sh).rounded_rectangle([off + int(S * 0.02), off + int(S * 0.045), off + S - int(S * 0.02),
                                          off + S + int(S * 0.045)], radius=rad, fill=255)
    glow = glow.filter(ImageFilter.GaussianBlur(size * 0.085))
    sh = sh.filter(ImageFilter.GaussianBlur(size * 0.04))
    canvas = Image.new("RGBA", (C, C), (0, 0, 0, 0))
    gl = Image.new("RGBA", (C, C), tuple(int(v) for v in mix(pal.a, WHITE, 0.15)) + (255,))
    gl.putalpha(glow.point(lambda v: int(v * 0.30)))
    canvas = Image.alpha_composite(canvas, gl)
    sd = Image.new("RGBA", (C, C), (0, 0, 0, 255))
    sd.putalpha(sh.point(lambda v: int(v * 0.55)))
    canvas = Image.alpha_composite(canvas, sd)
    if img is None:
        g = np.linspace(0, 1, 64, dtype=np.float32)
        gx = (g[None, :] + g[:, None]) / 2.0
        cols = np.asarray(pal.a, np.float32) * (1 - gx[..., None]) + np.asarray(pal.b, np.float32) * gx[..., None]
        cover = Image.fromarray(np.clip(cols, 0, 255).astype(np.uint8)).resize((S, S), Image.BILINEAR)
    else:
        cover = img.convert("RGB").resize((S, S), Image.LANCZOS)
    if echo and echo[0] > 0.04:                                          # cyberpsychosis: RGB split + doubled ghost image
        cover = echo_pil(cover, echo[0], random.Random(echo[1]))
    mask = Image.new("L", (S * 2, S * 2), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, S * 2 - 1, S * 2 - 1], radius=rad * 2, fill=255)
    canvas.paste(cover, (off, off), mask.resize((S, S), Image.LANCZOS))
    return np.asarray(canvas), pad


def render_info(track: Track, w: int, fonts: Fonts, pal: Palette, px: int, center: bool = False):
    ft, fa = fonts.get(fonts.bold, px), fonts.get(fonts.regular, int(px * 0.82))
    lh = int(px * 1.28)
    lines = [(fit_text(track.title, ft, w), ft, (255, 255, 255, 255)),
             (fit_text(track.artist, fa, w), fa, tuple(int(v) for v in mix(pal.a, WHITE, 0.2)) + (235,))]
    if track.album:
        lines.append((fit_text(track.album, fa, w), fa, tuple(int(v) for v in mix(pal.b, WHITE, 0.35)) + (150,)))
    im = Image.new("RGBA", (w, lh * len(lines) + 6), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    for i, (txt, f, col) in enumerate(lines):
        if center:
            d.text((w / 2, i * lh), txt, font=f, fill=col, anchor="ma")
        else:
            d.text((0, i * lh), txt, font=f, fill=col)
    return np.asarray(im)


def render_progress(w: int, h: int, pos: float, total, pal: Palette, fonts: Fonts, px: int):
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    f = fonts.get(fonts.regular, px)
    cy = h // 2
    tl = fmt_time(pos)
    d.text((0, cy), tl, font=f, fill=(255, 255, 255, 205), anchor="lm")
    if not total:
        return np.asarray(im)
    tr = fmt_time(total)
    d.text((w - 1, cy), tr, font=f, fill=(255, 255, 255, 150), anchor="rm")
    bx0 = int(f.getlength("00:00")) + 18
    bx1 = w - int(f.getlength("00:00")) - 18
    if bx1 - bx0 < 30:
        return np.asarray(im)
    th = max(3, px // 6)
    d.rounded_rectangle([bx0, cy - th // 2, bx1, cy + th // 2], radius=th // 2, fill=(255, 255, 255, 56))
    x = bx0 + int(clamp(pos / total) * (bx1 - bx0))
    lit = tuple(int(v) for v in mix(pal.a, WHITE, 0.45)) + (255,)
    if x > bx0:
        d.rounded_rectangle([bx0, cy - th // 2, x, cy + th // 2], radius=th // 2, fill=lit)
    r = th + 2
    d.ellipse([x - r, cy - r, x + r, cy + r], fill=(255, 255, 255, 255))
    return np.asarray(im)


# --------------------------------------------------------------------------- the app

ALPHA_TBL = [0.42, 0.52, 0.37, 0.27, 0.20, 0.15, 0.11, 0.08]
BLUR_TBL = [0.0, 0.9, 1.9, 2.9, 3.6, 4.2, 4.6, 5.0]
ID_BG, ID_COVER, ID_INFO, ID_PROG, ID_ANIM, ID_ROW0 = 1, 2, 3, 4, 5, 1000
ID_SCENE0, ID_KIN = 6000, 6100


class KittyApp(Base):
    def __init__(self, cfg, state, fx):
        super().__init__(cfg, state, fx)
        if np is None or Image is None:
            raise RuntimeError("the kitty renderer needs numpy and Pillow (python-numpy, python-pillow)")
        self.fonts = Fonts(getattr(cfg, "font", None))
        self.gfx = Gfx()
        self.back = Backdrop()
        self.scr = Screen()
        self.size = None
        self.fx_t, self.fx_speed = 0.0, 1.0
        self.last_bg = -9.0
        self.track_t0 = time.monotonic()
        self.reset_track_state()
        self.cover_s, self.cover_v, self.cover_key, self.cover_sent, self.cover_last = 1.0, 0.0, None, None, -9.0
        self.bob = 0.0
        self.info_key = self.prog_key = None
        self.layout_cache = None
        self.art_id = None
        self.next_iid = ID_ROW0
        self.anim = types.SimpleNamespace(token=None, queue=[], root_sent=False, prepped=False, running=None,
                                          frames_bg=None, clock=0.0, fps=12, S=0)
        self.g_view = "std"
        self.item_rows, self.art_cols = 2, 4             # 4x2 cells ≈ 36x36 px real image beside each song
        self.thumb_ids: dict = {}
        self.thumb_next = 3000
        self.thumb_placed: set = set()
        self._tmask = None
        self.scene_ids, self.scene_key = [], None        # built-in Earth scene: 6 beat variants
        self.kin_sig, self.kin_shown, self.kin_t = None, False, 0.0
        self._last_pulse = 0.0

    # ---- animated cover: frames are uploaded ONCE (budgeted per frame) and then looped by kitty itself
    def anim_reset(self):
        a = self.anim
        a.token, a.root_sent, a.prepped, a.running, a.frames_bg, a.clock = None, False, False, None, None, 0.0
        del a.queue[:]

    def anim_start(self, canvas, S: int):
        self.anim_reset()
        self.anim.token, self.anim.S = id(canvas), S
        self.anim.fps = canvas.fps
        threading.Thread(target=self._prep_anim, args=(canvas, S, self.anim.token), daemon=True).start()

    def _prep_anim(self, canvas, S: int, token):
        """Background thread: frames -> rounded RGBA -> zlib -> kitty protocol messages."""
        try:
            gap = int(round(1000.0 / canvas.fps))
            rad = int(S * 0.055)
            m = Image.new("L", (S * 2, S * 2), 0)
            ImageDraw.Draw(m).rounded_rectangle([0, 0, S * 2 - 1, S * 2 - 1], radius=rad * 2, fill=255)
            mask = np.asarray(m.resize((S, S), Image.LANCZOS), np.uint8)
            bg = []
            for k, fr in enumerate(canvas.frames):
                if self.anim.token != token:
                    return
                small = Image.fromarray(fr)
                bg.append(small.resize((64, 64), Image.BILINEAR).filter(ImageFilter.GaussianBlur(3.5)))
                if fr.shape[0] != S:
                    fr = np.asarray(small.resize((S, S), Image.LANCZOS))
                rgba = np.empty((S, S, 4), np.uint8)
                rgba[..., :3], rgba[..., 3] = fr, mask
                keys = (f"a=t,f=32,s={S},v={S},o=z,i={ID_ANIM}" if k == 0 else
                        f"a=f,i={ID_ANIM},f=32,s={S},v={S},o=z,z={gap},X=1")
                self.anim.queue.append(Gfx._chunks(keys, zlib.compress(rgba.tobytes(), 3)))
            self.anim.queue.append(f"\x1b_Ga=a,i={ID_ANIM},r=1,z={gap},q=2\x1b\\")
            self.anim.frames_bg = bg
            self.anim.prepped = True
        except Exception as e:
            log(f"anim prep: {e!r}")

    def setup(self) -> bytes:
        return self.gfx.delete_all().encode()

    def teardown(self) -> bytes:
        return self.gfx.delete_all().encode()

    def _kin_frame(self, out, ly, t, style, g, now, PW, PH):
        cur = ly.current(t)
        ln = ly.lines[max(cur, 0)]
        te = t - 0.15 if self.stutter else t
        if ln.kind != "line":                                              # instrumental gap: three big dots
            seg = max(0.2, (ln.e - ln.b) / 3.0)
            words = [[Cell("●", ln.b + i * seg, ln.b + (i + 1) * seg, False, 1)] for i in range(3)]
        else:
            words, cw_ = [], []
            for c in ln.cells:
                if c.ch == " ":
                    if cw_:
                        words.append(cw_)
                    cw_ = []
                else:
                    cw_.append(c)
            if cw_:
                words.append(cw_)
        started = [w for w in words if te >= w[0].b - 0.03]
        act = started[-1] if started else None
        qf = int(fill_of(act[-1], te) * 12) if act else -1
        gk = self.k if (self.cyber_on and bool(getattr(self.cfg, "cyber_echo", True))) else 0.0
        sig = (cur, len(started), qf, int(self.pulse * 3), int(gk * 10), self.gseed if gk > 0.04 else 0, self.stutter, style, PW)
        sweep_dt = 1.0 / (15.0 if self.low else min(24.0, max(1.0, float(self.cfg.sweep_hz))))
        if sig != self.kin_sig and now - self.kin_t >= sweep_dt:
            self.kin_sig, self.kin_t = sig, now
            band_h = int(PH * 0.56)
            cw2, ch2 = max(64, PW // 2), max(48, band_h // 2)
            fpx = int(ch2 * (0.64 if style == "word" else 0.30))
            arr = render_kinetic(words, te, cw2, ch2, fpx, style, self.pulse, gk, self.stutter, self.fonts.bold)
            if arr is None:
                if self.kin_shown:
                    out.append(self.gfx.unplace(ID_KIN))
                    self.kin_shown = False
                return
            out.append(self.gfx.send(ID_KIN, arr, 32, 4))
            self.kin_shown = True
        if self.kin_shown:
            rows = int(math.ceil(int(PH * 0.56) / self.gfx.ch))
            out.append(self.gfx.place(ID_KIN, 0, int(PH * 0.19), Gfx.Z_TEXT, max(1, PW // self.gfx.cw), rows))

    def reset_thumbs(self):
        self.thumb_ids.clear()
        self.thumb_placed.clear()
        self.scene_ids, self.scene_key, self.kin_sig, self.kin_shown = [], None, None, False   # delete_all wiped them

    def _thumb_rgba(self, im):
        n = im.size[0]
        if self._tmask is None or self._tmask.shape[0] != n:
            m = Image.new("L", (n * 3, n * 3), 0)
            ImageDraw.Draw(m).rounded_rectangle([0, 0, n * 3 - 1, n * 3 - 1], radius=int(n * 0.2 * 3), fill=255)
            self._tmask = np.asarray(m.resize((n, n), Image.LANCZOS), np.uint8)
        arr = np.asarray(im.convert("RGBA")).copy()
        arr[..., 3] = self._tmask
        return arr

    def place_thumbs(self) -> list:
        """modern list in kitty: one real image per visible song, placed beside its text"""
        out, want = [], set()
        if self.view == "pick" and self.list_style == "modern" and Image is not None and np is not None:
            for slot_i, (url, x, y, cols, rows, kind, title) in enumerate(self.art_slots):
                im = self.thumbs.get(url, 96) if url else None
                if im is None:
                    continue
                key = (url, 96)
                iid = self.thumb_ids.get(key)
                if iid is None:
                    iid = self.thumb_ids[key] = self.thumb_next
                    self.thumb_next += 1
                    out.append(self.gfx.send(iid, self._thumb_rgba(im), 32))
                want.add((iid, 100 + slot_i))
                out.append(self.gfx.place(iid, x * self.gfx.cw + 1, y * self.gfx.ch + 1, Gfx.Z_UI, cols, rows, 100 + slot_i))
        for iid, pid in list(self.thumb_placed - want):
            out.append(self.gfx.unplace(iid, pid))
        self.thumb_placed = want
        if len(self.thumb_ids) > 180:                   # keep kitty's image memory bounded
            for key in list(self.thumb_ids)[:60]:
                iid = self.thumb_ids.pop(key)
                self.thumb_placed = {t for t in self.thumb_placed if t[0] != iid}
                out.append(self.gfx.delete(iid))
        return out

    def on_level(self):
        self.last_bg = -9.0

    def on_low(self):
        self.last_bg = -9.0

    def reset_track_state(self):
        self.ypos: dict = {}
        self.alpha: dict = {}
        self.blur: dict = {}
        self.row_ids: dict = {}

    def on_track(self, track):
        super().on_track(track)
        self.reset_track_state()
        self.anim_reset()
        self.track_t0 = time.monotonic()
        self.cover_key = self.info_key = self.prog_key = None
        self.art_id = None

    # ---- geometry
    def geometry(self, W, H, PW, PH):
        g = types.SimpleNamespace()
        g.W, g.H, g.PW, g.PH = W, H, PW, PH
        g.fpx = int(clamp(PH * 0.056, 22, 54))
        g.pad = int(g.fpx * 0.6)
        g.margin = int(max(self.gfx.ch * 1.6, PW * 0.035))
        g.wide = self.art_on and PW >= 820
        g.csize_lyrics = 0
        if g.wide:
            g.csize_lyrics = int(clamp(min(PH * 0.44, PW * 0.26), 120, 520))
            if self.fx.cloader and self.fx.cloader.enabled and not self.low:
                g.csize_lyrics = min(g.csize_lyrics, 320)    # animated loops are decoded at 320 px
        if self.view == "cover":                             # big centred cover, no lyrics
            g.wide = True
            size = int(clamp(min(PH * 0.56, PW * 0.44), 160, 560))
            g.csize = size - size % self.gfx.ch              # whole rows -> the animation scales without distortion
            g.cover_x = (PW - g.csize) // 2
            g.cover_y = max(int(self.gfx.ch * 1.2), int((PH - g.csize) / 2 - self.gfx.ch * 2.2))
            g.col_x = g.margin
        elif g.wide:
            g.csize = g.csize_lyrics
            g.cover_x = g.margin
            g.cover_y = max(int(self.gfx.ch * 1.5), int((PH - g.csize) / 2 - self.gfx.ch * 2.2))
            g.col_x = g.margin + g.csize + int(PW * 0.055)
        else:
            g.csize = 0
            g.col_x = g.margin
        g.colw = max(200, min(PW - g.col_x - g.margin, int(PH * 1.6)))
        g.anchor = int(PH * 0.27)
        g.top = int(self.gfx.ch * 1.2)
        g.bot = PH - int(self.gfx.ch * 3.4)
        g.lh = None
        return g

    def layout(self, ly, g):
        key = (id(ly), g.colw, g.fpx)
        if self.layout_cache and self.layout_cache[0] == key:
            return self.layout_cache[1]
        rows_per, ys, y = [], [], 0
        gap = int(g.fpx * 0.58)
        sample = self.fonts.get(self.fonts.bold, g.fpx)
        asc, desc = sample.getmetrics()
        lh = asc + desc + int(g.fpx * 0.08)
        for ln in ly.lines:
            if ln.kind == "interlude":
                rows = [make_prow(ln.cells, self.fonts, g.fpx, "dots")]
            else:
                rows = [make_prow(r, self.fonts, g.fpx) for r in wrap_px(ln.cells, self.fonts, g.fpx, g.colw)]
            rows_per.append(rows)
            ys.append(y)
            y += len(rows) * lh + gap
        res = (rows_per, ys, lh)
        self.layout_cache = (key, res)
        return res

    def colors(self, pal):
        b_sat, a_sat = PRESETS[self.preset][0] == "sat", PRESETS[self.preset][1] == "sat"
        dim = mix(WHITE, pal.a, 0.55 if b_sat else 0.10)
        lit = mix(WHITE, pal.a, 0.42 if a_sat else 0.06)
        gl = mix(pal.a, WHITE, 0.30)
        f = lambda c: np.asarray(c, np.float32)
        return f(dim), f(lit), f(gl)

    # ---- frame
    def frame(self, dt: float, now: float) -> bytes:
        W, H, xp, yp = self.sizes(now)
        if not xp or not yp:
            xp, yp = W * 9, H * 18
        self.gfx.cw, self.gfx.ch = max(1, xp // W), max(1, yp // H)
        PW, PH = self.gfx.cw * W, self.gfx.ch * H
        out = []
        if (W, H, PW, PH, self.art_on, self.low) != self.size:
            self.size = (W, H, PW, PH, self.art_on, self.low)
            self.scr.resize(W, H)
            out.append(self.gfx.delete_all())
            self.reset_thumbs()
            self.row_ids.clear()
            self.cover_key = self.info_key = self.prog_key = None
            self.layout_cache = None
            self.g_view = "cover" if self.view == "cover" else "std"
            self.g = self.geometry(W, H, PW, PH)
            self.anim_reset()                                # delete_all wiped the uploaded animation -> it is sent again
        elif ("cover" if self.view == "cover" else "std") != self.g_view:
            self.g_view = "cover" if self.view == "cover" else "std"
            self.g = self.geometry(W, H, PW, PH)
            self.cover_key = self.info_key = None
        g = self.g
        track, playing, player = self.state.snapshot()
        key = track.key if track else None
        if key != self.cur_key:
            self.on_track(track)
            out.append(self.gfx.delete_all())
            self.reset_thumbs()
        t_pos = self.state.position()
        t = t_pos + self.offset
        self.pal = self.pal.lerp(self.fx.palette, 1.0 - math.exp(-dt * 2.2))
        pal = self.pal
        glow = self.glow
        self.fx_update(track, t, now)
        pulse = self.pulse
        amp = self.shake_amp if self.cyber_on else 0.0                     # screen shake = every image placement jumps a few pixels
        self.gfx.off = ((int(self.shake_dir[0] * amp * PW * 0.012), int(self.shake_dir[1] * amp * PH * 0.012)) if amp > 0.18 else (0, 0))
        style = self.eff_style()
        kin = style in ("kinetic", "word") and self.view == "lyrics"

        # art -> backdrop source (once per art object)
        art = self.fx.art
        if id(art) != self.art_id:
            self.art_id = id(art)
            self.back.set_art(art)

        low = self.low
        lvl = 0 if low else self.level
        glow_eff = 0.0 if low else glow
        canvas = self.fx.canvas if (g.wide and not low and np is not None and not self.cyber_on) else None
        if canvas is not None and self.anim.token != id(canvas):
            self.anim_start(canvas, min(320, g.csize_lyrics or g.csize))
        elif canvas is None and self.anim.token is not None:
            out.append(self.gfx.delete(ID_ANIM))
            self.anim_reset()
        animated = canvas is not None
        frame_src = None
        if animated and self.anim.frames_bg and self.anim.running:
            self.anim.clock += dt
        if animated and self.anim.frames_bg:
            fb = self.anim.frames_bg
            frame_src = fb[int(self.anim.clock * self.anim.fps) % len(fb)]

        # ---------- backdrop (animated cover effect)
        self.fx_speed += ((1.0 if playing else 0.3) - self.fx_speed) * (1 - math.exp(-dt * 2.0))
        self.fx_t += dt * self.fx_speed
        media = self.bgm
        if lvl >= 1:
            bg_dt = 1.0 / max(1.0, float(self.cfg.bg_hz))
        elif media is not None or pulse > 0.02 or self._last_pulse > 0.02:           # low-end: still pulses with the beat, at 12 Hz
            bg_dt = 1.0 / 12.0
        else:
            bg_dt = 0.5
        self._last_pulse = pulse
        if now - self.last_bg >= bg_dt:
            self.last_bg = now
            bw = int(clamp(PW // (5 if media is not None else 10), 160 if media is not None else 96, 320 if media is not None else 160))
            bh = max(24, int(bw * PH / PW))
            fade = 0.45 + 0.55 * smooth((now - self.track_t0) / 1.2)
            spec = self.bg_spec or {}
            img = self.back.render(self.fx_t, bw, bh, pal, lvl, fade, frame_src, pulse=pulse, media=media,
                                   midx=(media.idx(now) if media is not None else 0), dim=float(spec.get("dim", 0.42)),
                                   cyber=(self.k if self.cyber_on else 0.0), tint=self.tint_color(),
                                   zoom_on=str(spec.get("beat", "all")).lower() in ("all", "zoom"))
            out.append(self.gfx.send(ID_BG, img, 24))
            out.append(self.gfx.place(ID_BG, 0, 0, Gfx.Z_BG, W, H, shake=False))

        # ---------- built-in Earth scene (tribute song): 6 beat variants uploaded once, the right one is placed each frame
        if self.moon_on and self.view in ("lyrics", "cover"):
            skey = (self.figures,)
            if self.scene_key != skey:
                self.scene_key = skey
                for i in range(6):
                    a_ = np.asarray(moon_art(480, 270, i, self.figures)).astype(np.float32)
                    a_[..., :3] *= np.linspace(0.45, 1.0, 480, dtype=np.float32)[None, :, None]      # darker on the left, where the lyrics are
                    out.append(self.gfx.send(ID_SCENE0 + i, np.clip(a_, 0, 255).astype(np.uint8), 32))
                self.scene_ids = list(range(ID_SCENE0, ID_SCENE0 + 6))
            want = int(round(pulse * 5))
            for i, iid in enumerate(self.scene_ids):
                out.append(self.gfx.place(iid, 0, 0, Gfx.Z_BG + 10, W, H) if i == want else self.gfx.unplace(iid))
        elif self.scene_ids:
            for iid in self.scene_ids:
                out.append(self.gfx.unplace(iid))

        # ---------- cover: static image (spring pop on pause) or the real animated canvas on top of it
        if g.wide:
            target = 1.0 if (playing or animated or low) else 0.86
            if low:
                self.cover_s, self.cover_v = target, 0.0
            else:
                sub = max(1, int(dt / 0.008))
                for _ in range(min(sub, 12)):
                    h_ = dt / sub
                    self.cover_v += ((target - self.cover_s) * 190.0 - self.cover_v * 15.0) * h_
                    self.cover_s += self.cover_v * h_
            echo_on = self.cyber_on and self.k > 0.06 and bool(getattr(self.cfg, "cyber_echo", True))
            ck = (id(art), g.csize, tuple(int(v) >> 4 for v in self.fx.palette.a), echo_on)
            moving = self.cover_sent is None or abs(self.cover_s - self.cover_sent) > 0.004
            gl_due = echo_on and now - self.cover_last >= (0.11 if self.k > 0.5 else 0.2)
            if ck != self.cover_key or (moving and now - self.cover_last >= 1 / 20.0) or gl_due:
                arr, cpad = build_cover(art, g.csize, self.cover_s, self.fx.palette, echo=((self.k, self.gseed) if echo_on else None))
                out.append(self.gfx.send(ID_COVER, arr, 32))
                self.cover_key, self.cover_sent, self.cover_last, self.cover_pad = ck, self.cover_s, now, cpad
            self.bob += ((1.0 if (playing and not low) else 0.0) - self.bob) * (1 - math.exp(-dt * 2.0))
            bob = int(math.sin(now * 0.9) * self.gfx.ch * 0.16 * self.bob) - (int(pulse * self.gfx.ch * 0.25) if (self.beat.enabled and not low) else 0)
            out.append(self.gfx.place(ID_COVER, g.cover_x - self.cover_pad, g.cover_y - self.cover_pad + bob, Gfx.Z_COVER))
            if animated:
                budget, sent_any = 260_000, False      # bytes per frame: never stall the lyrics while uploading
                while self.anim.queue and (not sent_any or len(self.anim.queue[0]) <= budget):
                    msg = self.anim.queue.pop(0)
                    out.append(msg)
                    budget -= len(msg)
                    sent_any = True
                    self.anim.root_sent = True
                if self.anim.root_sent:
                    if g.csize != self.anim.S:
                        out.append(self.gfx.place(ID_ANIM, g.cover_x, g.cover_y + bob, Gfx.Z_ANIM,
                                                  max(1, round(g.csize / self.gfx.cw)), max(1, round(g.csize / self.gfx.ch))))
                    else:
                        out.append(self.gfx.place(ID_ANIM, g.cover_x, g.cover_y + bob, Gfx.Z_ANIM))
                if self.anim.prepped and not self.anim.queue:
                    want = bool(playing)
                    if self.anim.running != want:      # kitty loops it on the GPU; we only start / stop it
                        out.append(f"\x1b_Ga=a,i={ID_ANIM},s={3 if want else 1},v=1,q=2\x1b\\")
                        self.anim.running = want
            if track:
                center = self.view == "cover"
                ik = (track.key, g.csize, center, tuple(int(v) >> 4 for v in self.fx.palette.a))
                if ik != self.info_key:
                    self.info_key = ik
                    ipx = int(clamp(g.csize * (0.07 if center else 0.075), 15, 34))
                    out.append(self.gfx.send(ID_INFO, render_info(track, g.csize, self.fonts, self.fx.palette, ipx, center), 32))
                out.append(self.gfx.place(ID_INFO, g.cover_x, g.cover_y + g.csize + int(self.gfx.ch * 1.2), Gfx.Z_UI))
        else:
            out.append(self.gfx.unplace(ID_COVER))
            out.append(self.gfx.unplace(ID_ANIM))

        # ---------- lyrics
        ly = self.fx.lyrics
        live_ids = set()
        if self.view != "lyrics" or kin:                     # cover / picker / kinetic view: lift the lyric images out of the way
            for iid in list(self.row_ids.values()):
                out.append(self.gfx.unplace(iid))
        if ly is not None and self.view == "lyrics" and not kin:
            rows_per, ys, lh = self.layout(ly, g)
            cur = ly.current(t)
            ci = max(cur, 0)
            dim_rgb, lit_rgb, _ = self.colors(pal)
            gcols = tuple(np.asarray(c, np.float32) for c in glow_colors(pal, self.gcolor))
            gstyle = dict(GLOW_STYLES[self.gstyle])
            if self.gfollow in ("head", "trail"):
                gstyle["follow"] = self.gfollow
            gtag = (self.gstyle, self.gcolor, round(self.gsize * 10), self.gfollow, tuple(int(v) >> 3 for v in gcols[0]))
            pulse_ph = int(now * 5.0 / 0.8) if gstyle["pulse"] > 0 else 0
            sweep_dt = 1.0 / (15.0 if low else max(1.0, float(self.cfg.sweep_hz)))
            lift = g.fpx * 0.075
            gsig = g.fpx * 0.17 * self.gsize
            for i in range(max(0, ci - 5), min(len(ly.lines), ci + 9)):
                ln, rows = ly.lines[i], rows_per[i]
                d = i - ci
                tgt_y = g.anchor + ys[i] - ys[ci]
                rate = 13.0 / (1.0 + 0.55 * d) if d > 0 else 13.0 / (1.0 + 0.25 * -d)   # staggered cascade
                if i not in self.ypos:
                    self.ypos[i] = tgt_y
                self.ypos[i] += (tgt_y - self.ypos[i]) * (1.0 - math.exp(-dt * rate))
                window = ln.b - 0.5 <= t < ln.e + 0.75
                dd = min(abs(i - cur), len(ALPHA_TBL) - 1) if cur >= 0 else min(i + 1, len(ALPHA_TBL) - 1)
                ta = ALPHA_TBL[0] if window else ALPHA_TBL[dd] * (0.8 if i < cur else 1.0)
                tb = 0.0 if (window or low) else BLUR_TBL[dd] * g.fpx / 40.0
                kf = 1.0 - math.exp(-dt * 8.0)
                a_ = self.alpha[i] = self.alpha.get(i, ta) + (ta - self.alpha.get(i, ta)) * kf
                b_ = self.blur[i] = self.blur.get(i, tb) + (tb - self.blur.get(i, tb)) * kf
                lg = 1.0 if t < ln.e else 1.0 - smooth((t - ln.e) / 0.7)
                align = ly.align(ln, "left")
                for ri, row in enumerate(rows):
                    if not row.cells:
                        continue
                    rid = (i, ri)
                    y = int(self.ypos[i]) + ri * lh
                    cy_ = y + lh / 2.0
                    edge = smooth((cy_ - g.top) / (lh * 1.4)) * smooth((g.bot - cy_) / (lh * 1.4))
                    iid = self.row_ids.get(rid)
                    if edge <= 0.02 or y - g.pad < 0 or y + lh + g.pad > g.PH:
                        if iid is not None:
                            out.append(self.gfx.unplace(iid))
                        continue
                    if iid is None:
                        iid = self.row_ids[rid] = self.next_iid
                        self.next_iid += 1
                        row.sig = None
                    live_ids.add(rid)
                    aq = round(a_ * edge * 25) / 25.0
                    if window:
                        te = t - 0.15 if self.stutter else t
                        gk_ = self.k if (self.cyber_on and bool(getattr(self.cfg, "cyber_echo", True))) else 0.0
                        fq = tuple(int(fill_of(row.cells[k], te) * 20) for k in row.cidx)
                        breath = 1.0 + 0.10 * math.sin(now * 3.1) if row.kind == "dots" else 1.0
                        sig = ("a", fq, round(lg * 12), aq, int(breath * 50), round(glow_eff * 10), low, gtag, pulse_ph, int(pulse * 3), int(gk_ * 10), self.stutter)
                        if sig != row.sig and now - getattr(row, "last_t", 0.0) >= sweep_dt:
                            row.sig, row.last_t = sig, now
                            arr = render_active(row, te, g.pad, aq, lg, dim_rgb, lit_rgb, gcols, glow_eff * (1.0 + 0.6 * pulse), lift, gsig, breath,
                                                gstyle, now, echo=((gk_, self.stutter) if gk_ > 0.04 else None))
                            out.append(self.gfx.send(iid, arr, 32, 4))
                    else:
                        bq = round(b_ * 4) / 4.0
                        sig = ("s", aq, bq, tuple(int(v) >> 3 for v in dim_rgb), low)
                        if sig != row.sig:
                            row.sig = sig
                            out.append(self.gfx.send(iid, render_static(row, g.pad, bq, aq, tuple(int(v) for v in dim_rgb)), 32))
                    x = g.col_x + ((g.colw - int(row.w)) if align == "right" else 0)
                    out.append(self.gfx.place(iid, x - g.pad, y - g.pad, Gfx.Z_TEXT))
            # free rows that left the window
            for rid in [k for k in self.row_ids if k not in live_ids]:
                out.append(self.gfx.delete(self.row_ids.pop(rid)))
            self.ypos = {k: v for k, v in self.ypos.items() if ci - 8 <= k <= ci + 12}

        # ---------- kinetic / one-word lyric cards (the lyric-video look)
        if kin and ly is not None:
            self._kin_frame(out, ly, t, style, g, now, PW, PH)
        elif self.kin_shown:
            out.append(self.gfx.unplace(ID_KIN))
            self.kin_shown, self.kin_sig = False, None

        # ---------- progress bar
        total = (track.duration if track and track.duration else None) or (ly.end + 2 if ly else None)
        if track:
            pw = PW - 2 * g.margin
            ph = int(self.gfx.ch * 1.6)
            pxs = int(clamp(self.gfx.ch * 0.8, 11, 18))
            pk_ = (int(t_pos), int(clamp(t_pos / total) * max(pw, 1) / (16 if low else 2)) if total else 0, pw, tuple(int(v) >> 4 for v in pal.a))
            if pk_ != self.prog_key:
                self.prog_key = pk_
                out.append(self.gfx.send(ID_PROG, render_progress(pw, ph, t_pos, total, pal, self.fonts, pxs), 32))
            out.append(self.gfx.place(ID_PROG, g.margin, PH - int(self.gfx.ch * 2.9), Gfx.Z_UI))
        else:
            out.append(self.gfx.unplace(ID_PROG))
            self.prog_key = None

        # ---------- tiny text overlay (status / hints / debug)
        scr = self.scr
        scr.clear()
        if not g.wide and track:
            x = scr.text(2, 0, "♪ ", pk(pal.b), 1)
            x = scr.text(x, 0, trunc(track.title, max(4, (W - 6) * 6 // 10)), pk(WHITE), 1)
            if W - 2 - x > 6:
                scr.text(x, 0, trunc("  " + track.artist, W - 2 - x), pk(pal.a), 0)
        if self.view == "pick":
            self.draw_browser(scr, g.col_x // self.gfx.cw, 1, max(20, g.colw // self.gfx.cw), max(8, H - 4), pal)
        else:
            self.art_slots = []
        out.extend(self.place_thumbs())
        if self.view == "pick":
            pass
        elif ly is None and self.view == "lyrics":
            if track is None:
                msg, sub = "waiting for music", self.fx.err or self.state.error or "play something in Spotify, Firefox, mpv…"
            elif self.fx.status == "loading":
                msg, sub = "fetching lyrics" + "." * (1 + int(now * 3) % 3), ""
            else:
                msg, sub = "no synced lyrics for this track", self.fx.err
            cx0 = g.col_x // self.gfx.cw
            cw_ = max(10, g.colw // self.gfx.cw)
            col = mix(pal.deep, mix(pal.a, WHITE, 0.5), 0.6 + 0.35 * math.sin(now * 2.2))
            yy = max(2, int(g.anchor / self.gfx.ch))
            scr.text(cx0, yy, trunc(msg, cw_), pk(col), 1)
            if sub:
                scr.text(cx0, yy + 2, trunc(sub, cw_), pk(mix(pal.deep, WHITE, 0.45)), 2)
        self.overlay(scr, W, H, pal, track, playing)
        body = scr.flush()
        return ("\x1b[?2026h" + "".join(out) + body + "\x1b[0m\x1b[?2026l").encode("utf-8", "replace")


# =========================================================================== main loop / CLI

def parse_keys(data: str):
    """raw terminal bytes -> key names: single chars, plus UP DOWN LEFT RIGHT HOME END PGUP PGDN DEL ENTER BACKSPACE ESC TAB"""
    out, i, n = [], 0, len(data)
    csi = {"A": "UP", "B": "DOWN", "C": "RIGHT", "D": "LEFT", "H": "HOME", "F": "END", "Z": "BTAB"}
    tilde = {"1": "HOME", "3": "DEL", "4": "END", "5": "PGUP", "6": "PGDN", "7": "HOME", "8": "END"}
    while i < n:
        c = data[i]
        if c == "\x1b" and data[i:i + 3] == "\x1b[<":                        # SGR mouse / touch: ESC [ < b ; x ; y M|m
            j = i + 3
            while j < n and data[j] not in "Mm":
                j += 1
            if j < n:
                try:
                    b, x, y = (int(v) for v in data[i + 3:j].split(";"))
                    if data[j] == "M" and (b & 3) == 0 and b < 32:
                        out.append(f"CLICK:{x - 1}:{y - 1}")
                except ValueError:
                    pass
                i = j + 1
                continue
            break
        if c == "\x1b":
            if i + 1 < n and data[i + 1] in "[O":
                j = i + 2
                while j < n and (data[j].isdigit() or data[j] in ";?"):
                    j += 1
                if j < n:
                    fin, par = data[j], data[i + 2:j].split(";")[0]
                    k = csi.get(fin) or (tilde.get(par) if fin == "~" else None)
                    if k:
                        out.append(k)
                    i = j + 1
                    continue
                break
            out.append("ESC")
            i += 1
        elif c in "\r\n":
            out.append("ENTER")
            i += 1
        elif c in "\x7f\x08":
            out.append("BACKSPACE")
            i += 1
        elif c == "\t":
            out.append("TAB")
            i += 1
        else:
            out.append(c)
            i += 1
    return out


def run_tui(app: Base, fps: float):
    import tty
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    out = sys.stdout.buffer

    def stop(*_):
        app.running = False

    def winch(*_):
        app.size_dirty = True

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGHUP, stop)
    signal.signal(signal.SIGWINCH, winch)
    try:
        tty.setcbreak(fd)
        out.write(b"\x1b[?1049h\x1b[?25l\x1b[?7l\x1b[2J" + app.setup() + (b"\x1b[?1000h\x1b[?1006h" if getattr(app, "wants_mouse", False) else b""))
        out.flush()
        nxt = last = time.monotonic()
        while app.running:
            frame_t = 1.0 / app.target_fps()
            t0 = time.monotonic()
            dt = min(0.1, t0 - last)
            last = t0
            data = app.frame(dt, t0)
            if data:
                out.write(data)
                out.flush()
            ms = (time.monotonic() - t0) * 1000.0
            app.stats = (app.stats[0] * 0.9 + ms * 0.1, len(data))
            app.watch(app.stats[0], frame_t * 1000.0, t0)
            nxt += frame_t
            remain = nxt - time.monotonic()
            if remain < 0:
                nxt, remain = time.monotonic(), 0.0
            r, _, _ = select.select([fd], [], [], remain)
            if r:
                for k in parse_keys(os.read(fd, 256).decode("utf-8", "ignore")):
                    app.key(k)
    finally:
        try:
            out.write(app.teardown() + b"\x1b[?1000l\x1b[?1006l\x1b[0m\x1b[?7h\x1b[?25h\x1b[?1049l")
            out.flush()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)


def detect_render(pref: str) -> str:
    if pref in ("kitty", "cells"):
        return pref
    if os.environ.get("TMUX") or os.environ.get("STY") or IS_TERMUX:
        return "cells"          # graphics protocol does not pass through multiplexers
    if os.environ.get("KITTY_WINDOW_ID") or os.environ.get("TERM") == "xterm-kitty":
        return "kitty"
    return "cells"


def _import_web():
    """`lyricglow web` needs lyricglow_web.py (+ the webplayfr/ site folder next to it). Look beside this script, in the install folder, in
    $LYRICGLOW_HOME — and if it isn't anywhere, say exactly how to fix it instead of printing a traceback."""
    import importlib.util
    here = os.path.dirname(os.path.realpath(__file__))
    for d in (os.environ.get("LYRICGLOW_HOME", ""), here, os.path.dirname(os.path.abspath(__file__)), os.path.expanduser("~/.local/share/lyricglow"),
              os.path.join(os.environ.get("PREFIX", ""), "share", "lyricglow") if os.environ.get("PREFIX") else "", "/usr/local/share/lyricglow", "/usr/share/lyricglow"):
        p = os.path.join(d, "lyricglow_web.py") if d else ""
        if p and os.path.isfile(p):
            spec = importlib.util.spec_from_file_location("lyricglow_web", p)
            mod = importlib.util.module_from_spec(spec)
            sys.modules["lyricglow_web"] = mod
            spec.loader.exec_module(mod)
            return mod
    raise SystemExit("lyricglow web: can't find lyricglow_web.py (the web backend) — it lives in the lyricglow folder next to lyricglow.py.\n"
                     "  fix:  cd <the lyricglow folder> && sh install.sh        (installs it to ~/.local/share/lyricglow)\n"
                     "   or:  python3 /path/to/lyricglow/lyricglow_web.py        or set LYRICGLOW_HOME=/path/to/lyricglow")


def load_config() -> dict:
    if tomllib and os.path.exists(CONF):
        try:
            with open(CONF, "rb") as f:
                return tomllib.load(f)
        except Exception as e:
            print(f"lyricglow: bad config {CONF}: {e}", file=sys.stderr)
    return {}


# --- config: TOML tables are flattened into the flat option names the rest of the program uses
TABLE_MAP = {
    "sources": {"backend": "backend", "player": "player", "mpv_socket": "mpv_socket", "cmd": "cmd", "api": "api"},
    "display": {"render": "render", "list_style": "list_style", "lyric_style": "lyric_style", "shader": "shader", "font": "font", "before": "before", "after": "after", "art": "art",
                "align": "align", "max_width": "max_width", "offset": "offset", "debug": "debug"},
    "glow": {"strength": "glow", "style": "glow_style", "color": "glow_color", "size": "glow_size", "follow": "glow_follow"},
    "performance": {"fps": "fps", "sweep_hz": "sweep_hz", "bg_hz": "bg_hz", "low_end": "low_end"},
    "canvas": {"sources": "canvas", "dir": "canvas_dir", "endpoints": "canvas_endpoint", "headers": "canvas_header",
               "apple_api": "apple_api", "fps": "canvas_fps", "seconds": "canvas_seconds"},
    "ytm": {"auth_file": "ytm_auth", "authuser": "ytm_authuser", "user": "ytm_user", "language": "ytm_language", "radio": "ytm_radio",
            "volume": "volume", "mpv_args": "mpv_args", "cookies_from_browser": "ytm_cookies_browser",
            "oauth_client_id": "ytm_oauth_client_id", "oauth_client_secret": "ytm_oauth_client_secret",
            "gapless": "ytm_gapless", "cache": "ytm_cache", "cache_mb": "ytm_cache_mb", "cache_ahead": "ytm_cache_ahead", "resume": "ytm_resume",
            "album_enter": "ytm_album_enter", "search_filter": "ytm_search_filter"},
    "immersive": {"grow": "grow_mode", "grow_size": "grow_size", "grow_opacity": "grow_opacity", "grow_anim": "grow_anim", "grow_db_scale": "grow_db_scale",
                  "grow_db_label": "grow_db_label", "grow_db_floor": "grow_db_floor", "corners": "corners", "corner_strength": "corner_strength"},
    "beat": {"enabled": "beat", "source": "beat_source", "strength": "beat_strength"},
    "cyber": {"mode": "cyber_mode", "intensity": "cyber_intensity", "shake": "cyber_shake", "moon": "cyber_moon", "moon_all": "cyber_moon_all",
              "scene": "cyber_scene", "figures": "cyber_figures", "echo": "cyber_echo", "stutter": "cyber_stutter", "hud": "cyber_hud"},
    "addons": {"shell": "addon_shell"},
    "background": {"mode": "bg_mode", "file": "bg_file", "fit": "bg_fit", "dim": "bg_dim", "rotate": "bg_rotate", "fps": "bg_fps",
                   "beat": "bg_beat", "addons": "addon"},
    "web": {"host": "web_host", "port": "web_port", "allow": "web_allow", "auth": "web_auth", "token": "web_token",
            "stream_mode": "web_stream_mode", "bitrate": "web_bitrate", "cache_mb": "web_cache_mb", "canvas_codec": "web_canvas_codec", "cors": "web_cors"},
    "discord": {"enabled": "discord", "client_id": "discord_client_id", "scope": "discord_scope", "type": "discord_type",
                "details": "discord_details", "state": "discord_state", "large_text": "discord_large_text",
                "art": "discord_art", "large_image": "discord_large_image", "small_image": "discord_small_image",
                "small_text": "discord_small_text", "timestamps": "discord_timestamps", "buttons": "discord_buttons",
                "paused": "discord_paused", "min_interval": "discord_min_interval"},
}
CONFIG_KEYS = {v for t in TABLE_MAP.values() for v in t.values()} | {
    "fps", "sweep_hz", "bg_hz", "glow", "glow_style", "glow_color", "glow_size", "glow_follow", "shader", "before", "after",
    "align", "max_width", "offset", "art", "api", "player", "render", "font", "debug", "low_end", "backend", "cmd",
    "mpv_socket", "canvas", "canvas_dir", "canvas_endpoint", "canvas_header", "apple_api", "canvas_fps", "canvas_seconds",
    "volume", "ytm_radio", "mpv_args"}

DEFAULTS = dict(
    discord=False, discord_client_id="", discord_scope="ytm", discord_type="listening", discord_details="{title}",
    discord_state="{artist}", discord_large_text="{album}", discord_art="url", discord_large_image="", discord_small_image="",
    discord_small_text="", discord_timestamps="bar", discord_paused="hide", discord_min_interval=15.0,
    discord_buttons=[{"label": "Listen on YouTube Music", "url": "{url}"}],
    ytm_auth=None, ytm_authuser=0, ytm_user=None, ytm_language="en", ytm_oauth_client_id=None, ytm_oauth_client_secret=None, ytm_cookies_browser=None,
    canvas_header={}, canvas_endpoint=None, apple_api=None, canvas_dir=None)
DEFAULTS.update(addon_shell=False)
DEFAULTS.update(ytm_gapless=True, ytm_cache=True, ytm_cache_mb=0, ytm_cache_ahead=3, ytm_resume=True, ytm_album_enter="play", ytm_search_filter="all",
                grow_mode="behind", grow_size="auto", grow_opacity=0.5, grow_anim=True, grow_db_scale=False, grow_db_label=False, grow_db_floor=-30.0,
                corners=True, corner_strength=1.0)
DEFAULTS.update(bg_mode="auto", bg_file=None, bg_fit="cover", bg_dim=0.42, bg_rotate=0, bg_fps=10, bg_beat=True, addon=None,
                lyric_style="classic", cyber_figures=True, cyber_echo=True, cyber_stutter=True, cyber_hud=True, cyber_scene="auto")
DEFAULTS.update(beat=True, beat_source="auto", beat_strength=1.0, cyber_mode="auto", cyber_intensity=0.7, cyber_shake=0.6,
                cyber_moon=True, cyber_moon_all=False)
DEFAULTS.update(web_host="auto", web_port=8787, web_allow=["tailscale", "loopback"], web_auth="token", web_token="",
                web_stream_mode="direct", web_bitrate=160, web_cache_mb=2048, web_canvas_codec="h264", web_cors=["*"])
DEFAULT_CANVAS = ["local", "endpoints", "apple"]      # animated cover is ON by default


def flatten_config(conf: dict) -> dict:
    out = {}
    for k, v in conf.items():
        if isinstance(v, dict) and k in TABLE_MAP:
            for kk, vv in v.items():
                tgt = TABLE_MAP[k].get(kk)
                if tgt:
                    out[tgt] = vv
                else:
                    print(f"lyricglow: unknown config key [{k}] {kk} (ignored) — see example.config.toml", file=sys.stderr)
        elif k in CONFIG_KEYS:
            out[k] = v
        else:
            print(f"lyricglow: unknown config key {k!r} (ignored) — see example.config.toml", file=sys.stderr)
    return out


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="lyricglow", description="A YouTube Music app for your terminal — synced word-by-word lyrics, animated covers, Discord presence.",
                                 epilog="commands:\n  lyricglow ytm [search words | URL]   the YouTube Music player\n"
                                        "  lyricglow ytm login [browser]        sign in using your browser's YouTube login (or press  l  in the app)\n"
                                        "  lyricglow ytm logout | status        sign out / show who is signed in\n"
                                        "  lyricglow web                        the web app: host it on this machine, open it from your phone over Tailscale\n"
                                        "  lyricglow                            lyrics for whatever is already playing (Spotify, Firefox, mpv…)\n"
                                        "  lyricglow doctor                     diagnose players / terminal / Termux / Discord",
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", nargs="?", choices=["ytm", "doctor", "web"])
    ap.add_argument("query", nargs="*", help="for `ytm`: what to search / play, or login | logout | status")
    ap.add_argument("--demo", action="store_true", help="preview with built-in sample lyrics (no player needed)")
    ap.add_argument("--render", choices=["auto", "kitty", "cells"], default="auto")
    ap.add_argument("--cyber", dest="cyber_mode", choices=["off", "auto", "on"],
                    help="cyberpsychosis glitch: auto = only 'I Really Want to Stay at Your House', on = every song (live key: X)")
    ap.add_argument("--cyber-intensity", dest="cyber_intensity", type=float, help="0..1 (default 0.7)")
    ap.add_argument("--cyber-shake", dest="cyber_shake", type=float, help="0..1 screen shake on the beat (default 0.6)")
    ap.add_argument("--cyber-moon-all", dest="cyber_moon_all", action="store_true", help="show the moon scene for every song while cyberpsychosis is on")
    ap.add_argument("--bg", dest="bg_file", help="background for every song: an image, GIF or video file (or URL)")
    ap.add_argument("--bg-mode", dest="bg_mode", choices=["auto", "procedural", "immersive", "off"], help="auto = images/GIFs/addons when available · immersive = glossy "
                                                                     "floating objects + sparkles (live key: b)")
    ap.add_argument("--bg-dim", dest="bg_dim", type=float, help="darken the background for readability, 0..1 (default 0.42)")
    ap.add_argument("--addon", action="append", help="a *.add background pack (repeatable); ~/.config/lyricglow/addons/ is scanned automatically")
    ap.add_argument("--lyric-style", dest="lyric_style", choices=["classic", "kinetic", "word", "immersive", "slice", "caption", "vintage"],
                    help="kinetic = huge phrase lyric-video look · word = ONE word · immersive = word effects (fire, water, drinks…) · slice = glossy "
                         "typography · caption = caption box (addon-configurable) · vintage = pastel collage (live key: T cycles)")
    ap.add_argument("--addon-shell", dest="addon_shell", action="store_true", help="allow addon buttons to run shell commands (off by default)")
    ap.add_argument("--no-figures", dest="cyber_figures", action="store_false", help="hide the David & Lucy silhouettes (live key: F)")
    ap.add_argument("--no-echo", dest="cyber_echo", action="store_false", help="cyberpsychosis: no duplicated/echo text")
    ap.add_argument("--no-stutter", dest="cyber_stutter", action="store_false", help="cyberpsychosis: no stutter")
    ap.add_argument("--no-hud", dest="cyber_hud", action="store_false", help="cyberpsychosis: hide the warning bar")
    ap.add_argument("--cyber-scene", dest="cyber_scene", choices=["auto", "off"], help="the built-in Earth/moon scene for the tribute song")
    ap.add_argument("--no-cache", dest="ytm_cache", action="store_false", help="don't download songs to the audio cache (no gapless / instant replays)")
    ap.add_argument("--no-gapless", dest="ytm_gapless", action="store_false", help="don't hand the next song to mpv early")
    ap.add_argument("--cache-mb", dest="ytm_cache_mb", type=float, help="audio cache size limit in MB (default 2000, Termux 600)")
    ap.add_argument("--album-enter", dest="ytm_album_enter", choices=["play", "open"], help="Enter on an album/artist: play = queue it whole (default), open = browse it")
    ap.add_argument("--search-filter", dest="ytm_search_filter", choices=["all", "songs", "albums", "artists"], help="starting filter for search results (key: f)")
    ap.add_argument("--no-resume", dest="ytm_resume", action="store_false", help="don't restore last session's queue")
    ap.add_argument("--grow", dest="grow_mode", choices=["behind", "above", "off"], help="immersive: the big YOU — behind the lyrics (default), above them, or off")
    ap.add_argument("--grow-size", dest="grow_size", help="immersive: 'auto' (as big as fits) or a number")
    ap.add_argument("--grow-opacity", dest="grow_opacity", type=float, help="immersive: 0.05–1 (default 0.5)")
    ap.add_argument("--grow-db-scale", dest="grow_db_scale", action="store_true", help="immersive: scale the big YOU by the loudness (dB)")
    ap.add_argument("--grow-db-label", dest="grow_db_label", action="store_true", help="immersive: show the dB readout")
    ap.add_argument("--no-corners", dest="corners", action="store_false", help="immersive: no corner-of-the-screen effects")
    ap.add_argument("--no-beat", dest="beat", action="store_false", help="turn the beat-reactive background off (live key: B)")
    ap.add_argument("--beat-source", dest="beat_source", choices=["auto", "track", "monitor", "lyrics"])
    ap.add_argument("--list-style", choices=["classic", "modern"], default=None,
                    help="modern = a small album cover beside every song in lists (default in kitty; opt-in elsewhere)")
    ap.add_argument("--backend", choices=["auto", "playerctl", "mpv", "android", "cmd"], default="auto")
    ap.add_argument("--player", help="MPRIS: only follow this player")
    ap.add_argument("--cmd", help="command that prints the current track (JSON/TSV)")
    ap.add_argument("--mpv-socket", help="mpv --input-ipc-server path")
    ap.add_argument("--api", action="append", help="lyrics API base URL (repeatable)")
    ap.add_argument("--fps", type=float, default=None, help="motion frame rate 1-240 (60 / 120 supported)")
    ap.add_argument("--sweep-hz", type=float, default=40.0)
    ap.add_argument("--bg-hz", type=float, default=24.0)
    ap.add_argument("--glow", type=float, default=None, help="glow strength 0..2")
    ap.add_argument("--glow-style", choices=GLOW_ORDER, default="soft")
    ap.add_argument("--glow-color", default="album", help="album | white | accent | warm | cool | #rrggbb")
    ap.add_argument("--glow-size", type=float, default=1.0)
    ap.add_argument("--glow-follow", choices=["trail", "head"], default=None)
    ap.add_argument("--shader", choices=["off", "low", "high"], default=None)
    ap.add_argument("--before", choices=["sat", "desat"], default="desat")
    ap.add_argument("--after", choices=["sat", "desat"], default="sat")
    ap.add_argument("--align", choices=["center", "left"], default="left")
    ap.add_argument("--max-width", type=int, default=72)
    ap.add_argument("--font")
    ap.add_argument("--offset", type=float, default=0.0)
    ap.add_argument("--no-art", dest="art", action="store_false")
    ap.add_argument("--low-end", choices=["auto", "on", "off"], default="auto")
    ap.add_argument("--canvas", default=None, help="animated cover sources: local,endpoints,apple  (default: all three; 'off' disables)")
    ap.add_argument("--no-canvas", action="store_true", help="turn the animated cover off")
    ap.add_argument("--canvas-dir")
    ap.add_argument("--canvas-endpoint", action="append")
    ap.add_argument("--apple-api", action="append")
    ap.add_argument("--canvas-fps", type=int, default=12)
    ap.add_argument("--canvas-seconds", type=float, default=6.0)
    ap.add_argument("--volume", type=int, default=70)
    ap.add_argument("--no-radio", dest="ytm_radio", action="store_false")
    ap.add_argument("--mpv-arg", dest="mpv_args", action="append")
    ap.add_argument("--host", dest="web_host", help="web: address to bind (default: all interfaces, filtered to Tailscale + this machine)")
    ap.add_argument("--port", dest="web_port", type=int, help="web: port (default 8787)")
    ap.add_argument("--no-auth", action="store_true", help="web: don't require the access token")
    ap.add_argument("--token", dest="web_token", help="web: access token (default: generated once and saved)")
    ap.add_argument("--stream-mode", dest="web_stream_mode", choices=["direct", "aac", "mp3", "opus"], help="web: direct proxy or ffmpeg transcode")
    ap.add_argument("--manual", action="store_true", help="ytm login: paste request headers instead of reusing the browser login")
    ap.add_argument("--discord", action="store_true", help="Discord Rich Presence (Linux; needs discord client_id in the config)")
    ap.add_argument("--discord-id", dest="discord_client_id", help="Discord application id")
    ap.add_argument("--debug", action="store_true")
    ap.add_argument("--version", action="version", version=f"lyricglow {VERSION}")
    ap.set_defaults(**DEFAULTS)
    ap.set_defaults(**flatten_config(load_config()))
    return ap


def build_backends(cfg, state: State):
    if cfg.demo:
        return [DemoBackend(state)]
    mpv = MpvBackend(state, cfg.mpv_socket)
    if cfg.cmd or cfg.backend == "cmd":
        if not cfg.cmd:
            sys.exit("--backend cmd needs --cmd 'your command'")
        return [CmdBackend(state, cfg.cmd)]
    if cfg.backend == "playerctl":
        return [PlayerctlBackend(state, cfg.player)]
    if cfg.backend == "mpv":
        return [mpv]
    if cfg.backend == "android":
        return [AndroidBackend(state)]
    if IS_TERMUX:
        return [mpv, AndroidBackend(state)]
    return [PlayerctlBackend(state, cfg.player), mpv]


def run_doctor(cfg):
    yes = lambda b: "\x1b[32m✔\x1b[0m" if b else "\x1b[31m✘\x1b[0m"
    print(f"lyricglow {VERSION} — doctor\n")
    print(f"python      {sys.version.split()[0]} on {sys.platform}  termux={IS_TERMUX}")
    print("\ntools")
    for t, why in [("playerctl", "MPRIS (Linux)"), ("mpv", "ytm player / mpv backend"), ("yt-dlp", "ytm player"),
                   ("ffmpeg", "animated covers (mp4/hls)"), ("fc-match", "font lookup (kitty renderer)"),
                   ("adb", "Termux exact sync"), ("rish", "Termux exact sync (Shizuku)"),
                   ("termux-notification-list", "Termux fallback")]:
        print(f"  {yes(shutil.which(t))} {t:<26}{shutil.which(t) or '-':<40}{why}")
    print("\nlibraries")
    print(f"  {yes(np is not None)} numpy      {np.__version__ if np else '— needed for the kitty renderer'}")
    print(f"  {yes(Image is not None)} Pillow     {getattr(Image, '__version__', '') if Image else '— needed for cover art + kitty renderer'}")
    try:
        import ytmusicapi  # noqa
        print(f"  {yes(True)} ytmusicapi  installed")
    except ImportError:
        print(f"  {yes(False)} ytmusicapi  not installed (optional: richer search + radio; pip install ytmusicapi)")
    W, H = term_size()
    r_, c_, xp, yp = win_px()
    print("\nterminal")
    print(f"  TERM={os.environ.get('TERM')}  KITTY_WINDOW_ID={os.environ.get('KITTY_WINDOW_ID')}  TMUX={'yes' if os.environ.get('TMUX') else 'no'}")
    print(f"  {W}x{H} cells, {xp}x{yp} px   -> renderer: {detect_render(cfg.render)}")
    print("\nnetwork")
    try:
        http_get(DEFAULT_APIS[0] + "/", 8)
        print(f"  {yes(True)} {DEFAULT_APIS[0]} reachable")
    except Exception as e:
        print(f"  {yes(False)} {DEFAULT_APIS[0]}: {e}")
    print("\nsources")
    st = State()
    if shutil.which("playerctl"):
        r = subprocess.run(["playerctl", "-l"], capture_output=True, text=True)
        print(f"  MPRIS players: {r.stdout.split() or 'none running'}")
    socks = MpvBackend.candidates(cfg.mpv_socket)
    print(f"  mpv sockets:   {socks or 'none found (start mpv with --input-ipc-server=/tmp/mpvsocket)'}")
    for sk in socks[:3]:
        mb = MpvBackend(st, sk)
        print(f"    {sk}: {'responds as mpv' if mb._connect(sk) else 'not an mpv socket'}")
    if IS_TERMUX:
        ab = AndroidBackend(st)
        ab.cmd = ab.find_cmd()
        print(f"  android:       dumpsys via {ab.cmd or 'NOT AVAILABLE (set up adb wireless debugging, see README)'}")
        if ab.cmd:
            try:
                _, out = _run(ab.cmd, 12)
                sess = parse_media_sessions(out)
                print(f"    media sessions parsed: {len(sess)}")
                for s_ in sess[:4]:
                    print(f"      {s_['pkg']}  state={s_['state']}  pos={s_['position_ms'] / 1000:.1f}s  {s_['desc'][:50]}")
                if not sess:
                    print("    (none parsed — if something IS playing, send me the output of: adb shell dumpsys media_session | head -60)")
            except Exception as e:
                print(f"    dumpsys failed: {e}")
        try:
            rc, out = _run(["termux-notification-list"], 10)
            n = len(json.loads(out or "[]")) if rc == 0 else 0
            print(f"  notifications: {'readable, ' + str(n) + ' present' if rc == 0 else 'FAILED — open Termux:API and grant notification access'}")
        except Exception as e:
            print(f"  notifications: {e}")
    print("\nYouTube Music account")
    print(f"  {yes(ACCOUNT.signed_in)} {'signed in' if ACCOUNT.signed_in else 'not signed in'}  ({ACCOUNT.auth})")
    ff = [n for n in _FF_ROOTS if _ff_profiles(n)]
    logged = []
    for n in ff:
        try:
            if read_browser_cookies(n):
                logged.append(n)
        except Exception:
            pass
    print(f"  Firefox-family browsers found: {ff or 'none'}   with a YouTube login: {logged or 'none'}")
    print("  (Chrome-family browsers are only read when you run `lyricglow ytm login` — they can trigger a keyring prompt)")
    if not ACCOUNT.signed_in:
        print("  -> to sign in: log in at music.youtube.com in your browser, then press  l  in `lyricglow ytm`  (or run `lyricglow ytm login`)")
    print("\nanimated cover (kitty only)")
    print(f"  sources: {cfg.canvas or 'off'}")
    print(f"  {yes(shutil.which('ffmpeg'))} ffmpeg   {'' if shutil.which('ffmpeg') else '— needed to decode mp4 / HLS loops (sudo pacman -S ffmpeg)'}")
    print("\ndiscord presence (Linux only)")
    print(f"  {yes(DiscordRPC.supported())} supported on this system")
    print(f"  {yes(bool(DiscordRPC.socket_paths()))} Discord IPC sockets: {[os.path.basename(x) for x in DiscordRPC.socket_paths()] or 'none — is Discord (or Vesktop) running?'}")
    print(f"  {yes(bool(str(cfg.discord_client_id).strip()))} client_id configured   enabled={cfg.discord}")
    print("\ncache/log:", CACHE)


def main():
    cfg = build_parser().parse_args()
    cfg.fps = clamp(cfg.fps, 1.0, 240.0) if cfg.fps else None
    cfg.glow_size = clamp(float(cfg.glow_size), 0.4, 3.0)
    if cfg.no_canvas:
        cfg.canvas = []
    elif cfg.canvas is None:
        cfg.canvas = list(DEFAULT_CANVAS)
    elif isinstance(cfg.canvas, str):
        cfg.canvas = [x.strip() for x in cfg.canvas.split(",") if x.strip() and x.strip().lower() not in ("off", "none", "false")]
    ACCOUNT.configure(cfg)
    if cfg.no_auth:
        cfg.web_auth = "none"
    if cfg.command == "web":
        sys.path.insert(0, os.path.dirname(os.path.realpath(__file__)))
        lyricglow_web = _import_web()
        return lyricglow_web.serve(cfg, sys.modules[__name__])
    if cfg.command == "doctor":
        return run_doctor(cfg)
    if cfg.command == "ytm" and cfg.query[:1] in (["login"], ["logout"], ["status"]) and len(cfg.query) <= (2 if cfg.query[0] == "login" else 1):
        return {"login": run_login, "logout": run_logout, "status": run_status}[cfg.query[0]](cfg)
    if not sys.stdout.isatty() or not sys.stdin.isatty():
        sys.exit("lyricglow needs an interactive terminal.")

    kind = detect_render(cfg.render)
    state = State()
    apis = cfg.api if isinstance(cfg.api, list) and cfg.api else ([cfg.api] if cfg.api else DEFAULT_APIS)
    loader = CanvasLoader(cfg) if (kind == "kitty" and cfg.canvas and np is not None) else None
    fx = Fetcher(apis, demo=cfg.demo, canvas=loader)
    if not cfg.list_style:
        cfg.list_style = "modern" if (kind == "kitty" and Image is not None) else "classic"
    app: Base | None = None
    if kind == "kitty":
        try:
            cfg.fps = cfg.fps or 60.0
            cfg.shader = cfg.shader or "high"
            cfg.glow = 1.0 if cfg.glow is None else cfg.glow
            app = KittyApp(cfg, state, fx)
        except Exception as e:
            print(f"lyricglow: kitty renderer unavailable ({e}); using the cell renderer", file=sys.stderr)
            fx.cloader = None
            time.sleep(1.5)
    if app is None:
        cfg.fps = cfg.fps or (20.0 if IS_TERMUX else 30.0)
        cfg.shader = cfg.shader or ("low" if IS_TERMUX else "high")
        cfg.glow = 0.8 if cfg.glow is None else cfg.glow
        app = CellApp(cfg, state, fx)

    if fx.cloader and any(x in ("apple", "endpoints") for x in fx.cloader.sources) and not cfg.demo:
        app.say("animated covers on: artist+album are looked up on a community artwork server — canvas = [] turns it off", 8)

    player = rpc = None
    if cfg.command == "ytm":
        player = YtmPlayer(state, cfg)
        app.ytm = player
        backends = [player]
        miss = player.missing()
        if miss:
            app.say(miss, 10)
        if getattr(cfg, "ytm_resume", True) and not cfg.query:
            n_ = player.load_queue()
            if n_:
                app.say(f"restored {n_} songs from last time — press Q to open the queue", 7)
        if cfg.query:
            app.start_search(" ".join(cfg.query), autoplay=True)
        else:
            app.view = "pick"
            app.enter_tab("quick")
    else:
        backends = build_backends(cfg, state)
    if cfg.discord:
        if not DiscordRPC.supported():
            app.say("discord presence is Linux-only — disabled here", 6)
        elif not str(cfg.discord_client_id).strip():
            app.say("discord: set client_id under [discord] in the config (see example.config.toml)", 10)
        else:
            rpc = DiscordRPC(state, cfg)
            rpc.start()
            app.rpc = rpc
    Composite(state, backends).start()
    try:
        run_tui(app, cfg.fps)
    except KeyboardInterrupt:
        pass
    finally:
        if rpc:
            rpc.shutdown()
        if player:
            player.shutdown()


if __name__ == "__main__":
    main()
